"""Affectation des horaires hebdomadaires aux employés."""

from datetime import date, time

from sqlalchemy import select
from sqlalchemy.orm import Session, joinedload

from gestion_presence.database.models import AuditLog, Employee, WorkSchedule
from gestion_presence.errors import EntityNotFound, ValidationError
from gestion_presence.services.rbac import RbacService


class WorkScheduleService:
    @staticmethod
    def list_all(
        session: Session, *, actor_user_id: int
    ) -> list[WorkSchedule]:
        RbacService.require_permission(session, actor_user_id, "employee.view")
        return list(
            session.scalars(
                select(WorkSchedule)
                .options(joinedload(WorkSchedule.employee))
                .order_by(WorkSchedule.employee_id, WorkSchedule.day_of_week)
            )
        )

    @staticmethod
    def create(
        session: Session,
        *,
        actor_user_id: int,
        employee_id: int,
        name: str,
        day_of_week: int,
        start_time: time,
        end_time: time,
        effective_from: date,
        effective_to: date | None = None,
        break_minutes: int = 0,
        grace_period_minutes: int = 0,
    ) -> WorkSchedule:
        RbacService.require_permission(session, actor_user_id, "employee.update")
        employee = session.get(Employee, employee_id)
        if employee is None:
            raise EntityNotFound(f"Employé introuvable (id={employee_id}).")
        if day_of_week not in range(7) or start_time == end_time:
            raise ValidationError("Jour ou intervalle horaire invalide.")
        if break_minutes < 0 or grace_period_minutes < 0:
            raise ValidationError("Pause et tolérance doivent être positives ou nulles.")
        if effective_to is not None and effective_to < effective_from:
            raise ValidationError("La date de fin précède la date d'effet.")

        existing_schedules = session.scalars(
            select(WorkSchedule).where(
                WorkSchedule.employee_id == employee_id,
                WorkSchedule.day_of_week == day_of_week,
                WorkSchedule.is_active.is_(True),
            )
        )
        for existing in existing_schedules:
            existing_end = existing.effective_to or date.max
            new_end = effective_to or date.max
            if effective_from <= existing_end and existing.effective_from <= new_end:
                raise ValidationError(
                    "Un horaire actif existe déjà pour ce jour et cette période."
                )

        schedule = WorkSchedule(
            employee_id=employee_id,
            name=name.strip(),
            day_of_week=day_of_week,
            start_time=start_time,
            end_time=end_time,
            effective_from=effective_from,
            effective_to=effective_to,
            break_minutes=break_minutes,
            grace_period_minutes=grace_period_minutes,
        )
        session.add(schedule)
        session.flush()
        session.add(
            AuditLog(
                user_id=actor_user_id,
                action="CREATE_WORK_SCHEDULE",
                entity_type="work_schedule",
                entity_id=str(schedule.id),
            )
        )
        session.flush()
        return schedule

    @staticmethod
    def set_active(
        session: Session,
        schedule_id: int,
        *,
        actor_user_id: int,
        is_active: bool,
    ) -> WorkSchedule:
        RbacService.require_permission(session, actor_user_id, "employee.update")
        schedule = session.get(WorkSchedule, schedule_id)
        if schedule is None:
            raise EntityNotFound(f"Horaire introuvable (id={schedule_id}).")
        schedule.is_active = is_active
        session.add(
            AuditLog(
                user_id=actor_user_id,
                action="UPDATE_WORK_SCHEDULE_STATUS",
                entity_type="work_schedule",
                entity_id=str(schedule.id),
                details={"is_active": is_active},
            )
        )
        session.flush()
        return schedule
