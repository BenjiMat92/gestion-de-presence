"""Assemblage des composants d'infrastructure de l'application."""

import logging

from sqlalchemy import Engine, text
from sqlalchemy.exc import SQLAlchemyError

from gestion_presence.config import Settings
from gestion_presence.database.connection import create_database, create_engine
from gestion_presence.errors import ApplicationError

logger = logging.getLogger(__name__)


def initialize_application(settings: Settings | None = None) -> Engine:
    """Initialise les tables SQLite et confirme qu'une connexion fonctionne."""
    current_settings = settings or Settings.from_env()
    database_path = current_settings.database_path
    if database_path is not None and str(database_path) != ":memory:":
        database_path.parent.mkdir(parents=True, exist_ok=True)

    engine = create_engine(current_settings.database_url)
    try:
        create_database(engine)
        with engine.connect() as connection:
            connection.execute(text("SELECT 1"))
    except (SQLAlchemyError, OSError, ApplicationError):
        engine.dispose()
        logger.exception("Impossible d'initialiser la base de données.")
        raise
    logger.info("Connexion SQLite initialisée.")
    return engine
