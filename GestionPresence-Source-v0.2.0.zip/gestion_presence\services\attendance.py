"""Opérations métier de pointage et calculs horaires."""

from datetime import date, datetime, time, timedelta, timezone

from sqlalchemy import select
from sqlalchemy.orm import Session

from gestion_presence.config import Settings
from gestion_presence.database.models import (
    Attendance,
    AuditLog,
    Device,
    Employee,
    WorkSchedule,
)
from gestion_presence.errors import (
    AttendanceConflict,
    DeviceUnavailable,
    InactiveEmployee,
    UnknownEmployee,
    ValidationError,
)
from gestion_presence.errors import EntityNotFound
from gestion_presence.services.rbac import RbacService


class AttendanceService:
    """Pointe entrée/sortie après validation RBAC, employé et appareil."""

    @staticmethod
    def clock_in(
        session: Session,
        *,
        employee_code: str,
        actor_user_id: int,
        settings: Settings,
        identification_method: str = "qr",
        device_code: str | None = None,
        at: datetime | None = None,
    ) -> Attendance:
        RbacService.require_permission(session, actor_user_id, "attendance.create")
        current_time = AttendanceService._as_utc(at)
        employee = AttendanceService._find_employee(session, employee_code)
        if not employee.is_active:
            raise InactiveEmployee(f"L'employé {employee.employee_code} est désactivé.")
        device = AttendanceService._validate_identification(
            session, identification_method, device_code, current_time
        )
        local_time = current_time.astimezone(settings.timezone)
        attendance_date = local_time.date()
        existing = session.scalar(
            select(Attendance).where(
                Attendance.employee_id == employee.id,
                Attendance.attendance_date == attendance_date,
            )
        )
        if existing is not None:
            if existing.check_out_at is None:
                raise AttendanceConflict("L'entrée de cet employé est déjà enregistrée.")
            raise AttendanceConflict("L'entrée et la sortie de cet employé sont déjà enregistrées.")

        schedule = AttendanceService._schedule_for(
            session, employee.id, attendance_date
        )
        late_minutes: int | None = None
        if schedule is not None:
            scheduled_start = datetime.combine(
                attendance_date, schedule.start_time, tzinfo=settings.timezone
            )
            threshold = scheduled_start + timedelta(
                minutes=schedule.grace_period_minutes
            )
            late_minutes = max(
                0,
                int((local_time - threshold).total_seconds() // 60),
            )

        attendance = Attendance(
            employee_id=employee.id,
            device_id=device.id if device is not None else None,
            attendance_date=attendance_date,
            check_in_at=current_time.replace(tzinfo=None),
            identification_method=identification_method,
            status="open",
            late_minutes=late_minutes,
        )
        session.add(attendance)
        session.flush()
        session.add(
            AuditLog(
                user_id=actor_user_id,
                action="CLOCK_IN",
                entity_type="attendance",
                entity_id=str(attendance.id),
                details={
                    "employee_code": employee.employee_code,
                    "identification_method": identification_method,
                    "device_code": device_code,
                },
            )
        )
        session.flush()
        return attendance

    @staticmethod
    def clock_out(
        session: Session,
        *,
        employee_code: str,
        actor_user_id: int,
        settings: Settings,
        identification_method: str = "qr",
        device_code: str | None = None,
        at: datetime | None = None,
    ) -> Attendance:
        RbacService.require_permission(session, actor_user_id, "attendance.create")
        current_time = AttendanceService._as_utc(at)
        employee = AttendanceService._find_employee(session, employee_code)
        if not employee.is_active:
            raise InactiveEmployee(f"L'employé {employee.employee_code} est désactivé.")
        device = AttendanceService._validate_identification(
            session, identification_method, device_code, current_time
        )
        attendance = session.scalar(
            select(Attendance)
            .where(
                Attendance.employee_id == employee.id,
                Attendance.check_out_at.is_(None),
                Attendance.status == "open",
            )
            .order_by(Attendance.attendance_date.desc(), Attendance.check_in_at.desc())
            .limit(1)
        )
        if attendance is None:
            raise AttendanceConflict("Aucune entrée ouverte n'existe pour cet employé.")
        if current_time.replace(tzinfo=None) < attendance.check_in_at:
            raise ValidationError("La sortie ne peut pas précéder l'entrée.")

        attendance.check_out_at = current_time.replace(tzinfo=None)
        if device is not None:
            attendance.device_id = device.id

        schedule = AttendanceService._schedule_for(
            session, employee.id, attendance.attendance_date
        )
        check_in_utc = attendance.check_in_at.replace(tzinfo=timezone.utc)
        elapsed_minutes = int(
            (current_time - check_in_utc).total_seconds() // 60
        )
        if schedule is None:
            attendance.worked_minutes = elapsed_minutes
            attendance.early_departure_minutes = None
            attendance.overtime_minutes = None
        else:
            attendance.worked_minutes = max(
                0, elapsed_minutes - schedule.break_minutes
            )
            expected_end = datetime.combine(
                attendance.attendance_date,
                schedule.end_time,
                tzinfo=settings.timezone,
            )
            expected_start = datetime.combine(
                attendance.attendance_date,
                schedule.start_time,
                tzinfo=settings.timezone,
            )
            if schedule.end_time <= schedule.start_time:
                expected_end += timedelta(days=1)
            local_checkout = current_time.astimezone(settings.timezone)
            attendance.early_departure_minutes = max(
                0,
                int((expected_end - local_checkout).total_seconds() // 60),
            )
            attendance.overtime_minutes = max(
                0,
                int((local_checkout - expected_end).total_seconds() // 60),
            )
            if local_checkout < expected_start:
                attendance.early_departure_minutes = int(
                    (expected_end - local_checkout).total_seconds() // 60
                )
        attendance.status = "completed"
        session.add(
            AuditLog(
                user_id=actor_user_id,
                action="CLOCK_OUT",
                entity_type="attendance",
                entity_id=str(attendance.id),
                details={
                    "employee_code": employee.employee_code,
                    "identification_method": identification_method,
                    "device_code": device_code,
                },
            )
        )
        session.flush()
        return attendance

    @staticmethod
    def daily_report(
        session: Session,
        *,
        actor_user_id: int,
        attendance_date: date,
        employee_id: int | None = None,
        department_id: int | None = None,
    ) -> list[Attendance]:
        RbacService.require_permission(session, actor_user_id, "attendance.view")
        statement = (
            select(Attendance)
            .join(Employee)
            .where(Attendance.attendance_date == attendance_date)
        )
        if employee_id is not None:
            statement = statement.where(Attendance.employee_id == employee_id)
        if department_id is not None:
            statement = statement.where(Employee.department_id == department_id)
        return list(
            session.scalars(
                statement.order_by(Employee.last_name, Employee.first_name)
            )
        )

    @staticmethod
    def adjust(
        session: Session,
        attendance_id: int,
        *,
        actor_user_id: int,
        settings: Settings,
        check_in_at: datetime,
        check_out_at: datetime | None,
        status: str,
        note: str,
    ) -> Attendance:
        RbacService.require_permission(session, actor_user_id, "attendance.update")
        if status not in {"open", "completed", "anomaly", "excused"}:
            raise ValidationError(f"Statut de pointage invalide : {status}")
        local_check_in = AttendanceService._as_utc(check_in_at)
        local_check_out = (
            AttendanceService._as_utc(check_out_at) if check_out_at else None
        )
        if local_check_out is not None and local_check_out < local_check_in:
            raise ValidationError("La sortie ne peut pas précéder l'entrée.")
        attendance = session.get(Attendance, attendance_id)
        if attendance is None:
            raise EntityNotFound(f"Pointage introuvable (id={attendance_id}).")

        previous_values = {
            "check_in_at": attendance.check_in_at.isoformat(),
            "check_out_at": (
                attendance.check_out_at.isoformat()
                if attendance.check_out_at is not None
                else None
            ),
            "status": attendance.status,
        }
        attendance.check_in_at = local_check_in.replace(tzinfo=None)
        attendance.check_out_at = (
            local_check_out.replace(tzinfo=None) if local_check_out else None
        )
        attendance.status = status
        attendance.note = note.strip() or None

        schedule = AttendanceService._schedule_for(
            session, attendance.employee_id, attendance.attendance_date
        )
        local_day = attendance.attendance_date
        check_in_local = local_check_in.astimezone(settings.timezone)
        if schedule is not None:
            expected_start = datetime.combine(
                local_day, schedule.start_time, tzinfo=settings.timezone
            )
            grace_end = expected_start + timedelta(
                minutes=schedule.grace_period_minutes
            )
            attendance.late_minutes = max(
                0, int((check_in_local - grace_end).total_seconds() // 60)
            )
        else:
            attendance.late_minutes = None

        if local_check_out is None:
            attendance.worked_minutes = None
            attendance.early_departure_minutes = None
            attendance.overtime_minutes = None
        else:
            elapsed_minutes = int(
                (local_check_out - local_check_in).total_seconds() // 60
            )
            if schedule is None:
                attendance.worked_minutes = elapsed_minutes
                attendance.early_departure_minutes = None
                attendance.overtime_minutes = None
            else:
                expected_end = datetime.combine(
                    local_day, schedule.end_time, tzinfo=settings.timezone
                )
                if schedule.end_time <= schedule.start_time:
                    expected_end += timedelta(days=1)
                check_out_local = local_check_out.astimezone(settings.timezone)
                attendance.worked_minutes = max(
                    0, elapsed_minutes - schedule.break_minutes
                )
                attendance.early_departure_minutes = max(
                    0,
                    int((expected_end - check_out_local).total_seconds() // 60),
                )
                attendance.overtime_minutes = max(
                    0,
                    int((check_out_local - expected_end).total_seconds() // 60),
                )

        session.add(
            AuditLog(
                user_id=actor_user_id,
                action="ADJUST_ATTENDANCE",
                entity_type="attendance",
                entity_id=str(attendance.id),
                details={"before": previous_values, "note": attendance.note},
            )
        )
        session.flush()
        return attendance

    @staticmethod
    def _find_employee(session: Session, employee_code: str) -> Employee:
        employee = session.scalar(
            select(Employee).where(Employee.employee_code == employee_code.strip())
        )
        if employee is None:
            raise UnknownEmployee(f"QR Code inconnu ou employé introuvable : {employee_code}")
        return employee

    @staticmethod
    def _validate_identification(
        session: Session,
        identification_method: str,
        device_code: str | None,
        current_time: datetime,
    ) -> Device | None:
        if identification_method not in {"qr", "fingerprint", "manual"}:
            raise ValidationError(
                f"Méthode d'identification non prise en charge : {identification_method}"
            )
        if device_code is None:
            if identification_method != "manual":
                raise DeviceUnavailable("Aucune pointeuse n'est associée au pointage.")
            return None

        device = session.scalar(
            select(Device).where(Device.device_code == device_code.strip())
        )
        if device is None or device.status != "active":
            raise DeviceUnavailable(f"Pointeuse indisponible : {device_code}")
        accepted_types = {
            "qr": {"qr", "mixed"},
            "fingerprint": {"fingerprint", "mixed"},
            "manual": {"qr", "fingerprint", "mixed"},
        }
        if device.device_type not in accepted_types[identification_method]:
            raise DeviceUnavailable(
                f"La pointeuse {device.device_code} n'accepte pas {identification_method}."
            )
        device.last_seen_at = current_time.replace(tzinfo=None)
        return device

    @staticmethod
    def _schedule_for(
        session: Session, employee_id: int, target_date: date
    ) -> WorkSchedule | None:
        statement = (
            select(WorkSchedule)
            .where(
                WorkSchedule.employee_id == employee_id,
                WorkSchedule.day_of_week == target_date.weekday(),
                WorkSchedule.is_active.is_(True),
                WorkSchedule.effective_from <= target_date,
                (WorkSchedule.effective_to.is_(None))
                | (WorkSchedule.effective_to >= target_date),
            )
            .order_by(WorkSchedule.effective_from.desc())
            .limit(1)
        )
        return session.scalar(statement)

    @staticmethod
    def _as_utc(value: datetime | None) -> datetime:
        current_time = value or datetime.now(timezone.utc)
        if current_time.tzinfo is None or current_time.utcoffset() is None:
            raise ValidationError("L'heure de pointage doit inclure un fuseau horaire.")
        return current_time.astimezone(timezone.utc)
