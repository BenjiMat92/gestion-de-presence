"""Écriture et consultation du journal d'audit."""

from datetime import datetime

from sqlalchemy import select
from sqlalchemy.orm import Session, joinedload

from gestion_presence.database.models import AuditLog
from gestion_presence.errors import ValidationError
from gestion_presence.services.rbac import RbacService


class AuditService:
    @staticmethod
    def record(
        session: Session,
        *,
        action: str,
        user_id: int | None = None,
        entity_type: str | None = None,
        entity_id: str | None = None,
        result: str = "success",
        details: dict[str, object] | None = None,
        occurred_at: datetime | None = None,
    ) -> AuditLog:
        if result not in {"success", "failure"}:
            raise ValidationError("Le résultat d'audit doit être success ou failure.")
        entry = AuditLog(
            user_id=user_id,
            action=action,
            entity_type=entity_type,
            entity_id=entity_id,
            result=result,
            details=details,
            occurred_at=occurred_at,
        )
        session.add(entry)
        session.flush()
        return entry

    @staticmethod
    def search(
        session: Session,
        *,
        actor_user_id: int,
        user_id: int | None = None,
        action: str | None = None,
        since: datetime | None = None,
        until: datetime | None = None,
        limit: int = 500,
    ) -> list[AuditLog]:
        RbacService.require_permission(session, actor_user_id, "audit.view")
        if limit < 1 or limit > 5000:
            raise ValidationError("La limite d'audit doit être comprise entre 1 et 5000.")
        statement = select(AuditLog).options(joinedload(AuditLog.user))
        if user_id is not None:
            statement = statement.where(AuditLog.user_id == user_id)
        if action:
            statement = statement.where(AuditLog.action == action)
        if since:
            statement = statement.where(AuditLog.occurred_at >= since)
        if until:
            statement = statement.where(AuditLog.occurred_at <= until)
        statement = statement.order_by(AuditLog.occurred_at.desc()).limit(limit)
        return list(session.scalars(statement))
