"""Écrans Tkinter d'administration, de rapports et de supervision."""

from datetime import date, datetime, time, timedelta, timezone
import os
from pathlib import Path
import subprocess
import tempfile
import threading
import tkinter as tk
from tkinter import StringVar, filedialog, messagebox, ttk

from sqlalchemy import select
from sqlalchemy.orm import Session, joinedload

from gestion_presence.config import Settings
from gestion_presence.i18n import (
    LANGUAGE_SETTING_KEY,
    SUPPORTED_LANGUAGES,
    get_language,
    localize_widget_tree,
    set_language,
    translate,
)
from gestion_presence.database.models import (
    Attendance,
    Department,
    Employee,
    Role,
    RolePermission,
    User,
    UserRole,
)
from gestion_presence.services.access_control import AccessControlService
from gestion_presence.services.audit import AuditService
from gestion_presence.services.attendance import AttendanceService
from gestion_presence.services.authentication import AuthenticationService
from gestion_presence.services.backups import BackupService
from gestion_presence.services.departments import DepartmentService
from gestion_presence.services.devices import DeviceService
from gestion_presence.services.reports import ReportService
from gestion_presence.services.settings import SettingsService
from gestion_presence.services.updates import (
    UpdateRelease,
    check_for_update,
    download_update,
)
from gestion_presence.services.work_schedules import WorkScheduleService
from gestion_presence.version import __version__
from gestion_presence.ui.common import (
    BasePage,
    ask_form,
    build_table,
    fill_table,
    has_ui_permission,
    read_database,
    show_error,
    write_database,
)


def _page_table(parent, headers):
    return build_table(parent.content, headers)


def _selected_values(page) -> tuple[str, ...] | None:
    selected = page.table.selection()
    if not selected:
        messagebox.showinfo(page.title_label.cget("text"), "Sélectionnez une ligne.",
                            parent=page)
        return None
    return page.table.item(selected[0], "values")


class DashboardPage(BasePage):
    def __init__(self, parent, session_factory, settings: Settings, actor_user_id: int):
        super().__init__(parent, "Tableau de bord")
        self.session_factory = session_factory
        self.settings = settings
        self.actor_user_id = actor_user_id
        self.metrics: dict[str, ttk.Label] = {}
        metrics = ttk.Frame(self.content)
        metrics.grid(row=0, column=0, sticky="ew", pady=(0, 18))
        labels = (
            ("employees", "Employés actifs"),
            ("present", "Présents aujourd'hui"),
            ("absent", "Sans pointage"),
            ("late", "En retard"),
            ("open", "Pointages ouverts"),
        )
        for column, (key, caption) in enumerate(labels):
            card = ttk.LabelFrame(metrics, text=caption, padding=14)
            card.grid(row=0, column=column, sticky="nsew", padx=5)
            metrics.columnconfigure(column, weight=1)
            self.metrics[key] = ttk.Label(card, text="—", style="Metric.TLabel")
            self.metrics[key].pack()
        self.add_action("Actualiser", self.refresh)
        ttk.Label(self.content, text="Derniers pointages du jour",
                  font=("Segoe UI", 12, "bold")).grid(
            row=1, column=0, sticky="w", pady=(4, 8)
        )
        table_frame = ttk.Frame(self.content)
        table_frame.grid(row=2, column=0, sticky="nsew")
        self.content.rowconfigure(2, weight=1)
        self.recent = build_table(
            table_frame, ["Heure", "Matricule", "Employé", "Service", "Pointage"]
        )
        self.refresh()

    def refresh(self):
        current_date = datetime.now(self.settings.timezone).date()
        try:
            def collect(session: Session):
                counts = ReportService.dashboard_counts(
                    session, actor_user_id=self.actor_user_id,
                    attendance_date=current_date,
                )
                records = list(session.scalars(
                    select(Attendance)
                    .options(joinedload(Attendance.employee).joinedload(Employee.department))
                    .where(Attendance.attendance_date == current_date)
                    .order_by(Attendance.check_in_at.desc())
                    .limit(10)
                ))
                return counts, [
                    (
                        item.check_in_at.strftime("%H:%M"),
                        item.employee.employee_code,
                        f"{item.employee.first_name} {item.employee.last_name}",
                        item.employee.department.name if item.employee.department else "",
                        item.status,
                    )
                    for item in records
                ]

            counts, rows = read_database(self.session_factory, collect)
            for key, label in self.metrics.items():
                label.configure(text=str(counts[key]))
            fill_table(self.recent, rows)
        except Exception as error:
            show_error("Tableau de bord", error)


class DepartmentPage(BasePage):
    def __init__(self, parent, session_factory, actor_user_id: int):
        super().__init__(parent, "Services et départements")
        self.session_factory = session_factory
        self.actor_user_id = actor_user_id
        self.add_action("Activer / désactiver", self.toggle,
                        permission=has_ui_permission(session_factory, actor_user_id,
                                                     "department.update"))
        self.add_action("Ajouter un service", self.add_department,
                        permission=has_ui_permission(session_factory, actor_user_id,
                                                     "department.create"))
        self.table = _page_table(self, ["ID", "Code", "Nom", "Description", "Statut"])
        self.refresh()

    def refresh(self):
        try:
            rows = read_database(self.session_factory, lambda session: [
                (item.id, item.code, item.name, item.description or "",
                 "Actif" if item.is_active else "Désactivé")
                for item in DepartmentService.list_all(
                    session, actor_user_id=self.actor_user_id
                )
            ])
            fill_table(self.table, rows)
        except Exception as error:
            show_error("Services", error)

    def add_department(self):
        values = ask_form(self, "Nouveau service", [
            ("Code", "", None, False), ("Nom", "", None, False),
            ("Description", "", None, False),
        ])
        if values is None:
            return
        try:
            write_database(self.session_factory, lambda session: DepartmentService.create(
                session, actor_user_id=self.actor_user_id,
                code=str(values["Code"]), name=str(values["Nom"]),
                description=str(values["Description"]),
            ))
            self.refresh()
        except Exception as error:
            show_error("Service", error)

    def toggle(self):
        values = _selected_values(self)
        if values is None:
            return
        department_id = int(values[0])
        try:
            active = read_database(
                self.session_factory,
                lambda session: bool(session.get(Department, department_id).is_active),
            )
            write_database(self.session_factory, lambda session: DepartmentService.set_active(
                session, department_id, actor_user_id=self.actor_user_id,
                is_active=not active,
            ))
            self.refresh()
        except Exception as error:
            show_error("Services", error)


class DevicePage(BasePage):
    def __init__(self, parent, session_factory, actor_user_id: int):
        super().__init__(parent, "Pointeuses et appareils")
        self.session_factory = session_factory
        self.actor_user_id = actor_user_id
        self.add_action("Changer le statut", self.change_status,
                        permission=has_ui_permission(session_factory, actor_user_id,
                                                     "device.update"))
        self.add_action("Ajouter", self.add_device,
                        permission=has_ui_permission(session_factory, actor_user_id,
                                                     "device.create"))
        self.table = _page_table(self, [
            "ID", "Code", "Nom", "Emplacement", "Type", "Statut", "Dernière activité"
        ])
        self.refresh()

    def refresh(self):
        try:
            rows = read_database(self.session_factory, lambda session: [
                (device.id, device.device_code, device.name, device.location or "",
                 device.device_type, device.status, device.last_seen_at or "")
                for device in DeviceService.list_all(
                    session, actor_user_id=self.actor_user_id
                )
            ])
            fill_table(self.table, rows)
        except Exception as error:
            show_error("Pointeuses", error)

    def add_device(self):
        types = [("QR Code", "qr"), ("Empreinte (matériel futur)", "fingerprint"),
                 ("QR + empreinte", "mixed")]
        values = ask_form(self, "Nouvelle pointeuse", [
            ("Identifiant", "DEVICE-001", None, False),
            ("Nom", "", None, False), ("Emplacement", "", None, False),
            ("Type", "QR Code", types, False),
        ])
        if values is None:
            return
        try:
            write_database(self.session_factory, lambda session: DeviceService.create(
                session, actor_user_id=self.actor_user_id,
                device_code=str(values["Identifiant"]), name=str(values["Nom"]),
                location=str(values["Emplacement"]), device_type=str(values["Type"]),
            ))
            self.refresh()
        except Exception as error:
            show_error("Pointeuse", error)

    def change_status(self):
        values = _selected_values(self)
        if values is None:
            return
        statuses = [("active", "active"), ("inactive", "inactive"),
                    ("maintenance", "maintenance")]
        choice = ask_form(self, "Statut de la pointeuse", [
            ("Statut", str(values[5]), statuses, False),
        ])
        if choice is None:
            return
        try:
            write_database(self.session_factory, lambda session: DeviceService.set_status(
                session, int(values[0]), actor_user_id=self.actor_user_id,
                status=str(choice["Statut"]),
            ))
            self.refresh()
        except Exception as error:
            show_error("Pointeuse", error)


class SchedulePage(BasePage):
    WEEKDAYS = ["Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi", "Dimanche"]

    def __init__(self, parent, session_factory, actor_user_id: int):
        super().__init__(parent, "Horaires de travail")
        self.session_factory = session_factory
        self.actor_user_id = actor_user_id
        self.add_action("Activer / désactiver", self.toggle,
                        permission=has_ui_permission(session_factory, actor_user_id,
                                                     "employee.update"))
        self.add_action("Créer un horaire", self.add_schedule,
                        permission=has_ui_permission(session_factory, actor_user_id,
                                                     "employee.update"))
        self.table = _page_table(self, [
            "ID", "Matricule", "Employé", "Jour", "Début", "Fin", "Pause",
            "Tolérance", "Du", "Au", "Actif",
        ])
        self.refresh()

    def refresh(self):
        try:
            rows = read_database(self.session_factory, lambda session: [
                (
                    schedule.id,
                    schedule.employee.employee_code,
                    f"{schedule.employee.first_name} {schedule.employee.last_name}",
                    self.WEEKDAYS[schedule.day_of_week],
                    schedule.start_time.strftime("%H:%M"),
                    schedule.end_time.strftime("%H:%M"),
                    schedule.break_minutes,
                    schedule.grace_period_minutes,
                    schedule.effective_from,
                    schedule.effective_to or "",
                    "Oui" if schedule.is_active else "Non",
                )
                for schedule in WorkScheduleService.list_all(
                    session, actor_user_id=self.actor_user_id
                )
            ])
            fill_table(self.table, rows)
        except Exception as error:
            show_error("Horaires", error)

    def add_schedule(self):
        employees = read_database(
            self.session_factory,
            lambda session: list(session.scalars(
                select(Employee).where(Employee.is_active.is_(True))
                .order_by(Employee.last_name)
            )),
        )
        if not employees:
            messagebox.showinfo("Horaires", "Créez d'abord un employé actif.", parent=self)
            return
        employee_choices = [
            (f"{item.employee_code} — {item.first_name} {item.last_name}", item.id)
            for item in employees
        ]
        days = [(day, index) for index, day in enumerate(self.WEEKDAYS)]
        values = ask_form(self, "Créer un horaire", [
            ("Employé", employee_choices[0][0], employee_choices, False),
            ("Nom", "Horaire standard", None, False),
            ("Jour", "Lundi", days, False),
            ("Début (HH:MM)", "08:00", None, False),
            ("Fin (HH:MM)", "16:00", None, False),
            ("Pause (minutes)", "0", None, False),
            ("Tolérance (minutes)", "0", None, False),
            ("Date d'effet (AAAA-MM-JJ)", date.today().isoformat(), None, False),
        ])
        if values is None:
            return
        try:
            write_database(self.session_factory, lambda session: WorkScheduleService.create(
                session,
                actor_user_id=self.actor_user_id,
                employee_id=int(values["Employé"]),
                name=str(values["Nom"]),
                day_of_week=int(values["Jour"]),
                start_time=time.fromisoformat(str(values["Début (HH:MM)"])),
                end_time=time.fromisoformat(str(values["Fin (HH:MM)"])),
                effective_from=date.fromisoformat(str(values["Date d'effet (AAAA-MM-JJ)"])),
                break_minutes=int(str(values["Pause (minutes)"])),
                grace_period_minutes=int(str(values["Tolérance (minutes)"])),
            ))
            self.refresh()
        except Exception as error:
            show_error("Horaire", error)

    def toggle(self):
        values = _selected_values(self)
        if values is None:
            return
        try:
            write_database(self.session_factory, lambda session: WorkScheduleService.set_active(
                session, int(values[0]), actor_user_id=self.actor_user_id,
                is_active=values[10] != "Oui",
            ))
            self.refresh()
        except Exception as error:
            show_error("Horaire", error)


class UserPage(BasePage):
    def __init__(self, parent, session_factory, actor_user_id: int):
        super().__init__(parent, "Utilisateurs")
        self.session_factory = session_factory
        self.actor_user_id = actor_user_id
        self.add_action("Activer / désactiver", self.toggle_user,
                        permission=has_ui_permission(session_factory, actor_user_id,
                                                     "user.update"))
        self.add_action("Créer un utilisateur", self.create_user,
                        permission=has_ui_permission(session_factory, actor_user_id,
                                                     "user.create"))
        self.table = _page_table(self, [
            "ID", "Utilisateur", "Employé associé", "Rôles", "Statut",
            "Dernière connexion",
        ])
        self.refresh()

    def refresh(self):
        try:
            rows = read_database(self.session_factory, lambda session: [
                (
                    user.id,
                    user.username,
                    user.employee.employee_code if user.employee else "Compte responsable",
                    ", ".join(assignment.role.name for assignment in user.user_roles),
                    "Actif" if user.is_active else "Désactivé",
                    user.last_login_at or "Jamais",
                )
                for user in AuthenticationService.list_users(
                    session, actor_user_id=self.actor_user_id
                )
            ])
            fill_table(self.table, rows)
        except Exception as error:
            show_error("Utilisateurs", error)

    def create_user(self):
        roles, employees = read_database(self.session_factory, lambda session: (
            AccessControlService.list_roles(session, actor_user_id=self.actor_user_id),
            list(session.scalars(
                select(Employee).where(Employee.is_active.is_(True))
                .order_by(Employee.last_name)
            )),
        ))
        role_choices = [("Aucun rôle", None)] + [
            (role.name, role.id) for role in roles if role.is_active
        ]
        employee_choices = [("Compte responsable", None)] + [
            (f"{item.employee_code} — {item.first_name} {item.last_name}", item.id)
            for item in employees
        ]
        values = ask_form(self, "Créer un utilisateur", [
            ("Nom d'utilisateur", "", None, False),
            ("Mot de passe (12 caractères min.)", "", None, True),
            ("Rôle", role_choices[0][0], role_choices, False),
            ("Employé", employee_choices[0][0], employee_choices, False),
        ])
        if values is None:
            return
        try:
            write_database(self.session_factory, lambda session: AuthenticationService.create_user(
                session,
                created_by=self.actor_user_id,
                username=str(values["Nom d'utilisateur"]),
                password=str(values["Mot de passe (12 caractères min.)"]),
                role_id=values["Rôle"],
                employee_id=values["Employé"],
            ))
            self.refresh()
        except Exception as error:
            show_error("Utilisateur", error)

    def toggle_user(self):
        values = _selected_values(self)
        if values is None:
            return
        try:
            write_database(self.session_factory, lambda session: AuthenticationService.set_active(
                session,
                int(values[0]),
                actor_user_id=self.actor_user_id,
                is_active=values[4] != "Actif",
            ))
            self.refresh()
        except Exception as error:
            show_error("Utilisateur", error)


class RolePage(BasePage):
    def __init__(self, parent, session_factory, actor_user_id: int):
        super().__init__(parent, "Rôles et permissions")
        self.session_factory = session_factory
        self.actor_user_id = actor_user_id
        self.add_action("Activer / désactiver", self.toggle_role,
                        permission=has_ui_permission(session_factory, actor_user_id,
                                                     "role.update"))
        self.add_action("Configurer permissions", self.edit_permissions,
                        permission=has_ui_permission(session_factory, actor_user_id,
                                                     "role.update"))
        self.add_action("Créer un rôle", self.create_role,
                        permission=has_ui_permission(session_factory, actor_user_id,
                                                     "role.create"))
        self.table = _page_table(self, [
            "ID", "Nom", "Description", "Système", "Actif", "Permissions"
        ])
        self.refresh()

    def refresh(self):
        try:
            rows = read_database(self.session_factory, lambda session: [
                (
                    role.id,
                    role.name,
                    role.description or "",
                    "Oui" if role.is_system else "Non",
                    "Oui" if role.is_active else "Non",
                    len(role.role_permissions),
                )
                for role in AccessControlService.list_roles(
                    session, actor_user_id=self.actor_user_id
                )
            ])
            fill_table(self.table, rows)
        except Exception as error:
            show_error("Rôles", error)

    def create_role(self):
        values = ask_form(self, "Nouveau rôle", [
            ("Nom", "", None, False), ("Description", "", None, False),
        ])
        if values is None:
            return
        try:
            write_database(self.session_factory, lambda session: AccessControlService.create_role(
                session, actor_user_id=self.actor_user_id,
                name=str(values["Nom"]), description=str(values["Description"]),
            ))
            self.refresh()
        except Exception as error:
            show_error("Rôle", error)

    def edit_permissions(self):
        values = _selected_values(self)
        if values is None:
            return
        role_id = int(values[0])
        if values[3] == "Oui":
            messagebox.showinfo(
                "Rôles", "Les permissions du rôle système ne peuvent pas être modifiées.",
                parent=self,
            )
            return
        try:
            permissions, active_ids = read_database(self.session_factory, lambda session: (
                AccessControlService.list_permissions(
                    session, actor_user_id=self.actor_user_id
                ),
                {
                    item.permission_id
                    for item in session.scalars(
                        select(RolePermission).where(RolePermission.role_id == role_id)
                    )
                },
            ))
            fields = [
                (permission.name, "Oui" if permission.id in active_ids else "Non",
                 [("Oui", True), ("Non", False)], False)
                for permission in permissions
            ]
            changes = ask_form(self, f"Permissions — {values[1]}", fields)
            if changes is None:
                return
            permission_ids = {
                permission.id for permission in permissions
                if changes[permission.name] is True
            }
            write_database(self.session_factory, lambda session:
                AccessControlService.set_role_permissions(
                    session, actor_user_id=self.actor_user_id,
                    role_id=role_id, permission_ids=permission_ids,
                )
            )
            self.refresh()
        except Exception as error:
            show_error("Permissions", error)

    def toggle_role(self):
        values = _selected_values(self)
        if values is None:
            return
        try:
            write_database(self.session_factory, lambda session:
                AccessControlService.set_role_active(
                    session, actor_user_id=self.actor_user_id,
                    role_id=int(values[0]), is_active=values[4] != "Oui",
                )
            )
            self.refresh()
        except Exception as error:
            show_error("Rôle", error)


class ReportPage(BasePage):
    def __init__(self, parent, session_factory, actor_user_id: int,
                 settings: Settings):
        super().__init__(parent, "Rapports de présence")
        self.session_factory = session_factory
        self.actor_user_id = actor_user_id
        self.settings = settings
        self._rows: list[Attendance] = []
        self.start_date = StringVar(value=(date.today() - timedelta(days=6)).isoformat())
        self.end_date = StringVar(value=date.today().isoformat())
        self.employee_id: int | None = None
        self.department_id: int | None = None
        filter_row = ttk.Frame(self.content)
        filter_row.grid(row=0, column=0, sticky="ew", pady=(0, 10))
        ttk.Label(filter_row, text="Du (AAAA-MM-JJ)").pack(side="left")
        ttk.Entry(filter_row, textvariable=self.start_date, width=12).pack(
            side="left", padx=(6, 12)
        )
        ttk.Label(filter_row, text="Au (AAAA-MM-JJ)").pack(side="left")
        ttk.Entry(filter_row, textvariable=self.end_date, width=12).pack(
            side="left", padx=(6, 12)
        )
        self.employee_filter = ttk.Combobox(filter_row, state="readonly", width=30)
        self.employee_filter.pack(side="left", padx=4)
        self.department_filter = ttk.Combobox(filter_row, state="readonly", width=20)
        self.department_filter.pack(side="left", padx=4)
        self._employee_choices: list[tuple[str, int | None]] = []
        self._department_choices: list[tuple[str, int | None]] = []
        self.add_action("Corriger le pointage", self.adjust_attendance,
                        permission=has_ui_permission(session_factory, actor_user_id,
                                                     "attendance.update"))
        self.add_action("Exporter CSV", self.export_csv,
                        permission=has_ui_permission(session_factory, actor_user_id,
                                                     "report.export"))
        self.add_action("Générer", self.refresh)
        table_frame = ttk.Frame(self.content)
        table_frame.grid(row=1, column=0, sticky="nsew")
        self.content.rowconfigure(1, weight=1)
        self.table = build_table(table_frame, [
            "ID", "Matricule", "Employé", "Service", "Date", "Entrée", "Sortie",
            "Durée (min)", "Retard (min)", "Anticipé (min)",
            "Supplémentaire (min)", "Statut",
        ])
        self._load_filters()
        self.refresh()

    def _load_filters(self):
        try:
            employees, departments = read_database(self.session_factory, lambda session: (
                list(session.scalars(select(Employee).order_by(Employee.last_name))),
                list(session.scalars(select(Department).order_by(Department.name))),
            ))
            self._employee_choices = [("Tous les employés", None)] + [
                (f"{item.employee_code} — {item.first_name} {item.last_name}", item.id)
                for item in employees
            ]
            self._department_choices = [("Tous les services", None)] + [
                (item.name, item.id) for item in departments
            ]
            self.employee_filter.configure(
                values=[label for label, _ in self._employee_choices]
            )
            self.department_filter.configure(
                values=[label for label, _ in self._department_choices]
            )
            self.employee_filter.current(0)
            self.department_filter.current(0)
        except Exception as error:
            show_error("Rapports", error)

    def refresh(self):
        try:
            start = date.fromisoformat(self.start_date.get().strip())
            end = date.fromisoformat(self.end_date.get().strip())
            employee_index = self.employee_filter.current()
            department_index = self.department_filter.current()
            employee_id = self._employee_choices[employee_index][1] if employee_index >= 0 else None
            department_id = self._department_choices[department_index][1] if department_index >= 0 else None
            self._rows = read_database(self.session_factory, lambda session:
                ReportService.attendance(
                    session, actor_user_id=self.actor_user_id,
                    start_date=start, end_date=end,
                    employee_id=employee_id, department_id=department_id,
                )
            )
            fill_table(self.table, [
                (
                    row.id,
                    row.employee.employee_code,
                    f"{row.employee.first_name} {row.employee.last_name}",
                    row.employee.department.name if row.employee.department else "",
                    row.attendance_date,
                    row.check_in_at.strftime("%H:%M"),
                    row.check_out_at.strftime("%H:%M") if row.check_out_at else "",
                    row.worked_minutes if row.worked_minutes is not None else "",
                    row.late_minutes if row.late_minutes is not None else "",
                    row.early_departure_minutes if row.early_departure_minutes is not None else "",
                    row.overtime_minutes if row.overtime_minutes is not None else "",
                    row.status,
                )
                for row in self._rows
            ])
        except Exception as error:
            show_error("Rapports", error)

    def adjust_attendance(self):
        values = _selected_values(self)
        if values is None:
            return
        attendance = next((row for row in self._rows if row.id == int(values[0])), None)
        if attendance is None:
            messagebox.showerror("Rapports", "Le pointage sélectionné est introuvable.",
                                 parent=self)
            return
        local_in = attendance.check_in_at.replace(tzinfo=timezone.utc).astimezone(
            self.settings.timezone
        )
        local_out = (
            attendance.check_out_at.replace(tzinfo=timezone.utc).astimezone(
                self.settings.timezone
            )
            if attendance.check_out_at else local_in
        )
        statuses = [(status, status) for status in ("open", "completed", "anomaly", "excused")]
        values = ask_form(self, "Corriger un pointage", [
            ("Entrée (HH:MM)", local_in.strftime("%H:%M"), None, False),
            ("Sortie enregistrée", "Oui" if attendance.check_out_at else "Non",
             [("Oui", True), ("Non", False)], False),
            ("Sortie (HH:MM)", local_out.strftime("%H:%M"), None, False),
            ("Statut", attendance.status, statuses, False),
            ("Motif", attendance.note or "", None, False),
        ])
        if values is None:
            return
        try:
            check_in_time = time.fromisoformat(str(values["Entrée (HH:MM)"]))
            check_in_local = datetime.combine(
                attendance.attendance_date, check_in_time,
                tzinfo=self.settings.timezone,
            )
            check_out_local = None
            if values["Sortie enregistrée"] is True:
                check_out_time = time.fromisoformat(str(values["Sortie (HH:MM)"]))
                out_date = attendance.attendance_date
                if check_out_time < check_in_time:
                    out_date += timedelta(days=1)
                check_out_local = datetime.combine(
                    out_date, check_out_time, tzinfo=self.settings.timezone
                )
            write_database(self.session_factory, lambda session: AttendanceService.adjust(
                session, attendance.id, actor_user_id=self.actor_user_id,
                settings=self.settings, check_in_at=check_in_local,
                check_out_at=check_out_local, status=str(values["Statut"]),
                note=str(values["Motif"]),
            ))
            self.refresh()
        except Exception as error:
            show_error("Correction", error)

    def export_csv(self):
        if not self._rows:
            messagebox.showinfo("Rapports", "Aucune donnée à exporter.", parent=self)
            return
        path = filedialog.asksaveasfilename(
            parent=self,
            title="Exporter le rapport",
            initialfile=f"rapport_{self.start_date.get()}_{self.end_date.get()}.csv",
            defaultextension=".csv",
            filetypes=[("Fichier CSV", "*.csv")],
        )
        if not path:
            return
        try:
            write_database(self.session_factory, lambda session:
                ReportService.export_csv(
                    session, actor_user_id=self.actor_user_id,
                    attendances=self._rows, path=Path(path),
                )
            )
            messagebox.showinfo("Rapports", f"Export terminé : {path}", parent=self)
        except Exception as error:
            show_error("Rapports", error)


class AuditPage(BasePage):
    def __init__(self, parent, session_factory, actor_user_id: int):
        super().__init__(parent, "Journal d'audit")
        self.session_factory = session_factory
        self.actor_user_id = actor_user_id
        self.action_filter = StringVar()
        ttk.Entry(self.toolbar, textvariable=self.action_filter, width=35).pack(
            side="left", fill="x", expand=True
        )
        ttk.Label(self.toolbar, text="Filtrer par action (ex. LOGIN)").pack(
            side="left", padx=8
        )
        self.add_action("Actualiser", self.refresh)
        self.table = _page_table(self, [
            "Date et heure", "Utilisateur", "Action", "Type d'objet",
            "Identifiant", "Résultat", "Détails",
        ])
        self.refresh()

    def refresh(self):
        try:
            entries = read_database(self.session_factory, lambda session:
                AuditService.search(
                    session, actor_user_id=self.actor_user_id,
                    action=self.action_filter.get().strip() or None, limit=500,
                )
            )
            fill_table(self.table, [
                (
                    item.occurred_at,
                    item.user.username if item.user else "Utilisateur supprimé",
                    item.action, item.entity_type or "", item.entity_id or "",
                    item.result, item.details or "",
                )
                for item in entries
            ])
        except Exception as error:
            show_error("Audit", error)


class SettingsPage(BasePage):
    def __init__(
        self,
        parent,
        session_factory,
        settings: Settings,
        actor_user_id: int,
        *,
        startup_update: UpdateRelease | None = None,
    ):
        super().__init__(parent, "Configuration")
        self.session_factory = session_factory
        self.settings = settings
        self.actor_user_id = actor_user_id
        self.organization = StringVar()
        self.update_status = StringVar()
        self.language = StringVar()
        self.language_selector: ttk.Combobox | None = None
        self.startup_update = startup_update
        self.add_action("Sauvegarder la base", self.create_backup,
                        permission=has_ui_permission(session_factory, actor_user_id,
                                                     "backup.create"))
        self.add_action("Enregistrer", self.save,
                        permission=has_ui_permission(session_factory, actor_user_id,
                                                     "settings.update"))
        self.update_button = self.add_action(
            "Vérifier les mises à jour",
            self.check_for_updates,
            permission=self._is_system_administrator(),
        )
        form = ttk.Frame(self.content, padding=18)
        form.grid(row=0, column=0, sticky="nw")
        form.columnconfigure(1, weight=1)
        ttk.Label(form, text="Nom de l'organisation").grid(
            row=0, column=0, sticky="w", padx=8, pady=8
        )
        ttk.Entry(form, textvariable=self.organization, width=48).grid(
            row=0, column=1, sticky="ew", padx=8, pady=8
        )
        ttk.Label(form, text="Langue").grid(
            row=1, column=0, sticky="w", padx=8, pady=8
        )
        self.language_selector = ttk.Combobox(
            form,
            textvariable=self.language,
            values=tuple(SUPPORTED_LANGUAGES.values()),
            state="readonly",
            width=45,
        )
        self.language_selector.grid(row=1, column=1, sticky="ew", padx=8, pady=8)
        self.language_selector.bind(
            "<<ComboboxSelected>>", self._language_selected
        )
        details = [
            ("Fuseau horaire", settings.timezone.key),
            ("Base de données", str(settings.database_path or settings.database_url)),
            ("Identification", "QR actif — caméra utilisée après action de l'utilisateur."),
            ("Empreinte", "Architecture préparée, lecteur matériel non configuré."),
        ]
        for row, (label, value) in enumerate(details, start=2):
            ttk.Label(form, text=label).grid(
                row=row, column=0, sticky="nw", padx=8, pady=8
            )
            ttk.Label(form, text=value, wraplength=680).grid(
                row=row, column=1, sticky="w", padx=8, pady=8
            )
        ttk.Label(
            form, textvariable=self.update_status, wraplength=680
        ).grid(row=len(details) + 2, column=0, columnspan=2, sticky="w", padx=8, pady=8)
        self.refresh()
        if startup_update is not None and self.update_button is not None:
            self.update_status.set(
                translate("Version {version} disponible. Cliquez sur « Vérifier les mises à jour » pour l'installer.").format(
                    version=startup_update.version
                )
            )

    def _language_selected(self, _event=None) -> None:
        language = next(
            (
                code
                for code, label in SUPPORTED_LANGUAGES.items()
                if self.language.get() == label
                or self.language.get() == translate(label, "en")
                or self.language.get() == translate(label, "fr")
            ),
            None,
        )
        if language is None:
            return
        set_language(language)
        top_level = self.winfo_toplevel()
        localize_widget_tree(top_level, language)
        if self.language_selector is not None:
            self.language.set(
                translate(SUPPORTED_LANGUAGES[language], language)
            )

    def _is_system_administrator(self) -> bool:
        with self.session_factory() as session:
            return session.scalar(
                select(UserRole.user_id)
                .join(Role, Role.id == UserRole.role_id)
                .join(User, User.id == UserRole.user_id)
                .where(
                    UserRole.user_id == self.actor_user_id,
                    User.is_active.is_(True),
                    Role.name == "ADMINISTRATEUR",
                    Role.is_system.is_(True),
                    Role.is_active.is_(True),
                )
                .limit(1)
            ) is not None

    def check_for_updates(self) -> None:
        if not self._is_system_administrator():
            messagebox.showerror(
                "Mise à jour", "Seul l'administrateur peut lancer une mise à jour.",
                parent=self,
            )
            return
        if self.startup_update is not None:
            release, self.startup_update = self.startup_update, None
            self._finish_update_check(release, None)
            return
        if self.update_button is not None:
            self.update_button.configure(state="disabled")
        self.update_status.set("Vérification des mises à jour…")
        threading.Thread(target=self._update_check_worker, daemon=True).start()

    def _post_to_ui(self, callback) -> None:
        try:
            self.after(0, callback)
        except tk.TclError:
            return

    def _update_check_worker(self) -> None:
        try:
            release = check_for_update()
            self._post_to_ui(lambda: self._finish_update_check(release, None))
        except Exception as error:
            self._post_to_ui(
                lambda error=error: self._finish_update_check(None, error)
            )

    def _finish_update_check(
        self, release: UpdateRelease | None, error: Exception | None
    ) -> None:
        if self.update_button is not None:
            self.update_button.configure(state="normal")
        if error is not None:
            self.update_status.set(f"Vérification impossible : {error}")
            messagebox.showerror("Mise à jour", str(error), parent=self)
            return
        if release is None:
            self.update_status.set(f"Cette installation est à jour (version {__version__}).")
            return
        self.update_status.set(
            f"Version {release.version} disponible. Téléchargement et vérification…"
        )
        if self.update_button is None:
            self.update_status.set("Seul l'administrateur peut lancer une mise à jour.")
            return
        self.update_button.configure(state="disabled")
        destination = Path(tempfile.gettempdir()) / (
            f"GestionPresence-Setup-{release.version}.exe"
        )
        threading.Thread(
            target=self._download_update_worker,
            args=(release, destination),
            daemon=True,
        ).start()

    def _download_update_worker(
        self, release: UpdateRelease, destination: Path
    ) -> None:
        try:
            saved_path = download_update(release, destination)
            self._post_to_ui(
                lambda: self._finish_update_download(saved_path, release, None)
            )
        except Exception as error:
            self._post_to_ui(
                lambda error=error: self._finish_update_download(None, release, error)
            )

    def _finish_update_download(
        self,
        saved_path: Path | None,
        release: UpdateRelease,
        error: Exception | None,
    ) -> None:
        if self.update_button is not None:
            self.update_button.configure(state="normal")
        if error is not None:
            self.update_status.set(f"Téléchargement impossible : {error}")
            messagebox.showerror("Mise à jour", str(error), parent=self)
            return
        if saved_path is None:
            self.update_status.set("Le téléchargement n'a produit aucun fichier.")
            messagebox.showerror(
                "Mise à jour",
                "Le téléchargement n'a produit aucun fichier.",
                parent=self,
            )
            return
        try:
            subprocess.Popen(
                [
                    os.fspath(saved_path),
                    "/SILENT",
                    "/SUPPRESSMSGBOXES",
                    "/NORESTART",
                    "/CLOSEAPPLICATIONS",
                ],
                close_fds=True,
            )
        except OSError as launch_error:
            self.update_status.set(f"Impossible de lancer l'installateur : {launch_error}")
            messagebox.showerror(
                "Mise à jour", str(launch_error), parent=self
            )
            return
        self.update_status.set(
            f"Installation de la version {release.version} en cours…"
        )
        self.winfo_toplevel().destroy()

    def refresh(self):
        try:
            organization = read_database(
                self.session_factory,
                lambda session: SettingsService.get(
                    session,
                    "organization.name",
                    actor_user_id=self.actor_user_id,
                ),
            )
            self.organization.set(organization or "")
            current_language = get_language()
            self.language.set(
                translate(SUPPORTED_LANGUAGES[current_language], current_language)
            )
        except Exception as error:
            show_error("Configuration", error)

    def save(self):
        try:
            language = next(
                (
                    code
                    for code, label in SUPPORTED_LANGUAGES.items()
                    if self.language.get() in {
                        label, translate(label, "en"), translate(label, "fr")
                    }
                ),
                None,
            )
            if language is None:
                raise ValueError("Choisissez une langue prise en charge.")
            write_database(self.session_factory, lambda session:
                (
                    SettingsService.set(
                        session,
                        actor_user_id=self.actor_user_id,
                        key="organization.name",
                        value=self.organization.get().strip(),
                    ),
                    SettingsService.set(
                        session,
                        actor_user_id=self.actor_user_id,
                        key=LANGUAGE_SETTING_KEY,
                        value=language,
                        description="Interface language.",
                    ),
                )
            )
            set_language(language)
            localize_widget_tree(self.winfo_toplevel(), language)
            self.language.set(translate(SUPPORTED_LANGUAGES[language], language))
            messagebox.showinfo(
                translate("Configuration"),
                translate("Paramètres enregistrés."),
                parent=self,
            )
        except Exception as error:
            show_error("Configuration", error)

    def create_backup(self):
        path = filedialog.asksaveasfilename(
            parent=self,
            title="Sauvegarder la base SQLite",
            initialfile=f"gestion_presence_{datetime.now():%Y%m%d_%H%M%S}.db",
            defaultextension=".db",
            filetypes=[("Base SQLite", "*.db")],
        )
        if not path:
            return
        try:
            saved_path = write_database(self.session_factory, lambda session:
                BackupService.create(
                    session, actor_user_id=self.actor_user_id, destination=path
                )
            )
            messagebox.showinfo("Sauvegarde", f"Sauvegarde créée : {saved_path}",
                                parent=self)
        except Exception as error:
            show_error("Sauvegarde", error)
