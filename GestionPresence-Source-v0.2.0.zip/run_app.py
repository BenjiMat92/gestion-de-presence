"""Point d'entrée stable utilisé pour créer l'exécutable Windows."""

from gestion_presence.__main__ import main

if __name__ == "__main__":
    raise SystemExit(main())
