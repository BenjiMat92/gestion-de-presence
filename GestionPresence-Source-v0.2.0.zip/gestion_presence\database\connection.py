"""Configuration et initialisation de SQLite."""

import sqlite3
from pathlib import Path

from sqlalchemy import Engine, URL, create_engine as sqlalchemy_create_engine, event

from gestion_presence.database.models import Base


def create_engine(
    database_url: str | URL = "sqlite:///gestion_presence.db",
) -> Engine:
    """Crée un moteur SQLAlchemy configuré pour SQLite."""
    is_sqlite = (
        database_url.drivername.startswith("sqlite")
        if isinstance(database_url, URL)
        else database_url.startswith("sqlite")
    )
    connect_args = {"check_same_thread": False} if is_sqlite else {}
    engine = sqlalchemy_create_engine(database_url, connect_args=connect_args)

    if is_sqlite:
        @event.listens_for(engine, "connect")
        def enable_foreign_keys(dbapi_connection: sqlite3.Connection, _: object) -> None:
            cursor = dbapi_connection.cursor()
            cursor.execute("PRAGMA foreign_keys=ON")
            cursor.close()

    return engine


def create_database(engine: Engine) -> None:
    """Crée les tables déclarées si elles n'existent pas encore."""
    Base.metadata.create_all(engine)


def create_database_file(path: str | Path) -> Engine:
    """Crée et initialise un fichier SQLite à l'emplacement fourni."""
    database_path = Path(path)
    database_path.parent.mkdir(parents=True, exist_ok=True)
    engine = create_engine(URL.create("sqlite", database=str(database_path.resolve())))
    create_database(engine)
    return engine
