"""Erreurs applicatives explicites pour la couche métier."""


class ApplicationError(Exception):
    """Classe de base des erreurs attendues par l'application."""


class ConfigurationError(ApplicationError):
    """La configuration ne peut pas être utilisée."""


class EntityNotFound(ApplicationError):
    """L'entité demandée n'existe pas."""


class ValidationError(ApplicationError):
    """Une valeur métier n'est pas valide."""


class UnknownEmployee(EntityNotFound):
    """Aucun employé ne correspond à l'identifiant fourni."""


class InactiveEmployee(ApplicationError):
    """L'employé correspondant est désactivé."""


class AttendanceConflict(ApplicationError):
    """Le pointage est incompatible avec l'état existant."""


class DeviceUnavailable(ApplicationError):
    """La pointeuse n'existe pas, est inactive ou n'accepte pas la méthode."""


class AuthenticationFailed(ApplicationError):
    """Les informations de connexion ne sont pas acceptées."""


class PermissionDenied(ApplicationError):
    """L'utilisateur ne possède pas la permission demandée."""
