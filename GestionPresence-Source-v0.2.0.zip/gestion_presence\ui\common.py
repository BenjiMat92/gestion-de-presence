"""Composants Tkinter partagés par les écrans de l'application."""

from collections.abc import Callable, Sequence
from tkinter import StringVar, Toplevel, messagebox, ttk
from typing import TypeVar

from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session, sessionmaker

from gestion_presence.errors import ApplicationError
from gestion_presence.i18n import translate
from gestion_presence.services.rbac import RbacService

T = TypeVar("T")
Field = tuple[str, str, Sequence[tuple[str, object]] | None, bool]


def read_database(
    session_factory: sessionmaker[Session], operation: Callable[[Session], T]
) -> T:
    with session_factory() as session:
        return operation(session)


def write_database(
    session_factory: sessionmaker[Session], operation: Callable[[Session], T]
) -> T:
    with session_factory() as session, session.begin():
        return operation(session)


def has_ui_permission(
    session_factory: sessionmaker[Session], user_id: int, permission: str
) -> bool:
    return read_database(
        session_factory,
        lambda session: RbacService.has_permission(session, user_id, permission),
    )


def format_error(error: Exception) -> str:
    if isinstance(error, (ApplicationError, SQLAlchemyError, OSError, ValueError)):
        return str(error)
    return f"Une erreur inattendue s'est produite : {error}"


def show_error(title: str, error: Exception) -> None:
    messagebox.showerror(translate(title), translate(format_error(error)))


def fill_table(table: ttk.Treeview, rows: Sequence[Sequence[object]]) -> None:
    table.delete(*table.get_children())
    for index, values in enumerate(rows):
        table.insert(
            "",
            "end",
            iid=str(index),
            values=tuple("" if value is None else str(value) for value in values),
        )


def build_table(
    parent,
    headers: Sequence[str],
    *,
    height: int = 18,
) -> ttk.Treeview:
    table = ttk.Treeview(parent, columns=tuple(str(i) for i in range(len(headers))),
                         show="headings", height=height, selectmode="browse")
    for index, heading in enumerate(headers):
        column = str(index)
        table.heading(column, text=heading)
        table.column(column, width=max(100, min(240, len(heading) * 12)),
                     stretch=True, anchor="w")
    vertical = ttk.Scrollbar(parent, orient="vertical", command=table.yview)
    horizontal = ttk.Scrollbar(parent, orient="horizontal", command=table.xview)
    table.configure(yscrollcommand=vertical.set, xscrollcommand=horizontal.set)
    table.grid(row=0, column=0, sticky="nsew")
    vertical.grid(row=0, column=1, sticky="ns")
    horizontal.grid(row=1, column=0, sticky="ew")
    parent.rowconfigure(0, weight=1)
    parent.columnconfigure(0, weight=1)
    return table


class BasePage(ttk.Frame):
    """En-tête, barre d'actions et zone de contenu d'une page."""

    def __init__(self, parent, title: str) -> None:
        super().__init__(parent, padding=22)
        self.columnconfigure(0, weight=1)
        self.rowconfigure(2, weight=1)
        self.title_label = ttk.Label(self, text=title, style="PageTitle.TLabel")
        self.title_label.grid(row=0, column=0, sticky="w", pady=(0, 14))
        self.toolbar = ttk.Frame(self)
        self.toolbar.grid(row=1, column=0, sticky="ew", pady=(0, 12))
        self.toolbar.columnconfigure(0, weight=1)
        self.content = ttk.Frame(self)
        self.content.grid(row=2, column=0, sticky="nsew")
        self.content.columnconfigure(0, weight=1)
        self.content.rowconfigure(0, weight=1)

    def add_action(
        self,
        label: str,
        callback: Callable[[], None],
        *,
        permission: bool = True,
    ) -> ttk.Button | None:
        if not permission:
            return None
        button = ttk.Button(self.toolbar, text=label, command=callback)
        button.pack(side="right", padx=(6, 0))
        return button


def ask_form(
    parent,
    title: str,
    fields: Sequence[Field],
) -> dict[str, object] | None:
    """Affiche un formulaire modal simple; chaque champ est label, valeur, choix, secret."""
    dialog = Toplevel(parent)
    dialog.title(translate(title))
    dialog.transient(parent.winfo_toplevel())
    dialog.resizable(True, False)
    dialog.columnconfigure(1, weight=1)
    variables: dict[str, StringVar] = {}
    choices_by_label: dict[str, Sequence[tuple[str, object]] | None] = {}

    for row, (label, initial, choices, secret) in enumerate(fields):
        ttk.Label(dialog, text=translate(label)).grid(
            row=row, column=0, sticky="w", padx=12, pady=7
        )
        if choices is None:
            variable = StringVar(value=initial)
            control = ttk.Entry(
                dialog,
                textvariable=variable,
                show="*" if secret else "",
                width=38,
            )
        else:
            options = list(choices)
            visible_options = [translate(option[0]) for option in options]
            visible_initial = translate(initial)
            variable = StringVar(value=visible_initial)
            control = ttk.Combobox(
                dialog,
                textvariable=variable,
                values=visible_options,
                state="readonly",
                width=35,
            )
            if options and visible_initial not in visible_options:
                control.current(0)
        control.grid(row=row, column=1, sticky="ew", padx=12, pady=7)
        variables[label] = variable
        choices_by_label[label] = choices

    result: dict[str, object] | None = None

    def save() -> None:
        nonlocal result
        values: dict[str, object] = {}
        for label, variable in variables.items():
            raw = variable.get()
            choices = choices_by_label[label]
            if choices is None:
                values[label] = raw
            else:
                match = next(
                    (
                        value
                        for text, value in choices
                        if translate(text) == raw
                    ),
                    None,
                )
                values[label] = match
        result = values
        dialog.destroy()

    buttons = ttk.Frame(dialog)
    buttons.grid(row=len(fields), column=0, columnspan=2, sticky="e", padx=12, pady=12)
    ttk.Button(buttons, text=translate("Annuler"), command=dialog.destroy).pack(
        side="right", padx=(6, 0)
    )
    ttk.Button(buttons, text=translate("Enregistrer"), command=save).pack(side="right")
    dialog.bind("<Return>", lambda _event: save())
    dialog.bind("<Escape>", lambda _event: dialog.destroy())
    dialog.grab_set()
    dialog.wait_window()
    return result
