"""Administration des rôles et des permissions."""

from sqlalchemy import select
from sqlalchemy.orm import Session

from gestion_presence.database.models import AuditLog, Permission, Role, RolePermission
from gestion_presence.errors import EntityNotFound, ValidationError
from gestion_presence.services.rbac import RbacService


class AccessControlService:
    @staticmethod
    def list_roles(session: Session, *, actor_user_id: int) -> list[Role]:
        RbacService.require_permission(session, actor_user_id, "role.view")
        return list(session.scalars(select(Role).order_by(Role.name)))

    @staticmethod
    def list_permissions(
        session: Session, *, actor_user_id: int
    ) -> list[Permission]:
        RbacService.require_permission(session, actor_user_id, "role.view")
        return list(session.scalars(select(Permission).order_by(Permission.name)))

    @staticmethod
    def create_role(
        session: Session,
        *,
        actor_user_id: int,
        name: str,
        description: str | None = None,
    ) -> Role:
        RbacService.require_permission(session, actor_user_id, "role.create")
        name = name.strip()
        if not name or len(name) > 80:
            raise ValidationError("Le nom du rôle doit contenir de 1 à 80 caractères.")
        if session.scalar(select(Role.id).where(Role.name == name)) is not None:
            raise ValidationError("Ce rôle existe déjà.")
        role = Role(name=name, description=description.strip() if description else None)
        session.add(role)
        session.flush()
        session.add(
            AuditLog(
                user_id=actor_user_id,
                action="CREATE_ROLE",
                entity_type="role",
                entity_id=str(role.id),
            )
        )
        session.flush()
        return role

    @staticmethod
    def set_role_permissions(
        session: Session,
        *,
        actor_user_id: int,
        role_id: int,
        permission_ids: set[int],
    ) -> None:
        RbacService.require_permission(session, actor_user_id, "role.update")
        role = session.get(Role, role_id)
        if role is None:
            raise EntityNotFound(f"Rôle introuvable (id={role_id}).")
        if role.is_system:
            raise ValidationError("Les permissions du rôle système ne peuvent pas être modifiées.")
        permissions = list(
            session.scalars(
                select(Permission).where(Permission.id.in_(permission_ids))
            )
        ) if permission_ids else []
        if {permission.id for permission in permissions} != permission_ids:
            raise EntityNotFound("Une ou plusieurs permissions sont introuvables.")
        for existing in list(role.role_permissions):
            session.delete(existing)
        session.flush()
        session.add_all(
            RolePermission(role_id=role_id, permission_id=permission.id)
            for permission in permissions
        )
        session.add(
            AuditLog(
                user_id=actor_user_id,
                action="UPDATE_ROLE_PERMISSIONS",
                entity_type="role",
                entity_id=str(role_id),
                details={"permission_ids": sorted(permission_ids)},
            )
        )
        session.flush()

    @staticmethod
    def set_role_active(
        session: Session,
        *,
        actor_user_id: int,
        role_id: int,
        is_active: bool,
    ) -> Role:
        RbacService.require_permission(session, actor_user_id, "role.update")
        role = session.get(Role, role_id)
        if role is None:
            raise EntityNotFound(f"Rôle introuvable (id={role_id}).")
        if role.is_system and not is_active:
            raise ValidationError("Le rôle administrateur système ne peut pas être désactivé.")
        role.is_active = is_active
        session.add(
            AuditLog(
                user_id=actor_user_id,
                action="UPDATE_ROLE_STATUS",
                entity_type="role",
                entity_id=str(role_id),
                details={"is_active": is_active},
            )
        )
        session.flush()
        return role
