"""Traductions de l'interface utilisateur."""

from __future__ import annotations

import tkinter as tk
from tkinter import TclError, ttk

SUPPORTED_LANGUAGES = {
    "fr": "Français",
    "en": "Anglais",
}
LANGUAGE_SETTING_KEY = "application.language"

_TRANSLATIONS = {
    "Tableau de bord": "Dashboard",
    "Pointage QR": "QR Attendance",
    "Employés": "Employees",
    "Services": "Departments",
    "Services et départements": "Departments",
    "Horaires": "Schedules",
    "Horaires de travail": "Work Schedules",
    "Rapports": "Reports",
    "Rapports de présence": "Attendance Reports",
    "Utilisateurs": "Users",
    "Rôles et permissions": "Roles and Permissions",
    "Pointeuses": "Devices",
    "Pointeuses et appareils": "Devices",
    "Journal d'audit": "Audit Log",
    "Configuration": "Settings",
    "Démarrage — Gestion des présences": "Starting — Attendance Management",
    "Initialisation de l'application…": "Starting the application…",
    "Vérification des mises à jour…": "Checking for updates…",
    "Sécurisation du poste et des modules": "Securing the workstation and modules",
    "Initialisation de la base et préparation de l'interface":
        "Preparing the database and interface",
    "Ouverture de l'application": "Opening the application",
    "Progression du démarrage": "Startup Progress",
    "Progression": "Progress",
    "Démarrage sécurisé": "Secure Startup",
    "Nouvelle version détectée": "New Version Found",
    "Finalisation du démarrage": "Finishing Startup",
    "Base • Interface • Contrôles • Journalisation":
        "Database • Interface • Controls • Audit",
    "Chargement intelligent": "Smart Startup",
    "Le poste prépare la base, l'interface et les contrôles pour ouvrir votre espace de gestion dans de bonnes conditions.":
        "Preparing the database, interface, and controls to open your workspace.",
    "Vérification indisponible; démarrage de l'application…":
        "Update check unavailable; starting the application…",
    "Vérification terminée. Chargement…": "Update check complete. Loading…",
    "Version {version} disponible. Chargement…":
        "Version {version} available. Loading…",
    "Version {version} disponible. Cliquez sur « Vérifier les mises à jour » pour l'installer.":
        "Version {version} available. Click “Check for Updates” to install it.",
    "POINTAGE": "ATTENDANCE",
    "Déconnexion": "Log out",
    "Actualiser": "Refresh",
    "Derniers pointages du jour": "Latest attendance today",
    "Employés actifs": "Active Employees",
    "Présents aujourd'hui": "Present Today",
    "Sans pointage": "No Attendance",
    "En retard": "Late",
    "Pointages ouverts": "Open Attendance",
    "Heure": "Time",
    "Matricule": "Employee ID",
    "Employé": "Employee",
    "Service": "Department",
    "Pointage": "Attendance",
    "Activer / désactiver": "Enable / Disable",
    "Ajouter un service": "Add Department",
    "ID": "ID",
    "Code": "Code",
    "Nom": "Name",
    "Description": "Description",
    "Statut": "Status",
    "Changer le statut": "Change Status",
    "Ajouter": "Add",
    "Identifiant": "Identifier",
    "Emplacement": "Location",
    "Type": "Type",
    "Dernière activité": "Last Activity",
    "QR Code": "QR Code",
    "Empreinte (matériel futur)": "Fingerprint (future hardware)",
    "QR + empreinte": "QR + Fingerprint",
    "Actif": "Active",
    "Désactivé": "Disabled",
    "Inactif": "Inactive",
    "Maintenance": "Maintenance",
    "Créer un horaire": "Create Schedule",
    "Jour": "Day",
    "Début": "Start",
    "Fin": "End",
    "Pause": "Break",
    "Tolérance": "Grace Period",
    "Du": "From",
    "Au": "To",
    "Oui": "Yes",
    "Non": "No",
    "Créer un utilisateur": "Create User",
    "Nom d'utilisateur": "Username",
    "Rôle": "Role",
    "Activer / désactiver l'utilisateur": "Enable / Disable User",
    "Configurer permissions": "Configure Permissions",
    "Créer un rôle": "Create Role",
    "Système": "System",
    "Permissions": "Permissions",
    "Générer": "Generate",
    "Exporter CSV": "Export CSV",
    "Corriger le pointage": "Correct Attendance",
    "Date": "Date",
    "Entrée": "Check-in",
    "Sortie": "Check-out",
    "Durée (min)": "Duration (min)",
    "Retard (min)": "Late (min)",
    "Anticipé (min)": "Early Departure (min)",
    "Supplémentaire (min)": "Overtime (min)",
    "Date et heure": "Date and Time",
    "Action": "Action",
    "Type d'objet": "Object Type",
    "Identifiant": "Identifier",
    "Résultat": "Result",
    "Détails": "Details",
    "Sauvegarder la base": "Back Up Database",
    "Enregistrer": "Save",
    "Vérifier les mises à jour": "Check for Updates",
    "Nom de l'organisation": "Organization Name",
    "Fuseau horaire": "Time Zone",
    "Base de données": "Database",
    "Paramètres enregistrés.": "Settings saved.",
    "Identification": "Identification",
    "Empreinte": "Fingerprint",
    "QR actif — caméra utilisée après action de l'utilisateur.":
        "QR enabled — camera starts only after user action.",
    "Architecture préparée, lecteur matériel non configuré.":
        "Architecture prepared; fingerprint reader not configured.",
    "Langue": "Language",
    "Français": "French",
    "Anglais": "English",
    "Les changements de langue sont appliqués immédiatement.":
        "Language changes apply immediately.",
    "Annuler": "Cancel",
    "Paramètres enregistrés.": "Settings saved.",
    "Prénom": "First Name",
    "Prénom *": "First Name *",
    "Nom *": "Last Name *",
    "Poste": "Job Title",
    "Téléphone": "Phone",
    "Date d'embauche (AAAA-MM-JJ)": "Hire Date (YYYY-MM-DD)",
    "Rechercher nom, prénom ou matricule": "Search first name, last name, or employee ID",
    "Carte QR": "QR Card",
    "Modifier": "Edit",
    "Carte QR": "QR Card",
    "Aucun service": "No Department",
    "Nouvel employé": "New Employee",
    "Modifier l'employé": "Edit Employee",
    "Date invalide": "Invalid Date",
    "Utilisez le format AAAA-MM-JJ.": "Use the YYYY-MM-DD format.",
    "Enregistrer la carte QR": "Save QR Card",
    "Carte enregistrée": "Card saved",
    "Utilisateur supprimé": "Deleted User",
    "Filtrer par action (ex. LOGIN)": "Filter by action (e.g. LOGIN)",
    "Du (AAAA-MM-JJ)": "From (YYYY-MM-DD)",
    "Au (AAAA-MM-JJ)": "To (YYYY-MM-DD)",
    "Entrée (HH:MM)": "Check-in (HH:MM)",
    "Sortie enregistrée": "Check-out recorded",
    "Sortie (HH:MM)": "Check-out (HH:MM)",
    "Motif": "Reason",
    "Statut impossible à modifier": "Unable to change status",
    "Création impossible": "Unable to create",
    "Modification impossible": "Unable to edit",
    "Sélectionnez une ligne.": "Select a row.",
    "Sélectionnez un employé.": "Select an employee.",
    "Sélectionnez un service.": "Select a department.",
    "Nom de l'organisation": "Organization Name",
    "Code": "Code",
    "Code": "Code",
    "Ajouter un employé": "Add Employee",
    "QR actif — caméra utilisée après action de l'utilisateur.":
        "QR enabled — camera starts only after user action.",
    "La lecture caméra nécessite OpenCV. Installez les dépendances du projet.":
        "Camera scanning requires OpenCV. Install the project dependencies.",
    "La caméra ne peut pas être ouverte. Vérifiez son branchement et ses autorisations.":
        "The camera could not be opened. Check its connection and permissions.",
    "Aucune pointeuse QR active n'est configurée.":
        "No active QR device is configured.",
    "Scannez ou saisissez un identifiant QR.":
        "Scan or enter a QR identifier.",
    "L'entrée et la sortie sont déjà enregistrées aujourd'hui.":
        "Check-in and check-out have already been recorded today.",
    "Entrée enregistrée": "Check-in recorded",
    "Sortie enregistrée": "Check-out recorded",
    "Pointage non enregistré": "Attendance not recorded",
    "Impossible de charger les pointeuses": "Unable to load devices",
    "La lecture vidéo a échoué.": "Video capture failed.",
    "Caméra indisponible": "Camera unavailable",
    "Les mots de passe ne correspondent pas.": "Passwords do not match.",
    "Vérification": "Verification",
    "Connexion impossible": "Unable to log in",
    "Date d'effet (AAAA-MM-JJ)": "Effective Date (YYYY-MM-DD)",
    "Début (HH:MM)": "Start (HH:MM)",
    "Fin (HH:MM)": "End (HH:MM)",
    "Pause (minutes)": "Break (minutes)",
    "Tolérance (minutes)": "Grace Period (minutes)",
    "Créer d'abord un employé actif.": "Create an active employee first.",
    "Aucune donnée à exporter.": "There is no data to export.",
    "Exporter le rapport": "Export Report",
    "Export terminé": "Export complete",
    "Les permissions du rôle système ne peuvent pas être modifiées.":
        "Permissions for the system role cannot be changed.",
    "Nouvelle pointeuse": "New Device",
    "Nouvelle pointeuse": "New Device",
    "Nouvelle pointeuse": "New Device",
    "Statut de la pointeuse": "Device Status",
    "Nom d'utilisateur": "Username",
    "Mot de passe (12 caractères min.)": "Password (at least 12 characters)",
    "Employés actifs": "Active Employees",
    "Fichier CSV": "CSV File",
    "Scannez le QR code ou saisissez l'identifiant de l'employé":
        "Scan a QR code or enter the employee ID",
    "Pointeuse QR": "QR Device",
    "Identifiant QR": "QR Identifier",
    "Démarrer la caméra": "Start Camera",
    "Arrêter la caméra": "Stop Camera",
    "Pointer": "Clock In/Out",
    "Caméra arrêtée": "Camera stopped",
    "Prêt à pointer": "Ready to clock in/out",
    "Aucune pointeuse QR active": "No active QR device",
    "Nom d'utilisateur": "Username",
    "Mot de passe": "Password",
    "Confirmation": "Confirm Password",
    "12 caractères minimum": "At least 12 characters",
    "Créer le compte administrateur": "Create Administrator Account",
    "Se connecter": "Log In",
    "GESTION DES PRÉSENCES": "ATTENDANCE MANAGEMENT",
    "Gestion des présences": "Attendance Management",
    "Connexion — Gestion des présences": "Log In — Attendance Management",
    "Créer l'administrateur initial": "Create Initial Administrator",
    "DES PRÉSENCES": "ATTENDANCE",
    "Connexion": "Log In",
    "Accès sécurisé à votre espace de gestion des présences.":
        "Secure access to your attendance management workspace.",
    "Bienvenue dans votre espace": "Welcome to your workspace",
    "Gérez les présences, les horaires et les équipes dans un espace simple, sécurisé et centralisé.":
        "Manage attendance, schedules, and teams in one simple, secure, centralized workspace.",
    "Créez le compte administrateur initial pour commencer.":
        "Create the initial administrator account to get started.",
    "Connexion sécurisée à votre espace de gestion.":
        "Securely log in to your workspace.",
    "Enregistrer les paramètres avant de quitter la page.":
        "Save settings before leaving this page.",
}

_ENGLISH_TO_FRENCH = {english: french for french, english in _TRANSLATIONS.items()}
_language = "fr"


def set_language(language: str) -> None:
    global _language
    if language not in SUPPORTED_LANGUAGES:
        raise ValueError(f"Unsupported language: {language}")
    _language = language


def get_language() -> str:
    return _language


def translate(text: str, language: str | None = None) -> str:
    target = language or _language
    if target == "en":
        return _TRANSLATIONS.get(text, text)
    if target == "fr":
        return _ENGLISH_TO_FRENCH.get(text, text)
    raise ValueError(f"Unsupported language: {target}")


def localize_widget_tree(widget, language: str | None = None) -> None:
    target = language or _language
    try:
        if isinstance(widget, (tk.Tk, tk.Toplevel)):
            title = widget.title()
            if title:
                widget.title(translate(title, target))
        if isinstance(widget, (ttk.Label, ttk.Button, ttk.LabelFrame, ttk.Checkbutton)):
            text = widget.cget("text")
            if text:
                widget.configure(text=translate(text, target))
        if isinstance(widget, ttk.Treeview):
            for column in widget.cget("columns"):
                heading = widget.heading(column, "text")
                if heading:
                    widget.heading(column, text=translate(heading, target))
        if isinstance(widget, ttk.Combobox):
            current_values = tuple(widget.cget("values"))
            known_language_labels = {
                translate(label, candidate)
                for label in SUPPORTED_LANGUAGES.values()
                for candidate in SUPPORTED_LANGUAGES
            }
            if current_values and all(value in known_language_labels
                                      for value in current_values):
                widget.configure(
                    values=tuple(translate(value, target) for value in current_values)
                )
    except TclError:
        pass
    for child in widget.winfo_children():
        localize_widget_tree(child, target)
