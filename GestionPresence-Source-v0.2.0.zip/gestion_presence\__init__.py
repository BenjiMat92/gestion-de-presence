"""Application de gestion des présences."""
