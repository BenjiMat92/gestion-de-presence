$ErrorActionPreference = "Stop"

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $root

$python = Join-Path $root ".venv\Scripts\python.exe"
if (-not (Test-Path -LiteralPath $python)) {
    throw "L'environnement Python du projet est absent. Créez .venv et installez requirements-dev.txt."
}

$versionSource = Get-Content -LiteralPath (Join-Path $root "gestion_presence\version.py") -Raw
if ($versionSource -notmatch '__version__\s*=\s*"(\d+\.\d+\.\d+)"') {
    throw "Impossible de lire la version semver depuis gestion_presence\version.py."
}
$version = $Matches[1]

& $python -m PyInstaller --noconfirm --clean --onefile --windowed `
    --name GestionPresences `
    --collect-all cv2 `
    --collect-all sqlalchemy `
    --collect-data tzdata `
    run_app.py
if ($LASTEXITCODE -ne 0) {
    throw "La génération PyInstaller a échoué (code $LASTEXITCODE)."
}

$compilerCandidates = @(
    (Join-Path ${env:ProgramFiles(x86)} "Inno Setup 6\ISCC.exe"),
    (Join-Path $env:ProgramFiles "Inno Setup 6\ISCC.exe"),
    (Join-Path $env:LOCALAPPDATA "Programs\Inno Setup 6\ISCC.exe")
)
$compilerCommand = Get-Command "ISCC.exe" -ErrorAction SilentlyContinue
$compiler = $compilerCandidates |
    Where-Object { $_ -and (Test-Path -LiteralPath $_) } |
    Select-Object -First 1
if (-not $compiler -and $compilerCommand) {
    $compiler = $compilerCommand.Source
}
if (-not $compiler) {
    throw "Inno Setup 6 (ISCC.exe) est requis. Installez-le avec winget install --id JRSoftware.InnoSetup --exact."
}

& $compiler "/DAppVersion=$version" (Join-Path $root "installer.iss")
if ($LASTEXITCODE -ne 0) {
    throw "La génération Inno Setup a échoué (code $LASTEXITCODE)."
}

$installer = Join-Path $root "dist\GestionPresence-Setup.exe"
if (-not (Test-Path -LiteralPath $installer)) {
    throw "Le compilateur n'a pas généré l'installateur attendu : $installer"
}
$hash = (Get-FileHash -LiteralPath $installer -Algorithm SHA256).Hash.ToLowerInvariant()
"$hash  GestionPresence-Setup.exe" |
    Set-Content -LiteralPath "$installer.sha256" -Encoding ascii
Write-Host "Installateur version $version créé : $installer"
Write-Host "SHA-256 : $hash"
