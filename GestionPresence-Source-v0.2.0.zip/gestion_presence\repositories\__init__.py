"""Accès aux données par domaine."""
