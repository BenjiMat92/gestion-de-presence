"""Enregistrement et activation des appareils de pointage."""

from sqlalchemy import select
from sqlalchemy.orm import Session

from gestion_presence.database.models import AuditLog, Device
from gestion_presence.errors import EntityNotFound, ValidationError
from gestion_presence.services.rbac import RbacService


class DeviceService:
    @staticmethod
    def create(
        session: Session,
        *,
        actor_user_id: int,
        device_code: str,
        name: str,
        location: str | None = None,
        device_type: str = "qr",
    ) -> Device:
        RbacService.require_permission(session, actor_user_id, "device.create")
        if device_type not in {"qr", "fingerprint", "mixed"}:
            raise ValidationError(f"Type d'appareil invalide : {device_type}")
        device_code = device_code.strip()
        name = name.strip()
        if not device_code or not name:
            raise ValidationError("L'identifiant et le nom de la pointeuse sont obligatoires.")
        device = Device(
            device_code=device_code,
            name=name,
            location=location.strip() if location else None,
            device_type=device_type,
        )
        session.add(device)
        session.flush()
        session.add(
            AuditLog(
                user_id=actor_user_id,
                action="CREATE_DEVICE",
                entity_type="device",
                entity_id=device.device_code,
            )
        )
        session.flush()
        return device

    @staticmethod
    def list_active(session: Session, *, actor_user_id: int) -> list[Device]:
        RbacService.require_permission(session, actor_user_id, "device.view")
        return list(
            session.scalars(
                select(Device)
                .where(Device.status == "active")
                .order_by(Device.name)
            )
        )

    @staticmethod
    def list_all(session: Session, *, actor_user_id: int) -> list[Device]:
        RbacService.require_permission(session, actor_user_id, "device.view")
        return list(session.scalars(select(Device).order_by(Device.device_code)))

    @staticmethod
    def set_status(
        session: Session,
        device_id: int,
        *,
        actor_user_id: int,
        status: str,
    ) -> Device:
        RbacService.require_permission(session, actor_user_id, "device.update")
        if status not in {"active", "inactive", "maintenance"}:
            raise ValidationError(f"Statut d'appareil invalide : {status}")
        device = session.get(Device, device_id)
        if device is None:
            raise EntityNotFound(f"Pointeuse introuvable (id={device_id}).")
        device.status = status
        session.add(
            AuditLog(
                user_id=actor_user_id,
                action="UPDATE_DEVICE_STATUS",
                entity_type="device",
                entity_id=device.device_code,
                details={"status": status},
            )
        )
        session.flush()
        return device
