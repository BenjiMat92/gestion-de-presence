from datetime import date, datetime, time, timezone
from logging import INFO
import sqlite3
from zoneinfo import ZoneInfo

import pytest
from sqlalchemy import select
from sqlalchemy.orm import Session

from gestion_presence.application import initialize_application
from gestion_presence.config import Settings
from gestion_presence.database.connection import create_database, create_engine
from gestion_presence.database.models import (
    Attendance,
    AuditLog,
    Device,
    Employee,
    Role,
    User,
    WorkSchedule,
)
from gestion_presence.errors import (
    AttendanceConflict,
    AuthenticationFailed,
    DeviceUnavailable,
    InactiveEmployee,
    PermissionDenied,
    UnknownEmployee,
)
from gestion_presence.services.attendance import AttendanceService
from gestion_presence.services.authentication import AuthenticationService
from gestion_presence.services.backups import BackupService
from gestion_presence.services.devices import DeviceService
from gestion_presence.services.employees import EmployeeService
from gestion_presence.services.rbac import RbacService
from gestion_presence.services.work_schedules import WorkScheduleService

KINSHASA = ZoneInfo("Africa/Kinshasa")


@pytest.fixture
def engine():
    test_engine = create_engine("sqlite:///:memory:")
    create_database(test_engine)
    yield test_engine
    test_engine.dispose()


@pytest.fixture
def session_with_admin(engine):
    with Session(engine) as session:
        with session.begin():
            admin = AuthenticationService.bootstrap_first_administrator(
                session,
                username="admin",
                password="a secure test password",
            )
        yield session, admin.id


def test_application_initializes_and_connects_to_sqlite(tmp_path):
    database_url = create_engine(
        f"sqlite:///{(tmp_path / 'data' / 'startup.db').as_posix()}"
    ).url
    settings = Settings(
        database_url=database_url,
        timezone=KINSHASA,
        log_level=INFO,
    )

    application_engine = initialize_application(settings)
    try:
        with application_engine.connect() as connection:
            assert connection.exec_driver_sql("SELECT 1").scalar_one() == 1
        assert (tmp_path / "data" / "startup.db").is_file()
    finally:
        application_engine.dispose()


def test_bootstrap_authentication_and_password_storage(session_with_admin):
    session, admin_id = session_with_admin
    admin = session.get(User, admin_id)

    assert admin is not None
    assert admin.password_hash != "a secure test password"
    assert AuthenticationService.authenticate(
        session,
        username="admin",
        password="a secure test password",
        now=datetime(2026, 10, 3, 8, 0, tzinfo=timezone.utc),
    ).id == admin_id
    assert admin.last_login_at == datetime(2026, 10, 3, 8, 0)
    assert session.scalar(select(AuditLog).where(AuditLog.action == "LOGIN")) is not None
    with pytest.raises(AuthenticationFailed):
        AuthenticationService.authenticate(
            session, username="admin", password="incorrect password"
        )

    with pytest.raises(Exception, match="initial"):
        AuthenticationService.bootstrap_first_administrator(
            session, username="another", password="a secure test password"
        )


def test_employee_crud_uses_permissions_and_soft_deactivation(session_with_admin):
    session, admin_id = session_with_admin

    department_employee = EmployeeService.create(
        session,
        actor_user_id=admin_id,
        first_name=" Jean ",
        last_name=" Kabila ",
    )
    assert department_employee.first_name == "Jean"
    assert department_employee.employee_code.startswith("EMP-")
    assert EmployeeService.search(
        session, actor_user_id=admin_id, query=department_employee.employee_code
    ) == [department_employee]

    unprivileged = User(username="lecture-limitee", password_hash="hashed-placeholder")
    session.add(unprivileged)
    session.flush()
    with pytest.raises(PermissionDenied):
        EmployeeService.create(
            session,
            actor_user_id=unprivileged.id,
            first_name="Sans",
            last_name="Droit",
        )

    deactivated = EmployeeService.deactivate(
        session, department_employee.id, actor_user_id=admin_id
    )
    assert not deactivated.is_active
    assert EmployeeService.search(session, actor_user_id=admin_id) == []
    assert EmployeeService.search(
        session, actor_user_id=admin_id, include_inactive=True
    ) == [department_employee]


def test_clock_in_out_calculates_lateness_work_and_overtime(session_with_admin):
    session, admin_id = session_with_admin
    employee = EmployeeService.create(
        session,
        actor_user_id=admin_id,
        first_name="Jean",
        last_name="Kabila",
    )
    device = DeviceService.create(
        session,
        actor_user_id=admin_id,
        device_code="DEVICE-001",
        name="Entrée principale",
    )
    WorkScheduleService.create(
        session,
        actor_user_id=admin_id,
        employee_id=employee.id,
        name="Horaire standard",
        day_of_week=0,
        start_time=time(8),
        end_time=time(16),
        effective_from=date(2026, 1, 1),
        break_minutes=30,
        grace_period_minutes=5,
    )
    settings = Settings(
        database_url=create_engine("sqlite://").url,
        timezone=KINSHASA,
        log_level=INFO,
    )

    entry = AttendanceService.clock_in(
        session,
        employee_code=employee.employee_code,
        actor_user_id=admin_id,
        settings=settings,
        device_code=device.device_code,
        at=datetime(2026, 10, 5, 7, 17, tzinfo=timezone.utc),
    )
    assert entry.attendance_date == date(2026, 10, 5)
    assert entry.check_in_at == datetime(2026, 10, 5, 7, 17)
    assert entry.late_minutes == 12
    assert entry.device_id == device.id

    completed = AttendanceService.clock_out(
        session,
        employee_code=employee.employee_code,
        actor_user_id=admin_id,
        settings=settings,
        device_code=device.device_code,
        at=datetime(2026, 10, 5, 15, 30, tzinfo=timezone.utc),
    )
    assert completed.status == "completed"
    assert completed.worked_minutes == 463
    assert completed.early_departure_minutes == 0
    assert completed.overtime_minutes == 30
    assert len(
        AttendanceService.daily_report(
            session,
            actor_user_id=admin_id,
            attendance_date=date(2026, 10, 5),
        )
    ) == 1
    assert session.scalar(select(AuditLog).where(AuditLog.action == "CLOCK_IN"))
    assert session.scalar(select(AuditLog).where(AuditLog.action == "CLOCK_OUT"))

    with pytest.raises(AttendanceConflict, match="déjà enregistrées"):
        AttendanceService.clock_in(
            session,
            employee_code=employee.employee_code,
            actor_user_id=admin_id,
            settings=settings,
            device_code=device.device_code,
            at=datetime(2026, 10, 5, 16, 0, tzinfo=timezone.utc),
        )
    with pytest.raises(AttendanceConflict, match="Aucune entrée"):
        AttendanceService.clock_out(
            session,
            employee_code=employee.employee_code,
            actor_user_id=admin_id,
            settings=settings,
            device_code=device.device_code,
            at=datetime(2026, 10, 5, 16, 0, tzinfo=timezone.utc),
        )


def test_attendance_identification_and_employee_errors_are_explicit(
    session_with_admin,
):
    session, admin_id = session_with_admin
    settings = Settings(
        database_url=create_engine("sqlite://").url,
        timezone=KINSHASA,
        log_level=INFO,
    )
    with pytest.raises(UnknownEmployee):
        AttendanceService.clock_in(
            session,
            employee_code="EMP-UNKNOWN",
            actor_user_id=admin_id,
            settings=settings,
            device_code="DEVICE-001",
            at=datetime(2026, 10, 3, 7, 0, tzinfo=timezone.utc),
        )

    employee = EmployeeService.create(
        session,
        actor_user_id=admin_id,
        first_name="Employé",
        last_name="Désactivé",
    )
    employee.is_active = False
    session.flush()
    session.add(
        Device(
            device_code="DEVICE-INACTIVE",
            name="Pointeuse inactive",
            status="inactive",
        )
    )
    session.flush()
    with pytest.raises(InactiveEmployee):
        AttendanceService.clock_in(
            session,
            employee_code=employee.employee_code,
            actor_user_id=admin_id,
            settings=settings,
            device_code="DEVICE-INACTIVE",
            at=datetime(2026, 10, 3, 7, 0, tzinfo=timezone.utc),
        )

    employee.is_active = True
    session.flush()
    with pytest.raises(DeviceUnavailable):
        AttendanceService.clock_in(
            session,
            employee_code=employee.employee_code,
            actor_user_id=admin_id,
            settings=settings,
            device_code="DEVICE-INACTIVE",
            at=datetime(2026, 10, 3, 7, 0, tzinfo=timezone.utc),
        )


def test_work_schedules_reject_overlapping_effective_periods(session_with_admin):
    session, admin_id = session_with_admin
    employee = EmployeeService.create(
        session,
        actor_user_id=admin_id,
        first_name="Marie",
        last_name="Kabeya",
    )
    schedule_values = {
        "actor_user_id": admin_id,
        "employee_id": employee.id,
        "name": "Horaire",
        "day_of_week": 0,
        "start_time": time(8),
        "end_time": time(16),
        "effective_from": date(2026, 1, 1),
    }
    WorkScheduleService.create(session, **schedule_values)
    with pytest.raises(Exception, match="horaire actif"):
        WorkScheduleService.create(
            session,
            **{**schedule_values, "effective_from": date(2026, 6, 1)},
        )
    assert session.scalar(select(WorkSchedule)).employee_id == employee.id


def test_sqlite_backup_creates_readable_database_and_records_audit(tmp_path):
    source_path = tmp_path / "source.db"
    backup_path = tmp_path / "backup" / "attendance-copy.db"
    source_engine = create_engine(
        f"sqlite:///{source_path.as_posix()}"
    )
    create_database(source_engine)
    try:
        with Session(source_engine) as session, session.begin():
            admin = AuthenticationService.bootstrap_first_administrator(
                session,
                username="admin",
                password="a secure test password",
            )
            admin_id = admin.id

        with Session(source_engine) as session, session.begin():
            saved_path = BackupService.create(
                session,
                actor_user_id=admin_id,
                destination=backup_path,
            )
            assert saved_path == backup_path.resolve()

        with sqlite3.connect(backup_path) as backup:
            user_count = backup.execute("SELECT COUNT(*) FROM users").fetchone()[0]
            audit_count = backup.execute("SELECT COUNT(*) FROM audit_logs").fetchone()[0]
        assert user_count == 1
        assert audit_count == 1
    finally:
        source_engine.dispose()
