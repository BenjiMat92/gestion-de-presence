"""Interface graphique Tkinter."""
