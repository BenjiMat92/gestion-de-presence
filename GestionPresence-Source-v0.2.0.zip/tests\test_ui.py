import tkinter as tk
from logging import INFO as LOG_INFO
from zoneinfo import ZoneInfo

import pytest
from sqlalchemy.orm import Session

from gestion_presence.config import Settings
from gestion_presence.database.connection import create_database, create_engine
from gestion_presence.database.models import (
    Permission,
    Role,
    RolePermission,
    Setting,
    User,
    UserRole,
)
from gestion_presence.database.session import create_session_factory
from gestion_presence.services.authentication import AuthenticationService
from gestion_presence.ui import admin_pages
from gestion_presence.ui import main_window as main_window_module
from gestion_presence.ui.login_dialog import LoginDialog
from gestion_presence.ui.admin_pages import SettingsPage
from gestion_presence.ui.main_window import MainWindow
from gestion_presence.i18n import LANGUAGE_SETTING_KEY, get_language, set_language
from gestion_presence.services.updates import UpdateRelease


@pytest.fixture(scope="module")
def tk_root():
    root = tk.Tk()
    root.withdraw()
    yield root
    try:
        root.destroy()
    except tk.TclError:
        pass


@pytest.fixture
def engine():
    test_engine = create_engine("sqlite:///:memory:")
    create_database(test_engine)
    yield test_engine
    test_engine.dispose()


@pytest.fixture
def admin_session_factory(engine):
    with Session(engine) as session, session.begin():
        AuthenticationService.bootstrap_first_administrator(
            session, username="admin", password="StrongTestPass2026!"
        )
    return create_session_factory(engine)


def test_login_dialog_shows_first_account_setup_when_database_is_empty(tk_root, engine):
    dialog = LoginDialog(tk_root, create_session_factory(engine))
    assert dialog.first_user
    assert "administrateur initial" in dialog.window.title().lower()
    dialog.window.update_idletasks()
    assert dialog.window.geometry().split("+")[0] == "1160x760"
    assert dialog.username_entry.winfo_exists()
    assert dialog.submit_button.cget("text") == "Créer le compte administrateur"
    dialog.window.destroy()


def test_main_window_builds_rbac_navigation_and_all_registered_pages(
    tk_root, admin_session_factory,
):
    with admin_session_factory() as session:
        admin = session.query(User).filter_by(username="admin").one()
        admin_id = admin.id
    memory_engine = create_engine("sqlite://")
    settings = Settings(
        database_url=memory_engine.url,
        timezone=ZoneInfo("Africa/Kinshasa"),
        log_level=LOG_INFO,
    )

    window = MainWindow(tk_root, admin_session_factory, settings, admin_id)
    window.withdraw()
    try:
        assert len(window.navigation_buttons) == 11
        assert len(window.pages_by_key) == 11
        assert window.navigation_buttons[1].cget("text") == "Pointage QR"
        assert "settings" in window.pages_by_key
        settings_page = window.pages_by_key["settings"]
        assert settings_page.update_button.cget("text") == "Vérifier les mises à jour"
        assert settings_page.language_selector is not None
        assert tuple(settings_page.language_selector.cget("values")) == (
            "Français", "Anglais"
        )
        settings_page.language.set("Anglais")
        settings_page._language_selected()
        assert window.navigation_buttons[0].cget("text") == "Dashboard"
        assert settings_page.update_button.cget("text") == "Check for Updates"
        settings_page.language.set("Français")
        settings_page._language_selected()
        assert window.navigation_buttons[0].cget("text") == "Tableau de bord"
    finally:
        window.destroy()
        memory_engine.dispose()


def test_settings_language_is_saved_and_applied(tk_root, admin_session_factory,
                                                 monkeypatch):
    with admin_session_factory() as session:
        admin_id = session.query(User).filter_by(username="admin").one().id

    memory_engine = create_engine("sqlite://")
    settings = Settings(
        database_url=memory_engine.url,
        timezone=ZoneInfo("Africa/Kinshasa"),
        log_level=LOG_INFO,
    )
    page = SettingsPage(tk_root, admin_session_factory, settings, admin_id)
    monkeypatch.setattr(admin_pages.messagebox, "showinfo", lambda *_args, **_kwargs: None)
    try:
        page.language.set("Anglais")
        page.save()

        assert get_language() == "en"
        with admin_session_factory() as session:
            saved_language = session.get(Setting, LANGUAGE_SETTING_KEY)
            assert saved_language is not None
            assert saved_language.value == "en"
        assert page.title_label.cget("text") == "Settings"
    finally:
        set_language("fr")
        page.destroy()
        memory_engine.dispose()


def test_update_control_is_hidden_and_guarded_for_non_admin(
    tk_root, admin_session_factory, monkeypatch
):
    with admin_session_factory() as session, session.begin():
        admin = session.query(User).filter_by(username="admin").one()
        role = Role(name="RH", description="Ressources humaines")
        user = User(username="rh", password_hash="not-used")
        session.add_all([role, user])
        session.flush()
        permission = session.query(Permission).filter_by(name="settings.view").one()
        session.add_all([
            UserRole(user_id=user.id, role_id=role.id, assigned_by=admin.id),
            RolePermission(role_id=role.id, permission_id=permission.id),
        ])
        user_id = user.id

    memory_engine = create_engine("sqlite://")
    settings = Settings(
        database_url=memory_engine.url,
        timezone=ZoneInfo("Africa/Kinshasa"),
        log_level=LOG_INFO,
    )
    page = SettingsPage(tk_root, admin_session_factory, settings, user_id)
    monkeypatch.setattr(
        admin_pages.messagebox,
        "showerror",
        lambda *_args, **_kwargs: None,
    )
    started_threads = []

    class UnexpectedThread:
        def __init__(self, *_args, **_kwargs):
            started_threads.append(self)

        def start(self):
            started_threads.append("started")

    monkeypatch.setattr(admin_pages.threading, "Thread", UnexpectedThread)
    try:
        assert page.update_button is None
        page.check_for_updates()
        assert page.update_status.get() == ""
        assert started_threads == []
    finally:
        page.destroy()
        memory_engine.dispose()


def test_startup_shows_loading_and_checks_for_updates_before_login(
    tk_root, admin_session_factory, monkeypatch
):
    release = UpdateRelease(
        version="0.2.0",
        title="Release",
        page_url="https://github.com/example/repository/releases/tag/v0.2.0",
        notes="",
        installer_asset_id=1,
        installer_size=10,
        checksum_asset_id=2,
    )
    checks = []
    constructed_windows = []

    def check_for_update():
        checks.append(True)
        return release

    class FakeLoginDialog:
        def __init__(self, parent, _session_factory):
            self.user_id = 1
            self.window = tk.Toplevel(parent)
            self.window.after(1, self.window.destroy)

    class FakeMainWindow:
        def __init__(
            self, parent, _session_factory, _settings, _user_id, *, startup_update
        ):
            self.logout_requested = False
            self.startup_update = startup_update
            self.window = tk.Toplevel(parent)
            self.window.after(1, self.window.destroy)
            constructed_windows.append(self)

    monkeypatch.setattr(main_window_module, "check_for_update", check_for_update)
    monkeypatch.setattr(main_window_module, "LoginDialog", FakeLoginDialog)
    monkeypatch.setattr(main_window_module, "MainWindow", FakeMainWindow)
    memory_engine = create_engine("sqlite://")
    settings = Settings(
        database_url=memory_engine.url,
        timezone=ZoneInfo("Africa/Kinshasa"),
        log_level=LOG_INFO,
    )
    try:
        assert main_window_module.launch_desktop(
            settings, admin_session_factory, memory_engine
        ) == 0
        assert checks == [True]
        assert len(constructed_windows) == 1
        assert constructed_windows[0].startup_update == release
    finally:
        memory_engine.dispose()
