"""Connexion et création interactive du premier compte administrateur."""

from tkinter import (
    BOTH,
    LEFT,
    Canvas,
    Entry,
    Frame,
    StringVar,
    Toplevel,
    messagebox,
)
from tkinter import ttk

from sqlalchemy import select
from sqlalchemy.orm import Session, sessionmaker

from gestion_presence.database.models import User
from gestion_presence.errors import ApplicationError
from gestion_presence.i18n import get_language, translate
from gestion_presence.services.authentication import AuthenticationService
from gestion_presence.ui.common import format_error

_COLORS = {
    "background": "#f0f5fb",
    "teal": "#6aaead",
    "teal_dark": "#126d76",
    "navy": "#082e76",
    "blue": "#155386",
    "ink": "#172033",
    "muted": "#74839a",
    "border": "#d7e0eb",
    "button": "#0d625d",
    "button_hover": "#0a514e",
    "hint": "#edf3fa",
    "white": "#ffffff",
}


class LoginDialog:
    def __init__(self, parent, session_factory: sessionmaker[Session]) -> None:
        self.session_factory = session_factory
        self.user_id: int | None = None
        self.language = get_language()
        self.window = Toplevel(parent)
        self.window.title(translate("Connexion — Gestion des présences"))
        self.window.geometry("1160x760")
        self.window.minsize(920, 680)
        self.window.configure(bg=_COLORS["background"])
        self.window.protocol("WM_DELETE_WINDOW", self.window.destroy)
        self.first_user = not self._has_users()

        if self.first_user:
            self.window.title(translate("Créer l'administrateur initial"))

        self.username = StringVar(master=self.window)
        self.password = StringVar(master=self.window)
        self.confirm_password = StringVar(master=self.window)

        self.canvas = Canvas(
            self.window,
            background=_COLORS["background"],
            highlightthickness=0,
        )
        self.canvas.pack(fill=BOTH, expand=True)
        self._draw_background()
        self.card = Frame(self.canvas, background=_COLORS["white"])
        self.card_window = self.canvas.create_window(
            0, 0, window=self.card, anchor="center"
        )
        self._create_card()
        self.canvas.bind("<Configure>", self._layout)
        self.window.bind("<Return>", lambda _event: self.submit())
        self.window.after(50, self._center_window)
        self.username_entry.focus_set()
        self.window.grab_set()

    def _tr(self, text: str) -> str:
        return translate(text, self.language)

    def _draw_background(self) -> None:
        self.canvas.create_oval(
            -260, 45, 570, 875, fill="#70aeac", outline=""
        )
        self.canvas.create_oval(
            -210, 92, 505, 800, fill="#7db8b6", outline=""
        )
        self.canvas.create_oval(
            910, -220, 1570, 480, fill="#f1e2c4", outline=""
        )
        self.canvas.create_oval(
            640, 460, 1500, 1070, fill="#c1d5d5", outline=""
        )
        self.canvas.create_oval(
            1050, -140, 1610, 410, fill="#f6ead4", outline=""
        )

    def _create_card(self) -> None:
        self.card.grid_rowconfigure(0, weight=1)
        self.card.grid_columnconfigure(0, weight=1, uniform="login")
        self.card.grid_columnconfigure(1, weight=1, uniform="login")

        self.art = Canvas(
            self.card,
            width=450,
            height=500,
            background=_COLORS["teal_dark"],
            highlightthickness=0,
        )
        self.art.grid(row=0, column=0, sticky="nsew")
        self.art.bind("<Configure>", self._draw_welcome_panel)

        self.form_panel = Frame(self.card, background=_COLORS["white"], padx=38, pady=24)
        self.form_panel.grid(row=0, column=1, sticky="nsew")
        self.form_panel.grid_columnconfigure(0, weight=1)

        logo = Canvas(
            self.form_panel,
            width=190,
            height=48,
            background=_COLORS["hint"],
            highlightthickness=0,
        )
        logo.grid(row=0, column=0, sticky="w", pady=(0, 15))
        logo.create_oval(12, 11, 44, 43, fill=_COLORS["teal_dark"], outline="")
        logo.create_rectangle(25, 15, 31, 39, fill=_COLORS["white"], outline="")
        logo.create_rectangle(16, 24, 40, 30, fill=_COLORS["white"], outline="")
        logo.create_text(
            54,
            22,
            text="GESTION",
            anchor="w",
            fill=_COLORS["navy"],
            font=("Segoe UI", 10, "bold"),
        )
        logo.create_text(
            54,
            37,
            text=self._tr("DES PRÉSENCES"),
            anchor="w",
            fill=_COLORS["muted"],
            font=("Segoe UI", 7, "bold"),
        )

        heading_text = (
            "Créer l'administrateur initial" if self.first_user else "Connexion"
        )
        ttk.Label(
            self.form_panel,
            text=self._tr(heading_text),
            font=("Segoe UI", 23, "bold"),
            foreground=_COLORS["ink"],
            background=_COLORS["white"],
        ).grid(row=1, column=0, sticky="w", pady=(0, 4))
        ttk.Label(
            self.form_panel,
            text=self._tr(
                "Accès sécurisé à votre espace de gestion des présences."
            ),
            wraplength=370,
            foreground=_COLORS["muted"],
            background=_COLORS["white"],
            font=("Segoe UI", 9),
        ).grid(row=2, column=0, sticky="w", pady=(0, 18))

        self._add_field("Nom d'utilisateur", self.username, row=3)
        self.username_entry = self._last_entry
        self._add_field("Mot de passe", self.password, row=5, secret=True)
        if self.first_user:
            self._add_field("Confirmation", self.confirm_password, row=7, secret=True)
            ttk.Label(
                self.form_panel,
                text=self._tr("12 caractères minimum"),
                foreground=_COLORS["muted"],
                background=_COLORS["white"],
                font=("Segoe UI", 8),
            ).grid(row=9, column=0, sticky="w", pady=(0, 8))
            button_row = 10
            button_text = "Créer le compte administrateur"
        else:
            button_row = 7
            button_text = "Se connecter"

        self.submit_button = ttk.Button(
            self.form_panel,
            text=self._tr(button_text),
            command=self.submit,
            style="Login.Primary.TButton",
        )
        style = ttk.Style(self.window)
        style.configure(
            "Login.Primary.TButton",
            background=_COLORS["button"],
            foreground=_COLORS["white"],
            padding=(12, 11),
            font=("Segoe UI", 10, "bold"),
            borderwidth=0,
        )
        style.map(
            "Login.Primary.TButton",
            background=[("active", _COLORS["button_hover"])],
            foreground=[("active", _COLORS["white"])],
        )
        self.submit_button.grid(row=button_row, column=0, sticky="ew", pady=(7, 12))

        hint_text = (
            "Créez le compte administrateur initial pour commencer."
            if self.first_user
            else "Connexion sécurisée à votre espace de gestion."
        )
        self.hint = ttk.Label(
            self.form_panel,
            text=self._tr(hint_text),
            background=_COLORS["hint"],
            foreground=_COLORS["muted"],
            padding=(12, 11),
            wraplength=350,
            font=("Segoe UI", 8),
        )
        self.hint.grid(row=button_row + 1, column=0, sticky="ew", pady=(0, 2))

    def _add_field(
        self, label: str, variable: StringVar, *, row: int, secret: bool = False
    ) -> None:
        ttk.Label(
            self.form_panel,
            text=self._tr(label),
            foreground="#48566d",
            background=_COLORS["white"],
            font=("Segoe UI", 9),
        ).grid(row=row, column=0, sticky="w", pady=(0, 5))
        entry = Entry(
            self.form_panel,
            textvariable=variable,
            show="*" if secret else "",
            relief="solid",
            bd=1,
            highlightthickness=1,
            highlightbackground=_COLORS["border"],
            highlightcolor=_COLORS["teal_dark"],
            background=_COLORS["white"],
            foreground=_COLORS["ink"],
            insertbackground=_COLORS["ink"],
            font=("Segoe UI", 10),
        )
        entry.grid(row=row + 1, column=0, sticky="ew", ipady=8, pady=(0, 12))
        self._last_entry = entry

    def _draw_welcome_panel(self, _event=None) -> None:
        width = max(self.art.winfo_width(), 1)
        height = max(self.art.winfo_height(), 1)
        self.art.delete("all")
        self.art.configure(background=_COLORS["teal_dark"])
        self.art.create_oval(
            -width * 0.18, -height * 0.13, width * 0.96, height * 0.94,
            fill="#0f7780", outline="",
        )
        self.art.create_oval(
            width * 0.13, -height * 0.28, width * 0.92, height * 0.47,
            fill=_COLORS["navy"], outline="",
        )
        self.art.create_oval(
            width * 0.02, height * 0.25, width * 1.05, height * 1.28,
            fill="#075276", outline="",
        )
        self.art.create_arc(
            width * 0.06, height * 0.10, width * 0.89, height * 1.14,
            start=38, extent=275, style="arc", outline="#b4a326", width=12,
        )
        self.art.create_arc(
            width * 0.13, height * 0.14, width * 0.82, height * 1.05,
            start=38, extent=275, style="arc", outline="#148681", width=7,
        )
        self.art.create_oval(
            width * 0.09, height * 0.075, width * 0.24, height * 0.17,
            fill=_COLORS["white"], outline="",
        )

        title = self._tr("Bienvenue dans votre espace")
        description = self._tr(
            "Gérez les présences, les horaires et les équipes dans un espace "
            "simple, sécurisé et centralisé."
        )
        self.art.create_text(
            width * 0.10,
            height * 0.57,
            text=title,
            anchor="w",
            width=width * 0.76,
            fill=_COLORS["white"],
            font=("Segoe UI", 23, "bold"),
            justify=LEFT,
        )
        self.art.create_text(
            width * 0.10,
            height * 0.76,
            text=description,
            anchor="w",
            width=width * 0.72,
            fill="#dcebf1",
            font=("Segoe UI", 10),
            justify=LEFT,
        )

    def _layout(self, event) -> None:
        card_width = min(960, max(event.width - 48, 760))
        card_height = min(560, max(event.height - 64, 520))
        self.canvas.coords(
            self.card_window, event.width / 2, event.height / 2
        )
        self.canvas.itemconfigure(
            self.card_window, width=card_width, height=card_height
        )

    def _center_window(self) -> None:
        self.window.update_idletasks()
        width = self.window.winfo_width()
        height = self.window.winfo_height()
        x = (self.window.winfo_screenwidth() - width) // 2
        y = (self.window.winfo_screenheight() - height) // 2
        self.window.geometry(f"{width}x{height}+{x}+{y}")

    def _has_users(self) -> bool:
        with self.session_factory() as session:
            return session.scalar(select(User.id).limit(1)) is not None

    def submit(self) -> None:
        username = self.username.get().strip()
        password = self.password.get()
        if self.first_user and password != self.confirm_password.get():
            messagebox.showwarning(
                self._tr("Vérification"),
                self._tr("Les mots de passe ne correspondent pas."),
                parent=self.window,
            )
            return
        try:
            with self.session_factory() as session, session.begin():
                if self.first_user:
                    user = AuthenticationService.bootstrap_first_administrator(
                        session, username=username, password=password
                    )
                else:
                    user = AuthenticationService.authenticate(
                        session, username=username, password=password
                    )
                self.user_id = user.id
        except ApplicationError as error:
            messagebox.showwarning(
                self._tr("Connexion impossible"),
                self._tr(format_error(error)),
                parent=self.window,
            )
            return
        self.window.destroy()
