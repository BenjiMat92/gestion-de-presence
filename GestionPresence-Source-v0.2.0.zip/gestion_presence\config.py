"""Configuration de l'application, chargée depuis l'environnement."""

from dataclasses import dataclass
import logging
import os
from pathlib import Path
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from sqlalchemy import URL, make_url
from sqlalchemy.exc import ArgumentError

from gestion_presence.errors import ConfigurationError


def _default_database_path() -> Path:
    return Path.home() / ".gestion_presence" / "gestion_presence.db"


@dataclass(frozen=True, slots=True)
class Settings:
    """Paramètres d'exécution, avec variables GESTION_PRESENCE_* facultatives."""

    database_url: URL
    timezone: ZoneInfo
    log_level: int

    @classmethod
    def from_env(cls) -> "Settings":
        raw_path = os.getenv("GESTION_PRESENCE_DATABASE_PATH")
        raw_url = os.getenv("GESTION_PRESENCE_DATABASE_URL")
        if raw_url:
            try:
                database_url = make_url(raw_url)
            except ArgumentError as error:
                raise ConfigurationError("URL de base de données invalide.") from error
            if not database_url.drivername.startswith("sqlite"):
                raise ConfigurationError(
                    "Cette version de l'application utilise uniquement SQLite."
                )
        else:
            database_path = Path(raw_path).expanduser() if raw_path else _default_database_path()
            database_url = URL.create(
                "sqlite", database=str(database_path.expanduser().resolve())
            )

        timezone_name = os.getenv("GESTION_PRESENCE_TIMEZONE", "Africa/Kinshasa")
        try:
            timezone = ZoneInfo(timezone_name)
        except ZoneInfoNotFoundError as error:
            raise ConfigurationError(
                f"Fuseau horaire inconnu : {timezone_name}"
            ) from error

        log_level_name = os.getenv("GESTION_PRESENCE_LOG_LEVEL", "INFO").upper()
        log_level = logging.getLevelName(log_level_name)
        if not isinstance(log_level, int):
            raise ConfigurationError(
                f"Niveau de journalisation invalide : {log_level_name}"
            )

        return cls(
            database_url=database_url,
            timezone=timezone,
            log_level=log_level,
        )

    @property
    def database_path(self) -> Path | None:
        """Renvoie le chemin local si la configuration cible SQLite."""
        if not isinstance(self.database_url, URL):
            if not self.database_url.startswith("sqlite"):
                return None
            database = self.database_url.partition(":///")[2]
            return Path(database) if database else None
        if not self.database_url.drivername.startswith("sqlite"):
            return None
        database = self.database_url.database
        return Path(database) if database else None
