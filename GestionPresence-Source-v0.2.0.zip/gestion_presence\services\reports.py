"""Rapports de présence filtrés et export CSV."""

import csv
from datetime import date
from pathlib import Path

from sqlalchemy import select
from sqlalchemy.orm import Session, joinedload

from gestion_presence.database.models import Attendance, AuditLog, Employee
from gestion_presence.errors import ValidationError
from gestion_presence.services.rbac import RbacService


class ReportService:
    @staticmethod
    def attendance(
        session: Session,
        *,
        actor_user_id: int,
        start_date: date,
        end_date: date,
        employee_id: int | None = None,
        department_id: int | None = None,
    ) -> list[Attendance]:
        RbacService.require_permission(session, actor_user_id, "report.view")
        if end_date < start_date:
            raise ValidationError("La date de fin précède la date de début.")
        statement = (
            select(Attendance)
            .options(
                joinedload(Attendance.employee).joinedload(Employee.department)
            )
            .join(Employee)
            .where(
                Attendance.attendance_date >= start_date,
                Attendance.attendance_date <= end_date,
            )
        )
        if employee_id is not None:
            statement = statement.where(Attendance.employee_id == employee_id)
        if department_id is not None:
            statement = statement.where(Employee.department_id == department_id)
        return list(
            session.scalars(
                statement.order_by(
                    Attendance.attendance_date.desc(),
                    Employee.last_name,
                    Employee.first_name,
                )
            )
        )

    @staticmethod
    def dashboard_counts(
        session: Session, *, actor_user_id: int, attendance_date: date
    ) -> dict[str, int]:
        RbacService.require_permission(session, actor_user_id, "report.view")
        employees_count = len(
            list(session.scalars(select(Employee.id).where(Employee.is_active.is_(True))))
        )
        rows = list(
            session.scalars(
                select(Attendance).where(
                    Attendance.attendance_date == attendance_date
                )
            )
        )
        present = len(rows)
        return {
            "employees": employees_count,
            "present": present,
            "absent": max(0, employees_count - present),
            "late": sum((record.late_minutes or 0) > 0 for record in rows),
            "open": sum(record.check_out_at is None for record in rows),
        }

    @staticmethod
    def export_csv(
        session: Session,
        *,
        actor_user_id: int,
        attendances: list[Attendance],
        path: str | Path,
    ) -> None:
        RbacService.require_permission(session, actor_user_id, "report.export")
        destination = Path(path)
        destination.parent.mkdir(parents=True, exist_ok=True)
        with destination.open("w", newline="", encoding="utf-8-sig") as csv_file:
            writer = csv.writer(csv_file, delimiter=";")
            writer.writerow(
                [
                    "Identifiant",
                    "Employé",
                    "Service",
                    "Date",
                    "Entrée",
                    "Sortie",
                    "Durée (minutes)",
                    "Retard (minutes)",
                    "Départ anticipé (minutes)",
                    "Heures supplémentaires (minutes)",
                    "Statut",
                ]
            )
            for attendance in attendances:
                employee = attendance.employee
                writer.writerow(
                    [
                        employee.employee_code,
                        f"{employee.first_name} {employee.last_name}",
                        employee.department.name if employee.department else "",
                        attendance.attendance_date.isoformat(),
                        attendance.check_in_at.isoformat(sep=" ", timespec="minutes"),
                        (
                            attendance.check_out_at.isoformat(
                                sep=" ", timespec="minutes"
                            )
                            if attendance.check_out_at
                            else ""
                        ),
                        attendance.worked_minutes if attendance.worked_minutes is not None else "",
                        attendance.late_minutes if attendance.late_minutes is not None else "",
                        (
                            attendance.early_departure_minutes
                            if attendance.early_departure_minutes is not None
                            else ""
                        ),
                        (
                            attendance.overtime_minutes
                            if attendance.overtime_minutes is not None
                            else ""
                        ),
                        attendance.status,
                    ]
                )
        session.add(
            AuditLog(
                user_id=actor_user_id,
                action="EXPORT_REPORT",
                entity_type="attendance_report",
                entity_id=f"{len(attendances)} rows",
            )
        )
        session.flush()
