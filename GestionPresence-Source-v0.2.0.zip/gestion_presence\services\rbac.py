"""Attribution des rôles et contrôle des permissions RBAC."""

from sqlalchemy import select
from sqlalchemy.orm import Session

from gestion_presence.database.models import (
    Permission,
    Role,
    RolePermission,
    User,
    UserRole,
)
from gestion_presence.errors import EntityNotFound, PermissionDenied, ValidationError


class RbacService:
    @staticmethod
    def has_permission(session: Session, user_id: int, permission_name: str) -> bool:
        statement = (
            select(Permission.id)
            .join(RolePermission, RolePermission.permission_id == Permission.id)
            .join(Role, Role.id == RolePermission.role_id)
            .join(UserRole, UserRole.role_id == Role.id)
            .join(User, User.id == UserRole.user_id)
            .where(
                User.id == user_id,
                User.is_active.is_(True),
                Role.is_active.is_(True),
                Permission.name == permission_name,
            )
            .limit(1)
        )
        return session.scalar(statement) is not None

    @staticmethod
    def require_permission(session: Session, user_id: int, permission_name: str) -> None:
        if not RbacService.has_permission(session, user_id, permission_name):
            raise PermissionDenied(
                f"Permission refusée : {permission_name} (utilisateur {user_id})."
            )

    @staticmethod
    def assign_role(
        session: Session,
        *,
        user_id: int,
        role_id: int,
        assigned_by: int | None = None,
    ) -> UserRole:
        user = session.get(User, user_id)
        role = session.get(Role, role_id)
        if user is None or role is None:
            raise EntityNotFound("Utilisateur ou rôle introuvable.")
        if not user.is_active or not role.is_active:
            raise ValidationError("Impossible d'attribuer un rôle inactif.")
        if assigned_by is not None:
            RbacService.require_permission(session, assigned_by, "user.update")
        existing = session.get(UserRole, (user_id, role_id))
        if existing is not None:
            return existing
        association = UserRole(
            user_id=user_id,
            role_id=role_id,
            assigned_by=assigned_by,
        )
        session.add(association)
        session.flush()
        return association

    @staticmethod
    def revoke_role(
        session: Session, *, actor_user_id: int, user_id: int, role_id: int
    ) -> None:
        RbacService.require_permission(session, actor_user_id, "user.update")
        association = session.get(UserRole, (user_id, role_id))
        if association is None:
            raise EntityNotFound("Cette attribution de rôle n'existe pas.")
        session.delete(association)

    @staticmethod
    def grant_permission(
        session: Session,
        *,
        actor_user_id: int,
        role_id: int,
        permission_id: int,
    ) -> RolePermission:
        RbacService.require_permission(session, actor_user_id, "role.update")
        role = session.get(Role, role_id)
        permission = session.get(Permission, permission_id)
        if role is None or permission is None:
            raise EntityNotFound("Rôle ou permission introuvable.")
        existing = session.get(RolePermission, (role_id, permission_id))
        if existing is not None:
            return existing
        association = RolePermission(role_id=role_id, permission_id=permission_id)
        session.add(association)
        session.flush()
        return association

    @staticmethod
    def revoke_permission(
        session: Session,
        *,
        actor_user_id: int,
        role_id: int,
        permission_id: int,
    ) -> None:
        RbacService.require_permission(session, actor_user_id, "role.update")
        association = session.get(RolePermission, (role_id, permission_id))
        if association is None:
            raise EntityNotFound("Cette permission n'est pas associée au rôle.")
        session.delete(association)
