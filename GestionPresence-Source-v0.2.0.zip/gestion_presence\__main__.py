"""Point d'entrée de contrôle et de bootstrap de l'application."""

import argparse
import getpass
import logging
import sys

from sqlalchemy import select
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session

from gestion_presence.application import initialize_application
from gestion_presence.config import Settings
from gestion_presence.database.models import User
from gestion_presence.errors import ApplicationError
from gestion_presence.database.session import create_session_factory
from gestion_presence.services.authentication import AuthenticationService


def main() -> int:
    parser = argparse.ArgumentParser(description="Gestion des présences")
    parser.add_argument(
        "--create-admin",
        action="store_true",
        help="Créer le premier administrateur sur une base vide.",
    )
    parser.add_argument(
        "--check-db",
        action="store_true",
        help="Vérifier la connexion SQLite puis quitter.",
    )
    arguments = parser.parse_args()

    try:
        settings = Settings.from_env()
        logging.basicConfig(
            level=settings.log_level,
            format="%(asctime)s %(levelname)s %(name)s: %(message)s",
        )
        engine = initialize_application(settings)
        if arguments.create_admin:
            with Session(engine) as session, session.begin():
                has_users = session.scalar(select(User.id).limit(1)) is not None
                if has_users:
                    raise ApplicationError(
                        "La base contient déjà un utilisateur ; le bootstrap est désactivé."
                    )
                username = input("Nom du premier administrateur : ").strip()
                password = getpass.getpass("Mot de passe (12 caractères minimum) : ")
                confirmation = getpass.getpass("Confirmer le mot de passe : ")
                if password != confirmation:
                    raise ApplicationError("Les mots de passe ne correspondent pas.")
                user = AuthenticationService.bootstrap_first_administrator(
                    session,
                    username=username,
                    password=password,
                )
                print(f"Administrateur initial créé : {user.username}")
            engine.dispose()
            return 0
        if arguments.check_db:
            print("Connexion SQLite vérifiée avec succès.")
            engine.dispose()
            return 0

        try:
            from gestion_presence.ui.main_window import launch_desktop
        except ModuleNotFoundError as error:
            engine.dispose()
            raise ApplicationError(
                "Dépendance interface ou caméra manquante (Tkinter/OpenCV/Pillow). "
                "Installez requirements.txt puis relancez."
            ) from error

        return launch_desktop(
            settings,
            create_session_factory(engine),
            engine,
        )
    except (ApplicationError, SQLAlchemyError, OSError) as error:
        logging.getLogger(__name__).error("Démarrage impossible : %s", error)
        return 1


if __name__ == "__main__":
    sys.exit(main())
