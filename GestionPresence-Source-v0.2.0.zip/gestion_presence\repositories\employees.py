"""Opérations de persistance liées aux employés."""

from datetime import date
from uuid import uuid4

from sqlalchemy.orm import Session

from gestion_presence.database.models import Employee


class EmployeeRepository:
    """Persistance employé et génération de son identifiant public."""

    @staticmethod
    def create(
        session: Session,
        *,
        first_name: str,
        last_name: str,
        department_id: int | None = None,
        job_title: str | None = None,
        phone: str | None = None,
        hire_date: date | None = None,
        is_active: bool = True,
    ) -> Employee:
        """Crée un employé avec un code séquentiel non réutilisable."""
        employee = Employee(
            employee_code=f"PENDING-{uuid4().hex}",
            first_name=first_name,
            last_name=last_name,
            department_id=department_id,
            job_title=job_title,
            phone=phone,
            hire_date=hire_date,
            is_active=is_active,
        )
        session.add(employee)
        session.flush()
        employee.employee_code = f"EMP-{date.today().year}-{employee.id:06d}"
        session.flush()
        return employee
