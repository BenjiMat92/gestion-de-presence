"""Sauvegarde cohérente d'une base SQLite active."""

import sqlite3
from pathlib import Path

from sqlalchemy.orm import Session

from gestion_presence.database.models import AuditLog
from gestion_presence.errors import ValidationError
from gestion_presence.services.rbac import RbacService


class BackupService:
    @staticmethod
    def create(
        session: Session, *, actor_user_id: int, destination: str | Path
    ) -> Path:
        RbacService.require_permission(session, actor_user_id, "backup.create")
        engine = session.get_bind()
        if not engine.url.drivername.startswith("sqlite"):
            raise ValidationError(
                "La sauvegarde native est disponible uniquement pour SQLite."
            )
        target_path = Path(destination).expanduser().resolve()
        if (
            engine.url.database
            and Path(engine.url.database).expanduser().resolve() == target_path
        ):
            raise ValidationError("La sauvegarde ne peut pas remplacer la base active.")
        target_path.parent.mkdir(parents=True, exist_ok=True)

        source = engine.raw_connection()
        target: sqlite3.Connection | None = None
        try:
            target = sqlite3.connect(target_path)
            source.driver_connection.backup(target)
        finally:
            if target is not None:
                target.close()
            source.close()

        session.add(
            AuditLog(
                user_id=actor_user_id,
                action="CREATE_DATABASE_BACKUP",
                entity_type="database",
                entity_id=target_path.name,
            )
        )
        session.flush()
        return target_path
