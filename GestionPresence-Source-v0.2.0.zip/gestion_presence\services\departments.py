"""Gestion métier des services et départements."""

from sqlalchemy import select
from sqlalchemy.orm import Session

from gestion_presence.database.models import AuditLog, Department
from gestion_presence.errors import EntityNotFound, ValidationError
from gestion_presence.services.rbac import RbacService


class DepartmentService:
    @staticmethod
    def create(
        session: Session,
        *,
        actor_user_id: int,
        code: str,
        name: str,
        description: str | None = None,
    ) -> Department:
        RbacService.require_permission(session, actor_user_id, "department.create")
        code = code.strip()
        name = name.strip()
        if not code or not name:
            raise ValidationError("Le code et le nom du service sont obligatoires.")
        department = Department(
            code=code,
            name=name,
            description=description.strip() if description else None,
        )
        session.add(department)
        session.flush()
        session.add(
            AuditLog(
                user_id=actor_user_id,
                action="CREATE_DEPARTMENT",
                entity_type="department",
                entity_id=department.code,
            )
        )
        session.flush()
        return department

    @staticmethod
    def list_active(
        session: Session, *, actor_user_id: int
    ) -> list[Department]:
        RbacService.require_permission(session, actor_user_id, "employee.view")
        return list(
            session.scalars(
                select(Department)
                .where(Department.is_active.is_(True))
                .order_by(Department.name)
            )
        )

    @staticmethod
    def list_all(session: Session, *, actor_user_id: int) -> list[Department]:
        RbacService.require_permission(session, actor_user_id, "employee.view")
        return list(session.scalars(select(Department).order_by(Department.name)))

    @staticmethod
    def rename(
        session: Session,
        department_id: int,
        *,
        actor_user_id: int,
        name: str,
        description: str | None = None,
    ) -> Department:
        RbacService.require_permission(session, actor_user_id, "department.update")
        department = session.get(Department, department_id)
        if department is None:
            raise EntityNotFound(f"Service introuvable (id={department_id}).")
        name = name.strip()
        if not name:
            raise ValidationError("Le nom du service est obligatoire.")
        department.name = name
        department.description = description.strip() if description else None
        session.add(
            AuditLog(
                user_id=actor_user_id,
                action="UPDATE_DEPARTMENT",
                entity_type="department",
                entity_id=department.code,
            )
        )
        session.flush()
        return department

    @staticmethod
    def set_active(
        session: Session,
        department_id: int,
        *,
        actor_user_id: int,
        is_active: bool,
    ) -> Department:
        RbacService.require_permission(session, actor_user_id, "department.update")
        department = session.get(Department, department_id)
        if department is None:
            raise EntityNotFound(f"Service introuvable (id={department_id}).")
        department.is_active = is_active
        session.add(
            AuditLog(
                user_id=actor_user_id,
                action="UPDATE_DEPARTMENT_STATUS",
                entity_type="department",
                entity_id=department.code,
                details={"is_active": is_active},
            )
        )
        session.flush()
        return department
