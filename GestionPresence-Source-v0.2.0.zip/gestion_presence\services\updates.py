"""Vérification et téléchargement vérifié des mises à jour GitHub Releases."""

from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
import os
from pathlib import Path
import re
import tempfile
from urllib.error import HTTPError, URLError
from urllib.parse import urlsplit
from urllib.request import HTTPRedirectHandler, Request, build_opener

from gestion_presence.version import __version__

GITHUB_OWNER = "BenjiMat92"
GITHUB_REPOSITORY = "gestion-de-presence"
INSTALLER_ASSET_NAME = "GestionPresence-Setup.exe"
MAX_INSTALLER_BYTES = 500 * 1024 * 1024
_API_ROOT = f"https://api.github.com/repos/{GITHUB_OWNER}/{GITHUB_REPOSITORY}"
_VERSION_PATTERN = re.compile(r"^v?(\d+)\.(\d+)\.(\d+)$")


def _http_error(error: HTTPError) -> UpdateCheckError:
    if error.code == 404:
        return UpdateCheckError(
            "Dépôt ou Release introuvable. Vérifiez que le dépôt public contient "
            "une première Release."
        )
    if error.code == 403:
        return UpdateCheckError(
            "GitHub a refusé l'accès ou atteint sa limite de requêtes."
        )
    return UpdateCheckError(f"GitHub a répondu avec le code HTTP {error.code}.")


@dataclass(frozen=True, slots=True)
class UpdateRelease:
    version: str
    title: str
    page_url: str
    notes: str
    installer_asset_id: int
    installer_size: int
    checksum_asset_id: int


class UpdateCheckError(Exception):
    """Une erreur explicite est survenue pendant la consultation de GitHub."""


class _SafeGitHubRedirectHandler(HTTPRedirectHandler):
    _ALLOWED_HOSTS = {
        "api.github.com",
        "github.com",
        "objects.githubusercontent.com",
        "release-assets.githubusercontent.com",
    }

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        parsed = urlsplit(newurl)
        if parsed.scheme != "https" or parsed.hostname not in self._ALLOWED_HOSTS:
            raise UpdateCheckError("GitHub a retourné une redirection non sécurisée.")
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def _version_tuple(value: str) -> tuple[int, int, int]:
    match = _VERSION_PATTERN.fullmatch(value.strip())
    if match is None:
        raise UpdateCheckError(f"Version GitHub non prise en charge : {value!r}")
    return tuple(int(component) for component in match.groups())


def _request_bytes(url: str, accept: str) -> bytes:
    headers = {
        "Accept": accept,
        "User-Agent": "GestionPresence-UpdateChecker",
        "X-GitHub-Api-Version": "2022-11-28",
    }
    request = Request(
        url,
        headers=headers,
    )
    try:
        with build_opener(_SafeGitHubRedirectHandler()).open(
            request, timeout=30
        ) as response:
            return response.read()
    except HTTPError as error:
        raise _http_error(error) from error
    except (URLError, TimeoutError, OSError) as error:
        raise UpdateCheckError(f"Connexion à GitHub impossible : {error}") from error


def check_for_update() -> UpdateRelease | None:
    """Retourne la dernière Release stable si elle est plus récente que l'application."""
    raw = _request_bytes(
        f"{_API_ROOT}/releases/latest",
        "application/vnd.github+json",
    )
    try:
        release = json.loads(raw)
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        raise UpdateCheckError("GitHub a retourné des métadonnées Release invalides.") from error
    if not isinstance(release, dict):
        raise UpdateCheckError("GitHub a retourné des métadonnées Release invalides.")

    tag = release.get("tag_name")
    if not isinstance(tag, str):
        raise UpdateCheckError("La Release GitHub ne contient pas de tag de version.")
    if _version_tuple(tag) <= _version_tuple(__version__):
        return None

    assets = release.get("assets")
    if not isinstance(assets, list):
        raise UpdateCheckError("La Release GitHub ne contient pas de liste d'assets.")
    installer = next(
        (
            asset
            for asset in assets
            if isinstance(asset, dict)
            and asset.get("name") == INSTALLER_ASSET_NAME
        ),
        None,
    )
    checksum = next(
        (
            asset
            for asset in assets
            if isinstance(asset, dict)
            and asset.get("name") == f"{INSTALLER_ASSET_NAME}.sha256"
        ),
        None,
    )
    if installer is None or checksum is None:
        raise UpdateCheckError(
            "Cette Release ne contient pas l'installateur Windows et son checksum."
        )
    installer_id = installer.get("id")
    checksum_id = checksum.get("id")
    asset_size = installer.get("size")
    page_url = release.get("html_url")
    if (
        not isinstance(installer_id, int)
        or not isinstance(checksum_id, int)
        or not isinstance(asset_size, int)
        or asset_size <= 0
        or asset_size > MAX_INSTALLER_BYTES
        or not isinstance(page_url, str)
        or urlsplit(page_url).scheme != "https"
        or urlsplit(page_url).hostname != "github.com"
    ):
        raise UpdateCheckError("La Release contient des métadonnées d'asset invalides.")

    return UpdateRelease(
        version=tag.removeprefix("v"),
        title=str(release.get("name") or f"Version {tag}"),
        page_url=page_url,
        notes=str(release.get("body") or ""),
        installer_asset_id=installer_id,
        installer_size=asset_size,
        checksum_asset_id=checksum_id,
    )


def download_update(
    release: UpdateRelease,
    destination: str | Path,
) -> Path:
    """Télécharge l'installateur dans un fichier temporaire, vérifie SHA-256, puis le publie."""
    target = Path(destination).expanduser().resolve()
    if target.suffix.lower() != ".exe":
        raise UpdateCheckError("Choisissez un chemin de destination se terminant par .exe.")
    target.parent.mkdir(parents=True, exist_ok=True)

    checksum_data = _request_bytes(
        f"{_API_ROOT}/releases/assets/{release.checksum_asset_id}",
        "application/octet-stream",
    )
    checksum_match = re.match(rb"^\s*([a-fA-F0-9]{64})(?:\s|$)", checksum_data)
    if checksum_match is None:
        raise UpdateCheckError("Le fichier checksum de la Release est invalide.")
    expected_digest = checksum_match.group(1).decode("ascii").lower()

    asset_url = f"{_API_ROOT}/releases/assets/{release.installer_asset_id}"
    request = Request(asset_url, headers={
        "Accept": "application/octet-stream",
        "User-Agent": "GestionPresence-UpdateChecker",
        "X-GitHub-Api-Version": "2022-11-28",
    })
    temporary_path: Path | None = None
    try:
        with build_opener(_SafeGitHubRedirectHandler()).open(
            request, timeout=60
        ) as response:
            descriptor, temporary_name = tempfile.mkstemp(
                prefix=f".{target.name}.", suffix=".download", dir=target.parent
            )
            temporary_path = Path(temporary_name)
            digest = hashlib.sha256()
            written = 0
            with os.fdopen(descriptor, "wb") as output:
                while chunk := response.read(1024 * 1024):
                    written += len(chunk)
                    if written > MAX_INSTALLER_BYTES or written > release.installer_size:
                        raise UpdateCheckError("L'installateur dépasse la taille annoncée.")
                    digest.update(chunk)
                    output.write(chunk)
        if written != release.installer_size:
            raise UpdateCheckError("Le téléchargement est incomplet.")
        if digest.hexdigest() != expected_digest:
            raise UpdateCheckError(
                "Le SHA-256 de l'installateur ne correspond pas à celui de la Release."
            )
        if temporary_path is None:
            raise UpdateCheckError("Le fichier temporaire de l'installateur est manquant.")
        os.replace(temporary_path, target)
        temporary_path = None
        return target
    except HTTPError as error:
        raise _http_error(error) from error
    except (URLError, TimeoutError, OSError) as error:
        raise UpdateCheckError(f"Échec du téléchargement : {error}") from error
    finally:
        if temporary_path is not None:
            temporary_path.unlink(missing_ok=True)
