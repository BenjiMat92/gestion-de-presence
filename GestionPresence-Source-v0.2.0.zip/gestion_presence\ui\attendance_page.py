"""Écran de pointage Tkinter avec saisie d'identifiant et caméra QR."""

from __future__ import annotations

from datetime import datetime, timezone
from importlib import import_module
import tkinter as tk
from tkinter import StringVar, messagebox, ttk
from typing import Any

from PIL import Image, ImageTk
from sqlalchemy import select
from sqlalchemy.orm import Session, sessionmaker

try:
    cv2: Any = import_module("cv2")
except ModuleNotFoundError:
    cv2 = None

from gestion_presence.config import Settings
from gestion_presence.database.models import Attendance, Device, Employee
from gestion_presence.errors import ApplicationError
from gestion_presence.services.attendance import AttendanceService
from gestion_presence.ui.common import BasePage, read_database, write_database


class AttendancePage(BasePage):
    def __init__(
        self,
        parent,
        session_factory: sessionmaker[Session],
        settings: Settings,
        actor_user_id: int,
    ) -> None:
        super().__init__(parent, "Pointage QR")
        self.session_factory = session_factory
        self.settings = settings
        self.actor_user_id = actor_user_id
        self.camera: Any = None
        self._timer_id: str | None = None
        self._preview_image: ImageTk.PhotoImage | None = None
        self.device_codes: dict[str, str] = {}
        self.device_name = StringVar()
        self.qr_value = StringVar()

        card = ttk.LabelFrame(
            self.content,
            text="Scannez le QR code ou saisissez l'identifiant de l'employé",
            padding=20,
        )
        card.grid(row=0, column=0, sticky="n", padx=30, pady=10)
        card.columnconfigure(1, weight=1)
        ttk.Label(card, text="Pointeuse QR").grid(
            row=0, column=0, sticky="w", padx=(0, 12), pady=8
        )
        self.device = ttk.Combobox(
            card, textvariable=self.device_name, state="readonly", width=38
        )
        self.device.grid(row=0, column=1, sticky="ew", pady=8)
        ttk.Label(card, text="Identifiant QR").grid(
            row=1, column=0, sticky="w", padx=(0, 12), pady=8
        )
        self.qr_input = ttk.Entry(card, textvariable=self.qr_value, width=42)
        self.qr_input.grid(row=1, column=1, sticky="ew", pady=8)
        self.qr_input.bind("<Return>", lambda _event: self.submit_code())
        action_row = ttk.Frame(card)
        action_row.grid(row=2, column=0, columnspan=2, sticky="ew", pady=8)
        self.scan_button = ttk.Button(
            action_row, text="Démarrer la caméra", command=self.toggle_camera
        )
        self.scan_button.pack(side="left")
        self.submit_button = ttk.Button(
            action_row,
            text="Pointer",
            command=self.submit_code,
            style="Primary.TButton",
        )
        self.submit_button.pack(side="right")
        self.camera_preview = ttk.Label(
            card,
            text="Caméra arrêtée",
            anchor="center",
            width=70,
            relief="solid",
        )
        self.camera_preview.grid(
            row=3, column=0, columnspan=2, sticky="ew", pady=(12, 8)
        )
        self.result = ttk.Label(
            card, text="Prêt à pointer", anchor="center", justify="center",
            padding=14, style="Result.TLabel",
        )
        self.result.grid(row=4, column=0, columnspan=2, sticky="ew", pady=8)
        ttk.Style(self).configure(
            "Result.TLabel",
            background="#eff6ff",
            font=("Segoe UI", 13, "bold"),
        )
        self._load_devices()
        self.qr_input.focus_set()

    def _load_devices(self) -> None:
        try:
            devices = read_database(
                self.session_factory,
                lambda session: [
                    (device.name, device.device_code)
                    for device in session.scalars(
                        select(Device)
                        .where(
                            Device.status == "active",
                            Device.device_type.in_(("qr", "mixed")),
                        )
                        .order_by(Device.name)
                    )
                ],
            )
        except Exception as error:
            self.result.configure(text=f"Impossible de charger les pointeuses : {error}")
            self.submit_button.configure(state="disabled")
            self.scan_button.configure(state="disabled")
            return
        self.device_codes = {
            f"{name} — {code}": code for name, code in devices
        }
        self.device.configure(values=list(self.device_codes))
        if devices:
            self.device.current(0)
        else:
            self.device.configure(values=["Aucune pointeuse QR active"])
            self.device.current(0)
            self.submit_button.configure(state="disabled")
            self.scan_button.configure(state="disabled")

    def submit_code(self) -> None:
        employee_code = self.qr_value.get().strip()
        if not employee_code:
            messagebox.showinfo(
                "Pointage", "Scannez ou saisissez un identifiant QR.", parent=self
            )
            return
        device_code = self.device_codes.get(self.device_name.get())
        if not device_code:
            self.result.configure(text="Aucune pointeuse QR active n'est configurée.")
            return
        try:
            def record(session: Session) -> tuple[str, str, datetime, bool]:
                employee = session.scalar(
                    select(Employee).where(Employee.employee_code == employee_code)
                )
                if employee is None:
                    raise ApplicationError(f"QR Code inconnu : {employee_code}")
                local_date = datetime.now(timezone.utc).astimezone(
                    self.settings.timezone
                ).date()
                open_record = session.scalar(
                    select(Attendance).where(
                        Attendance.employee_id == employee.id,
                        Attendance.status == "open",
                        Attendance.check_out_at.is_(None),
                    )
                    .order_by(Attendance.attendance_date.desc())
                    .limit(1)
                )
                existing_today = session.scalar(
                    select(Attendance).where(
                        Attendance.employee_id == employee.id,
                        Attendance.attendance_date == local_date,
                    )
                )
                method = "clock_out" if open_record is not None else "clock_in"
                if existing_today is not None and existing_today.check_out_at is not None:
                    raise ApplicationError(
                        "L'entrée et la sortie sont déjà enregistrées aujourd'hui."
                    )
                attendance = getattr(AttendanceService, method)(
                    session,
                    employee_code=employee_code,
                    actor_user_id=self.actor_user_id,
                    settings=self.settings,
                    identification_method="qr",
                    device_code=device_code,
                    at=datetime.now(timezone.utc),
                )
                timestamp = (
                    attendance.check_in_at
                    if method == "clock_in"
                    else attendance.check_out_at
                )
                if timestamp is None:
                    raise RuntimeError("Horodatage de pointage manquant.")
                return (
                    f"{employee.first_name} {employee.last_name}",
                    employee.employee_code,
                    timestamp,
                    method == "clock_in",
                )

            employee_name, saved_code, timestamp, is_entry = write_database(
                self.session_factory, record
            )
            local_timestamp = timestamp.replace(tzinfo=timezone.utc).astimezone(
                self.settings.timezone
            )
            event = "Entrée enregistrée" if is_entry else "Sortie enregistrée"
            self.result.configure(
                text=f"{event}\n{employee_name}\n{saved_code}\n{local_timestamp:%H:%M:%S}",
                background="#dcfce7",
            )
            self.qr_value.set("")
            self.qr_input.focus_set()
        except Exception as error:
            self.result.configure(
                text=f"Pointage non enregistré\n{error}", background="#fee2e2"
            )
            messagebox.showerror("Pointage non enregistré", str(error), parent=self)

    def toggle_camera(self) -> None:
        if cv2 is None:
            messagebox.showerror(
                "Caméra indisponible",
                "La lecture caméra nécessite OpenCV. Installez les dépendances du projet.",
                parent=self,
            )
            return
        if self.camera is not None:
            self._stop_camera()
            return
        camera = cv2.VideoCapture(0)
        if not camera.isOpened():
            camera.release()
            messagebox.showerror(
                "Caméra indisponible",
                "La caméra ne peut pas être ouverte. Vérifiez son branchement et ses autorisations.",
                parent=self,
            )
            return
        self.camera = camera
        self.scan_button.configure(text="Arrêter la caméra")
        self.camera_preview.configure(text="Recherche du QR code…")
        self._read_camera()

    def _read_camera(self) -> None:
        self._timer_id = None
        if self.camera is None:
            return
        success, frame = self.camera.read()
        if not success:
            self._stop_camera()
            messagebox.showerror("Caméra", "La lecture vidéo a échoué.", parent=self)
            return
        decoded, points, _ = cv2.QRCodeDetector().detectAndDecode(frame)
        if points is not None:
            cv2.polylines(frame, [points.astype(int)], True, (40, 180, 80), 3)
        rgb_image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        image = Image.fromarray(rgb_image)
        image.thumbnail((720, 405))
        self._preview_image = ImageTk.PhotoImage(image)
        self.camera_preview.configure(image=self._preview_image, text="")
        if decoded.strip():
            self.qr_value.set(decoded.strip())
            self._stop_camera()
            self.submit_code()
            return
        self._timer_id = self.after(35, self._read_camera)

    def _stop_camera(self) -> None:
        if self._timer_id is not None:
            try:
                self.after_cancel(self._timer_id)
            except tk.TclError:
                pass
            self._timer_id = None
        if self.camera is not None:
            self.camera.release()
            self.camera = None
        self._preview_image = None
        self.scan_button.configure(text="Démarrer la caméra")
        self.camera_preview.configure(image="", text="Caméra arrêtée")
