"""Initialise une base de démonstration isolée, avec utilisateurs et exemples."""

from __future__ import annotations

import argparse
from datetime import date, datetime, time, timedelta, timezone
from pathlib import Path
from zoneinfo import ZoneInfo

import qrcode
from sqlalchemy import URL, select
from sqlalchemy.orm import Session

from gestion_presence.database.connection import create_database, create_engine
from gestion_presence.database.models import (
    Attendance,
    Department,
    Device,
    Employee,
    Permission,
    Role,
    RolePermission,
    User,
    UserRole,
    WorkSchedule,
)
from gestion_presence.errors import ApplicationError
from gestion_presence.services.authentication import AuthenticationService
from gestion_presence.services.departments import DepartmentService
from gestion_presence.services.devices import DeviceService
from gestion_presence.services.employees import EmployeeService

PROJECT_ROOT = Path(__file__).resolve().parents[1]
DEMO_DIRECTORY = PROJECT_ROOT / ".demo"
DEMO_DATABASE = DEMO_DIRECTORY / "gestion_presence_demo.db"
DEMO_PASSWORD = "DemoPresence2026!"
DEMO_USERS = {
    "admin.demo": "ADMINISTRATEUR",
    "rh.demo": "RH",
    "superviseur.demo": "SUPERVISEUR",
}
TIMEZONE = ZoneInfo("Africa/Kinshasa")


def _get_or_create_role(session: Session, name: str, description: str) -> Role:
    role = session.scalar(select(Role).where(Role.name == name))
    if role is None:
        role = Role(name=name, description=description)
        session.add(role)
        session.flush()
    return role


def _assign_permissions(
    session: Session, role: Role, permission_names: set[str]
) -> None:
    for permission_name in permission_names:
        permission = session.scalar(
            select(Permission).where(Permission.name == permission_name)
        )
        if permission is None:
            resource, _, action = permission_name.partition(".")
            permission = Permission(
                name=permission_name,
                resource=resource,
                description=f"Autorise l'action {action} sur {resource}",
            )
            session.add(permission)
            session.flush()
        if session.get(RolePermission, (role.id, permission.id)) is None:
            session.add(RolePermission(role_id=role.id, permission_id=permission.id))
    role.is_active = True


def _create_demo_user(
    session: Session,
    *,
    username: str,
    role: Role,
    employee_id: int | None,
    admin_id: int,
) -> User:
    user = session.scalar(select(User).where(User.username == username))
    if user is None:
        user = AuthenticationService.create_user(
            session,
            created_by=admin_id,
            username=username,
            password=DEMO_PASSWORD,
            employee_id=employee_id,
            role_id=role.id,
        )
    else:
        user.is_active = True
        if session.get(UserRole, (user.id, role.id)) is None:
            session.add(
                UserRole(user_id=user.id, role_id=role.id, assigned_by=admin_id)
            )
    return user


def seed_demo_database(database_path: Path = DEMO_DATABASE) -> dict[str, object]:
    """Crée des données de démo de manière idempotente dans une base dédiée."""
    database_path = database_path.resolve()
    DEMO_DIRECTORY.mkdir(parents=True, exist_ok=True)
    qr_directory = database_path.parent / "qr_codes"
    qr_directory.mkdir(parents=True, exist_ok=True)
    engine = create_engine(URL.create("sqlite", database=str(database_path)))
    create_database(engine)
    try:
        with Session(engine) as session, session.begin():
            admin = session.scalar(
                select(User).where(User.username == "admin.demo")
            )
            if admin is None and session.scalar(select(User.id).limit(1)) is not None:
                raise ApplicationError(
                    "La base de démonstration contient déjà d'autres comptes. "
                    "Choisissez un fichier de démonstration vide."
                )
            if admin is None:
                admin = AuthenticationService.bootstrap_first_administrator(
                    session,
                    username="admin.demo",
                    password=DEMO_PASSWORD,
                )
            admin_id = admin.id

            rh_role = _get_or_create_role(
                session, "RH", "Gestion des employés, présences et rapports."
            )
            supervisor_role = _get_or_create_role(
                session, "SUPERVISEUR", "Consultation des employés et des présences."
            )
            _assign_permissions(
                session,
                rh_role,
                {
                    "employee.view",
                    "employee.create",
                    "employee.update",
                    "attendance.view",
                    "attendance.create",
                    "attendance.update",
                    "report.view",
                    "report.export",
                    "device.view",
                },
            )
            _assign_permissions(
                session,
                supervisor_role,
                {"employee.view", "attendance.view", "report.view"},
            )

            department_specs = (
                ("DEMO-ADM", "Administration"),
                ("DEMO-IT", "Informatique"),
                ("DEMO-RH", "Ressources humaines"),
            )
            departments: dict[str, Department] = {}
            for code, name in department_specs:
                department = session.scalar(
                    select(Department).where(Department.code == code)
                )
                if department is None:
                    department = DepartmentService.create(
                        session,
                        actor_user_id=admin_id,
                        code=code,
                        name=name,
                    )
                department.is_active = True
                departments[code] = department

            employee_specs = (
                ("Amina", "Kabila", "DEMO-IT", "Technicienne informatique"),
                ("Jean", "Mbuyi", "DEMO-ADM", "Agent administratif"),
                ("Sarah", "Ilunga", "DEMO-RH", "Assistante RH"),
                ("David", "Tshibanda", "DEMO-IT", "Support utilisateur"),
                ("Grace", "Mukendi", "DEMO-ADM", "Comptable"),
            )
            employees: list[Employee] = []
            for first_name, last_name, department_code, job_title in employee_specs:
                employee = session.scalar(
                    select(Employee).where(
                        Employee.first_name == first_name,
                        Employee.last_name == last_name,
                        Employee.department_id == departments[department_code].id,
                    )
                )
                if employee is None:
                    employee = EmployeeService.create(
                        session,
                        actor_user_id=admin_id,
                        first_name=first_name,
                        last_name=last_name,
                        department_id=departments[department_code].id,
                        job_title=job_title,
                        phone="+243 000 000 000",
                        hire_date=date.today() - timedelta(days=365),
                    )
                employee.is_active = True
                employee.job_title = job_title
                employees.append(employee)

            employee_users: dict[str, int | None] = {
                "rh.demo": employees[2].id,
                "superviseur.demo": employees[1].id,
            }
            _create_demo_user(
                session,
                username="rh.demo",
                role=rh_role,
                employee_id=employee_users["rh.demo"],
                admin_id=admin_id,
            )
            _create_demo_user(
                session,
                username="superviseur.demo",
                role=supervisor_role,
                employee_id=employee_users["superviseur.demo"],
                admin_id=admin_id,
            )

            device = session.scalar(
                select(Device).where(Device.device_code == "DEVICE-DEMO-01")
            )
            if device is None:
                device = DeviceService.create(
                    session,
                    actor_user_id=admin_id,
                    device_code="DEVICE-DEMO-01",
                    name="Pointeuse de démonstration",
                    location="Entrée principale",
                    device_type="qr",
                )
            device.status = "active"

            today_local = datetime.now(TIMEZONE).date()
            monday = today_local - timedelta(days=today_local.weekday())
            for employee in employees:
                for weekday in range(5):
                    start_date = monday - timedelta(days=7)
                    existing_schedule = session.scalar(
                        select(WorkSchedule).where(
                            WorkSchedule.employee_id == employee.id,
                            WorkSchedule.day_of_week == weekday,
                            WorkSchedule.effective_from == start_date,
                        )
                    )
                    if existing_schedule is None:
                        session.add(
                            WorkSchedule(
                                employee_id=employee.id,
                                name="Horaire standard de démonstration",
                                day_of_week=weekday,
                                start_time=time(8, 0),
                                end_time=time(16, 0),
                                break_minutes=30,
                                grace_period_minutes=5,
                                effective_from=start_date,
                            )
                        )

            demo_day = today_local - timedelta(days=1)
            while demo_day.weekday() >= 5:
                demo_day -= timedelta(days=1)
            attendance_samples = (
                (employees[0], time(7, 55), time(16, 20), 0),
                (employees[1], time(8, 22), time(15, 45), 17),
                (employees[2], time(8, 4), time(16, 0), 0),
                (employees[3], time(8, 0), None, 0),
            )
            for employee, check_in_time, check_out_time, late_minutes in attendance_samples:
                _create_sample_attendance(
                    session,
                    employee=employee,
                    device=device,
                    day=demo_day,
                    check_in_time=check_in_time,
                    check_out_time=check_out_time,
                    late_minutes=late_minutes,
                )

            now_local = datetime.now(TIMEZONE)
            today_entry = min(
                datetime.combine(today_local, time(8, 5), tzinfo=TIMEZONE),
                now_local - timedelta(minutes=5),
            )
            if today_entry.date() != today_local:
                today_entry = now_local.replace(second=0, microsecond=0) - timedelta(
                    minutes=1
                )
            _create_sample_attendance(
                session,
                employee=employees[0],
                device=device,
                day=today_local,
                check_in_time=today_entry.timetz().replace(tzinfo=None),
                check_out_time=None,
                late_minutes=max(
                    0,
                    int(
                        (
                            today_entry
                            - datetime.combine(
                                today_local, time(8, 5), tzinfo=TIMEZONE
                            )
                        ).total_seconds()
                        // 60
                    ),
                ),
            )
            second_entry = min(
                datetime.combine(today_local, time(8, 10), tzinfo=TIMEZONE),
                now_local - timedelta(minutes=5),
            )
            if (
                second_entry.date() == today_local
                and now_local > second_entry + timedelta(minutes=1)
            ):
                second_checkout = min(
                    datetime.combine(today_local, time(16, 0), tzinfo=TIMEZONE),
                    now_local,
                )
                if second_checkout > second_entry:
                    _create_sample_attendance(
                        session,
                        employee=employees[1],
                        device=device,
                        day=today_local,
                        check_in_time=second_entry.timetz().replace(tzinfo=None),
                        check_out_time=second_checkout.timetz().replace(tzinfo=None),
                        late_minutes=max(
                            0,
                            int(
                                (
                                    second_entry
                                    - datetime.combine(
                                        today_local, time(8, 5), tzinfo=TIMEZONE
                                    )
                                ).total_seconds()
                                // 60
                            ),
                        ),
                    )
            session.flush()
            employee_codes = {
                employee.employee_code: f"{employee.first_name} {employee.last_name}"
                for employee in employees
            }

        for employee_code in employee_codes:
            qr_code = qrcode.QRCode(box_size=8, border=4)
            qr_code.add_data(employee_code)
            qr_code.make(fit=True)
            qr_code.make_image(fill_color="black", back_color="white").save(
                qr_directory / f"{employee_code}.png"
            )
        return {
            "database": database_path,
            "qr_directory": qr_directory,
            "employees": employee_codes,
            "accounts": DEMO_USERS.copy(),
            "password": DEMO_PASSWORD,
            "device": "DEVICE-DEMO-01",
            "sample_date": demo_day,
        }
    finally:
        engine.dispose()


def _create_sample_attendance(
    session: Session,
    *,
    employee: Employee,
    device: Device,
    day: date,
    check_in_time: time,
    check_out_time: time | None,
    late_minutes: int,
) -> None:
    existing = session.scalar(
        select(Attendance.id).where(
            Attendance.employee_id == employee.id,
            Attendance.attendance_date == day,
        )
    )
    if existing is not None:
        return
    check_in_local = datetime.combine(day, check_in_time, tzinfo=TIMEZONE)
    check_out_local = (
        datetime.combine(day, check_out_time, tzinfo=TIMEZONE)
        if check_out_time
        else None
    )
    worked_minutes = (
        max(0, int((check_out_local - check_in_local).total_seconds() // 60) - 30)
        if check_out_local
        else None
    )
    expected_end = datetime.combine(day, time(16), tzinfo=TIMEZONE)
    session.add(
        Attendance(
            employee_id=employee.id,
            device_id=device.id,
            attendance_date=day,
            check_in_at=check_in_local.astimezone(timezone.utc).replace(tzinfo=None),
            check_out_at=(
                check_out_local.astimezone(timezone.utc).replace(tzinfo=None)
                if check_out_local
                else None
            ),
            identification_method="qr",
            status="completed" if check_out_local else "open",
            worked_minutes=worked_minutes,
            late_minutes=late_minutes,
            early_departure_minutes=(
                max(
                    0,
                    int((expected_end - check_out_local).total_seconds() // 60),
                )
                if check_out_local
                else None
            ),
            overtime_minutes=(
                max(
                    0,
                    int((check_out_local - expected_end).total_seconds() // 60),
                )
                if check_out_local
                else None
            ),
        )
    )


def main() -> int:
    parser = argparse.ArgumentParser(description="Préparer la démonstration isolée.")
    parser.add_argument(
        "--database",
        type=Path,
        default=DEMO_DATABASE,
        help="Chemin vers un fichier SQLite de démonstration vide ou déjà initialisé.",
    )
    args = parser.parse_args()
    try:
        summary = seed_demo_database(args.database)
    except (ApplicationError, OSError) as error:
        parser.error(str(error))
        return 2
    print("Données de démonstration prêtes.")
    print(f"Base isolée : {summary['database']}")
    print(f"Images QR : {summary['qr_directory']}")
    print(f"Pointeuse : {summary['device']}")
    print(f"Date avec pointages : {summary['sample_date']}")
    print(f"Mot de passe démo (base locale uniquement) : {summary['password']}")
    for username, role_name in DEMO_USERS.items():
        print(f"  {username} — {role_name}")
    for employee_code, name in summary["employees"].items():
        print(f"  {employee_code} — {name}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
