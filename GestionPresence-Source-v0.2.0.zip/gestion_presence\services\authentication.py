"""Création d'utilisateurs et authentification locale."""

from datetime import datetime, timezone

from sqlalchemy import select
from sqlalchemy.orm import joinedload
from sqlalchemy.orm import Session

from gestion_presence.database.models import (
    AuditLog,
    Permission,
    Role,
    RolePermission,
    User,
    UserRole,
)
from gestion_presence.errors import (
    AuthenticationFailed,
    EntityNotFound,
    ValidationError,
)
from gestion_presence.services.rbac import RbacService
from gestion_presence.utils.security import hash_password, verify_password


class AuthenticationService:
    @staticmethod
    def list_users(session: Session, *, actor_user_id: int) -> list[User]:
        RbacService.require_permission(session, actor_user_id, "user.view")
        return list(
            session.scalars(
                select(User)
                .options(
                    joinedload(User.employee),
                    joinedload(User.user_roles).joinedload(UserRole.role),
                )
                .order_by(User.username)
            )
            .unique()
        )

    @staticmethod
    def create_user(
        session: Session,
        *,
        created_by: int,
        username: str,
        password: str,
        employee_id: int | None = None,
        role_id: int | None = None,
    ) -> User:
        RbacService.require_permission(session, created_by, "user.create")
        username = username.strip()
        if not username or len(username) > 80:
            raise ValidationError("Le nom d'utilisateur doit contenir de 1 à 80 caractères.")
        if len(password) < 12:
            raise ValidationError("Le mot de passe doit contenir au moins 12 caractères.")
        if session.scalar(select(User.id).where(User.username == username)) is not None:
            raise ValidationError("Ce nom d'utilisateur existe déjà.")
        if employee_id is not None:
            linked = session.scalar(
                select(User.id).where(User.employee_id == employee_id)
            )
            if linked is not None:
                raise ValidationError("Cet employé possède déjà un compte utilisateur.")
        user = User(
            username=username,
            password_hash=hash_password(password),
            employee_id=employee_id,
        )
        session.add(user)
        session.flush()
        if role_id is not None:
            RbacService.assign_role(
                session,
                user_id=user.id,
                role_id=role_id,
                assigned_by=created_by,
            )
        session.add(
            AuditLog(
                user_id=created_by,
                action="CREATE_USER",
                entity_type="user",
                entity_id=str(user.id),
                details={"username": username},
            )
        )
        session.flush()
        return user

    @staticmethod
    def authenticate(
        session: Session, *, username: str, password: str, now: datetime | None = None
    ) -> User:
        user = session.scalar(select(User).where(User.username == username.strip()))
        if user is None or not verify_password(password, user.password_hash):
            raise AuthenticationFailed("Nom d'utilisateur ou mot de passe invalide.")
        if not user.is_active:
            raise AuthenticationFailed("Ce compte utilisateur est désactivé.")

        current_time = now or datetime.now(timezone.utc)
        if current_time.tzinfo is None or current_time.utcoffset() is None:
            raise ValidationError("L'heure de connexion doit inclure un fuseau horaire.")
        user.last_login_at = current_time.astimezone(timezone.utc).replace(tzinfo=None)
        session.add(
            AuditLog(
                user_id=user.id,
                action="LOGIN",
                entity_type="user",
                entity_id=str(user.id),
            )
        )
        session.flush()
        return user

    @staticmethod
    def set_active(
        session: Session,
        user_id: int,
        *,
        actor_user_id: int,
        is_active: bool,
    ) -> User:
        RbacService.require_permission(session, actor_user_id, "user.update")
        user = session.get(User, user_id)
        if user is None:
            raise EntityNotFound(f"Utilisateur introuvable (id={user_id}).")
        user.is_active = is_active
        session.add(
            AuditLog(
                user_id=actor_user_id,
                action="UPDATE_USER_STATUS",
                entity_type="user",
                entity_id=str(user.id),
                details={"is_active": is_active},
            )
        )
        session.flush()
        return user

    @staticmethod
    def bootstrap_first_administrator(
        session: Session, *, username: str, password: str
    ) -> User:
        """Crée le premier administrateur uniquement sur une base sans utilisateur."""
        if session.scalar(select(User.id).limit(1)) is not None:
            raise ValidationError("Le compte initial existe déjà.")
        username = username.strip()
        if not username or len(username) > 80:
            raise ValidationError("Le nom d'utilisateur doit contenir de 1 à 80 caractères.")
        if len(password) < 12:
            raise ValidationError("Le mot de passe doit contenir au moins 12 caractères.")

        permission_names = (
            "employee.view",
            "employee.create",
            "employee.update",
            "employee.delete",
            "attendance.view",
            "attendance.create",
            "attendance.update",
            "report.view",
            "report.export",
            "user.view",
            "user.create",
            "user.update",
            "user.delete",
            "role.view",
            "role.create",
            "role.update",
            "role.delete",
            "device.view",
            "device.create",
            "device.update",
            "audit.view",
            "department.create",
            "department.update",
            "settings.view",
            "settings.update",
            "backup.create",
        )
        role = Role(
            name="ADMINISTRATEUR",
            description="Accès complet à l'application",
            is_system=True,
        )
        session.add(role)
        for permission_name in permission_names:
            session.add(
                Permission(
                    name=permission_name,
                    resource=permission_name.partition(".")[0],
                    description=f"Autorise l'action {permission_name}",
                )
            )
        session.flush()
        user = User(username=username, password_hash=hash_password(password))
        session.add(user)
        session.flush()
        for permission in session.scalars(select(Permission)):
            session.add(
                RolePermission(role_id=role.id, permission_id=permission.id)
            )
        session.add(UserRole(user_id=user.id, role_id=role.id))
        session.add(
            AuditLog(
                user_id=user.id,
                action="CREATE_INITIAL_ADMIN",
                entity_type="user",
                entity_id=str(user.id),
            )
        )
        session.flush()
        return user
