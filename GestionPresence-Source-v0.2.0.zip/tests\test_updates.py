import hashlib
import json
from pathlib import Path

import pytest

from gestion_presence.services import updates
from gestion_presence.services.updates import (
    UpdateCheckError,
    UpdateRelease,
    check_for_update,
    download_update,
)


def _release_payload(tag="v0.2.0"):
    return {
        "tag_name": tag,
        "name": f"Gestion des présences {tag}",
        "html_url": f"https://github.com/{updates.GITHUB_OWNER}/"
        f"{updates.GITHUB_REPOSITORY}/releases/tag/{tag}",
        "body": "Améliorations.",
        "assets": [
            {"id": 17, "name": updates.INSTALLER_ASSET_NAME, "size": 123},
            {
                "id": 18,
                "name": f"{updates.INSTALLER_ASSET_NAME}.sha256",
                "size": 86,
            },
        ],
    }


def test_check_for_update_returns_latest_valid_windows_release(monkeypatch):
    monkeypatch.setattr(
        updates,
        "_request_bytes",
        lambda *_args: json.dumps(_release_payload()).encode(),
    )

    release = check_for_update()

    assert release == UpdateRelease(
        version="0.2.0",
        title="Gestion des présences v0.2.0",
        page_url=(
            "https://github.com/BenjiMat92/gestion-de-presence/releases/tag/v0.2.0"
        ),
        notes="Améliorations.",
        installer_asset_id=17,
        installer_size=123,
        checksum_asset_id=18,
    )


def test_check_for_update_reports_current_release(monkeypatch):
    monkeypatch.setattr(
        updates,
        "_request_bytes",
        lambda *_args: json.dumps(_release_payload("v0.1.0")).encode(),
    )

    assert check_for_update() is None


def test_check_for_update_requires_installer_and_checksum(monkeypatch):
    payload = _release_payload()
    payload["assets"] = []
    monkeypatch.setattr(
        updates,
        "_request_bytes",
        lambda *_args: json.dumps(payload).encode(),
    )

    with pytest.raises(UpdateCheckError, match="installateur Windows"):
        check_for_update()


def test_download_update_checks_checksum_before_writing_destination(
    tmp_path: Path, monkeypatch
):
    installer = b"tested installer bytes"
    digest = hashlib.sha256(installer).hexdigest()
    release = UpdateRelease(
        version="0.2.0",
        title="Release",
        page_url="https://github.com/BenjiMat92/gestion-de-presence/releases/tag/v0.2.0",
        notes="",
        installer_asset_id=17,
        installer_size=len(installer),
        checksum_asset_id=18,
    )

    class Response:
        def __init__(self):
            self._data = installer

        def __enter__(self):
            return self

        def __exit__(self, *_args):
            return None

        def read(self, _size=-1):
            data, self._data = self._data, b""
            return data

    class Opener:
        def open(self, *_args, **_kwargs):
            return Response()

    monkeypatch.setattr(
        updates,
        "_request_bytes",
        lambda *_args: f"{digest}  {updates.INSTALLER_ASSET_NAME}\n".encode(),
    )
    monkeypatch.setattr(updates, "build_opener", lambda *_args: Opener())
    destination = tmp_path / "release.exe"

    saved = download_update(release, destination)

    assert saved == destination.resolve()
    assert saved.read_bytes() == installer


def test_download_update_rejects_bad_checksum_and_keeps_existing_file(
    tmp_path: Path, monkeypatch
):
    release = UpdateRelease(
        version="0.2.0",
        title="Release",
        page_url="https://github.com/BenjiMat92/gestion-de-presence/releases/tag/v0.2.0",
        notes="",
        installer_asset_id=17,
        installer_size=4,
        checksum_asset_id=18,
    )

    class Response:
        def __enter__(self):
            return self

        def __exit__(self, *_args):
            return None

        def read(self, _size=-1):
            if not hasattr(self, "sent"):
                self.sent = True
                return b"evil"
            return b""

    class Opener:
        def open(self, *_args, **_kwargs):
            return Response()

    monkeypatch.setattr(
        updates,
        "_request_bytes",
        lambda *_args: (b"0" * 64) + b"  installer.exe\n",
    )
    monkeypatch.setattr(updates, "build_opener", lambda *_args: Opener())
    destination = tmp_path / "release.exe"
    destination.write_bytes(b"old")

    with pytest.raises(UpdateCheckError, match="SHA-256"):
        download_update(release, destination)

    assert destination.read_bytes() == b"old"
    assert list(tmp_path.glob("*.download")) == []
