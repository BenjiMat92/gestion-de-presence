from datetime import datetime, timezone
from zoneinfo import ZoneInfo

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from gestion_presence.database.connection import create_engine
from gestion_presence.database.models import Attendance, Employee, Role, User
from gestion_presence.demo import DEMO_PASSWORD, DEMO_USERS, seed_demo_database
from gestion_presence.services.authentication import AuthenticationService


def test_demo_seed_creates_isolated_users_data_and_qr_images(tmp_path):
    database_path = tmp_path / ".demo" / "demo.db"
    result = seed_demo_database(database_path)

    assert result["database"] == database_path.resolve()
    assert result["qr_directory"] == database_path.parent / "qr_codes"
    assert set(result["accounts"]) == set(DEMO_USERS)
    assert len(result["employees"]) == 5
    assert all(
        (result["qr_directory"] / f"{employee_code}.png").is_file()
        for employee_code in result["employees"]
    )

    engine = create_engine(f"sqlite:///{database_path.as_posix()}")
    try:
        with Session(engine) as session:
            assert session.scalar(select(func.count(User.id))) == 3
            assert session.scalar(select(func.count(Employee.id))) == 5
            assert session.scalar(select(func.count(Role.id))) == 3
            assert session.scalar(select(func.count(Attendance.id))) >= 5
            for username in DEMO_USERS:
                user = AuthenticationService.authenticate(
                    session,
                    username=username,
                    password=DEMO_PASSWORD,
                    now=datetime(2026, 10, 3, 8, 0, tzinfo=timezone.utc),
                )
                assert user.is_active
    finally:
        engine.dispose()


def test_demo_seed_is_idempotent(tmp_path):
    database_path = tmp_path / "demo.db"
    seed_demo_database(database_path)
    seed_demo_database(database_path)

    engine = create_engine(f"sqlite:///{database_path.as_posix()}")
    try:
        with Session(engine) as session:
            assert session.scalar(select(func.count(User.id))) == 3
            assert session.scalar(select(func.count(Employee.id))) == 5
            assert session.scalar(
                select(func.count(Attendance.id)).where(
                    Attendance.attendance_date == datetime.now(
                        ZoneInfo("Africa/Kinshasa")
                    ).date()
                )
            ) in {1, 2}
    finally:
        engine.dispose()
