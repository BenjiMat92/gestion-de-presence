"""Lecture et mise à jour des paramètres applicatifs persistants."""

from sqlalchemy.orm import Session

from gestion_presence.database.models import AuditLog, Setting
from gestion_presence.errors import ValidationError
from gestion_presence.services.rbac import RbacService


class SettingsService:
    @staticmethod
    def get(session: Session, key: str, *, actor_user_id: int) -> str | None:
        RbacService.require_permission(session, actor_user_id, "settings.view")
        setting = session.get(Setting, key)
        return setting.value if setting is not None else None

    @staticmethod
    def set(
        session: Session,
        *,
        actor_user_id: int,
        key: str,
        value: str,
        description: str | None = None,
    ) -> Setting:
        RbacService.require_permission(session, actor_user_id, "settings.update")
        if not key.strip():
            raise ValidationError("La clé du paramètre est obligatoire.")
        setting = session.get(Setting, key)
        if setting is None:
            setting = Setting(key=key.strip(), value=value)
            session.add(setting)
        else:
            setting.value = value
        setting.description = description
        setting.updated_by = actor_user_id
        session.add(
            AuditLog(
                user_id=actor_user_id,
                action="UPDATE_SETTING",
                entity_type="setting",
                entity_id=setting.key,
            )
        )
        session.flush()
        return setting
