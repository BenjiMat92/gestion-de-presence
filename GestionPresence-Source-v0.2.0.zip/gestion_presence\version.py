"""Version de développement; le workflow Release la remplace depuis le tag."""

__version__ = "0.2.0"
