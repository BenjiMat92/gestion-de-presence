# Schéma SQLite

Le schéma couvre les 12 tables du périmètre C01–C12. Les clés étrangères,
contraintes d'unicité et index sont déclarés dans les modèles SQLAlchemy. Les
clés étrangères SQLite sont activées par connexion.

## Choix de conception

- Les employés ont une clé technique entière et un code public `EMP-AAAA-NNNNNN`.
  `EmployeeRepository.create()` produit ce code dans la transaction de création.
  La clé SQLite utilise `AUTOINCREMENT` : un identifiant supprimé n'est pas
  réattribué.
- Les horaires sont définis par employé et jour de semaine (`0` = lundi,
  `6` = dimanche), avec dates d'effet, pause et tolérance.
- Une seule ligne de pointage est autorisée par employé et par jour. Les entrées
  et sorties sont stockées comme dates-heures sans fuseau dans SQLite ; la couche
  applicative doit leur fournir et interpréter des valeurs UTC.
- La méthode d'identification accepte `qr`, `fingerprint` ou `manual`. Le schéma
  prépare l'empreinte sans prétendre intégrer un lecteur.
- La suppression d'un employé pointé est refusée ; les employés sont à désactiver.

## Initialisation

```python
from gestion_presence.database import (
    create_database,
    create_database_file,
    create_engine,
)

engine = create_engine("sqlite:///gestion_presence.db")
create_database(engine)
```

Pour créer le fichier et ses dossiers parents, utiliser
`create_database_file("data/gestion_presence.db")`.

Les tests couvrent la création du schéma, le CRUD, les relations, les
contraintes, les index et la non-réutilisation des codes employés.
