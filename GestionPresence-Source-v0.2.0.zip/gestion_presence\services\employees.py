"""Règles métier de gestion des employés."""

from datetime import date

from sqlalchemy import or_, select
from sqlalchemy.orm import Session

from gestion_presence.database.models import AuditLog, Department, Employee
from gestion_presence.errors import EntityNotFound, ValidationError
from gestion_presence.repositories.employees import EmployeeRepository
from gestion_presence.services.rbac import RbacService


class EmployeeService:
    """Création, recherche et modification des employés."""

    @staticmethod
    def create(
        session: Session,
        *,
        actor_user_id: int,
        first_name: str,
        last_name: str,
        department_id: int | None = None,
        job_title: str | None = None,
        phone: str | None = None,
        hire_date: date | None = None,
    ) -> Employee:
        RbacService.require_permission(session, actor_user_id, "employee.create")
        first_name = first_name.strip()
        last_name = last_name.strip()
        if not first_name or not last_name:
            raise ValidationError("Le nom et le prénom sont obligatoires.")
        if department_id is not None:
            department = session.get(Department, department_id)
            if department is None or not department.is_active:
                raise EntityNotFound("Le service demandé n'existe pas ou est désactivé.")

        employee = EmployeeRepository.create(
            session,
            first_name=first_name,
            last_name=last_name,
            department_id=department_id,
            job_title=job_title.strip() if job_title else None,
            phone=phone.strip() if phone else None,
            hire_date=hire_date,
        )
        session.add(
            AuditLog(
                user_id=actor_user_id,
                action="CREATE_EMPLOYEE",
                entity_type="employee",
                entity_id=employee.employee_code,
            )
        )
        session.flush()
        return employee

    @staticmethod
    def get_by_id(
        session: Session, employee_id: int, *, actor_user_id: int
    ) -> Employee:
        RbacService.require_permission(session, actor_user_id, "employee.view")
        employee = session.get(Employee, employee_id)
        if employee is None:
            raise EntityNotFound(f"Employé introuvable (id={employee_id}).")
        return employee

    @staticmethod
    def get_by_code(
        session: Session, employee_code: str, *, actor_user_id: int
    ) -> Employee:
        RbacService.require_permission(session, actor_user_id, "employee.view")
        employee = session.scalar(
            select(Employee).where(Employee.employee_code == employee_code.strip())
        )
        if employee is None:
            raise EntityNotFound(f"Employé introuvable ({employee_code}).")
        return employee

    @staticmethod
    def search(
        session: Session,
        *,
        actor_user_id: int,
        query: str | None = None,
        department_id: int | None = None,
        include_inactive: bool = False,
    ) -> list[Employee]:
        RbacService.require_permission(session, actor_user_id, "employee.view")
        statement = select(Employee)
        if not include_inactive:
            statement = statement.where(Employee.is_active.is_(True))
        if department_id is not None:
            statement = statement.where(Employee.department_id == department_id)
        if query and query.strip():
            term = f"%{query.strip()}%"
            statement = statement.where(
                or_(
                    Employee.employee_code.ilike(term),
                    Employee.first_name.ilike(term),
                    Employee.last_name.ilike(term),
                )
            )
        statement = statement.order_by(Employee.last_name, Employee.first_name)
        return list(session.scalars(statement))

    @staticmethod
    def update(
        session: Session,
        employee_id: int,
        *,
        actor_user_id: int,
        **changes: object,
    ) -> Employee:
        RbacService.require_permission(session, actor_user_id, "employee.update")
        allowed_fields = {
            "first_name",
            "last_name",
            "department_id",
            "job_title",
            "phone",
            "hire_date",
            "is_active",
        }
        invalid_fields = changes.keys() - allowed_fields
        if invalid_fields:
            raise ValidationError(
                f"Champs employé non modifiables : {', '.join(sorted(invalid_fields))}"
            )

        employee = session.get(Employee, employee_id)
        if employee is None:
            raise EntityNotFound(f"Employé introuvable (id={employee_id}).")
        if "first_name" in changes:
            first_name = str(changes["first_name"]).strip()
            if not first_name:
                raise ValidationError("Le prénom est obligatoire.")
            changes["first_name"] = first_name
        if "last_name" in changes:
            last_name = str(changes["last_name"]).strip()
            if not last_name:
                raise ValidationError("Le nom est obligatoire.")
            changes["last_name"] = last_name
        if "department_id" in changes and changes["department_id"] is not None:
            department = session.get(Department, int(changes["department_id"]))
            if department is None or not department.is_active:
                raise EntityNotFound("Le service demandé n'existe pas ou est désactivé.")

        for field, value in changes.items():
            setattr(employee, field, value)
        session.add(
            AuditLog(
                user_id=actor_user_id,
                action="UPDATE_EMPLOYEE",
                entity_type="employee",
                entity_id=employee.employee_code,
                details={"changed_fields": sorted(changes)},
            )
        )
        session.flush()
        return employee

    @staticmethod
    def deactivate(
        session: Session, employee_id: int, *, actor_user_id: int
    ) -> Employee:
        return EmployeeService.update(
            session, employee_id, actor_user_id=actor_user_id, is_active=False
        )

    @staticmethod
    def activate(
        session: Session, employee_id: int, *, actor_user_id: int
    ) -> Employee:
        return EmployeeService.update(
            session, employee_id, actor_user_id=actor_user_id, is_active=True
        )
