"""Fenêtre Tkinter principale et navigation filtrée par RBAC."""

from __future__ import annotations

import logging
import queue
import threading
import tkinter as tk
from tkinter import ttk

from sqlalchemy.orm import Session, sessionmaker

from gestion_presence.config import Settings
from gestion_presence.database.models import Setting, User
from gestion_presence.i18n import (
    LANGUAGE_SETTING_KEY,
    localize_widget_tree,
    set_language,
    translate,
)
from gestion_presence.services.updates import UpdateRelease, check_for_update
from gestion_presence.services.rbac import RbacService
from gestion_presence.ui.admin_pages import (
    AuditPage,
    DashboardPage,
    DepartmentPage,
    DevicePage,
    ReportPage,
    RolePage,
    SchedulePage,
    SettingsPage,
    UserPage,
)
from gestion_presence.ui.attendance_page import AttendancePage
from gestion_presence.ui.employee_page import EmployeePage
from gestion_presence.ui.login_dialog import LoginDialog

logger = logging.getLogger(__name__)


class MainWindow(tk.Toplevel):
    def __init__(
        self,
        parent,
        session_factory: sessionmaker[Session],
        settings: Settings,
        user_id: int,
        startup_update: UpdateRelease | None = None,
    ) -> None:
        super().__init__(parent)
        self.session_factory = session_factory
        self.settings = settings
        self.user_id = user_id
        self.startup_update = startup_update
        set_language(self._read_language())
        self.logout_requested = False
        self._camera_page: AttendancePage | None = None
        self.title("Gestion des présences")
        self.geometry("1440x900")
        self.minsize(1024, 680)
        self.configure(bg="#f4f7fb")

        self._configure_styles()
        user = self._load_user()
        self.columnconfigure(1, weight=1)
        self.rowconfigure(0, weight=1)

        sidebar = ttk.Frame(self, style="Sidebar.TFrame", padding=(12, 18))
        sidebar.grid(row=0, column=0, sticky="ns")
        sidebar.configure(width=235)
        sidebar.grid_propagate(False)
        ttk.Label(sidebar, text="POINTAGE", style="Brand.TLabel").pack(
            anchor="w", pady=(2, 8)
        )
        ttk.Label(sidebar, text=user.username, style="SidebarUser.TLabel").pack(
            anchor="w", pady=(0, 18)
        )
        self.navigation = ttk.Frame(sidebar, style="Sidebar.TFrame")
        self.navigation.pack(fill="both", expand=True)
        ttk.Button(
            sidebar,
            text="Déconnexion",
            command=self._logout,
            style="Sidebar.TButton",
        ).pack(fill="x", pady=(12, 0))

        self.page_host = ttk.Frame(self, style="App.TFrame")
        self.page_host.grid(row=0, column=1, sticky="nsew")
        self.page_host.rowconfigure(0, weight=1)
        self.page_host.columnconfigure(0, weight=1)
        self.pages_by_key: dict[str, ttk.Frame] = {}
        self.navigation_buttons: list[ttk.Button] = []
        self._register_pages()
        localize_widget_tree(self)
        self.protocol("WM_DELETE_WINDOW", self._close)
        if self.navigation_buttons:
            self.navigation_buttons[0].invoke()

    def _configure_styles(self) -> None:
        style = ttk.Style(self)
        style.configure("App.TFrame", background="#f4f7fb")
        style.configure("Sidebar.TFrame", background="#172554")
        style.configure(
            "Brand.TLabel",
            background="#172554",
            foreground="white",
            font=("Segoe UI", 17, "bold"),
        )
        style.configure(
            "SidebarUser.TLabel",
            background="#172554",
            foreground="#cbd5e1",
            font=("Segoe UI", 10),
        )
        style.configure(
            "Sidebar.TButton",
            anchor="w",
            background="#172554",
            foreground="#dbeafe",
            padding=(10, 10),
            font=("Segoe UI", 10),
        )
        style.map(
            "Sidebar.TButton",
            background=[("active", "#1d4ed8")],
            foreground=[("active", "white")],
        )
        style.configure("PageTitle.TLabel", font=("Segoe UI", 20, "bold"))
        style.configure("Metric.TLabel", font=("Segoe UI", 18, "bold"),
                        foreground="#1d4ed8")
        style.configure("Primary.TButton", padding=(12, 8))
        style.configure("Treeview", rowheight=27)
        style.configure("Treeview.Heading", font=("Segoe UI", 9, "bold"))

    def _load_user(self) -> User:
        with self.session_factory() as session:
            user = session.get(User, self.user_id)
            if user is None or not user.is_active:
                raise RuntimeError("Le compte de la session n'est plus actif.")
            session.expunge(user)
            return user

    def _read_language(self) -> str:
        with self.session_factory() as session:
            language = session.get(Setting, LANGUAGE_SETTING_KEY)
            return language.value if language and language.value in {"fr", "en"} else "fr"

    def _has_permission(self, permission: str) -> bool:
        with self.session_factory() as session:
            return RbacService.has_permission(session, self.user_id, permission)

    def _register_pages(self) -> None:
        specs = [
            PageSpec("dashboard", "Tableau de bord", "report.view",
                    lambda: DashboardPage(self.page_host, self.session_factory, self.settings,
                                          self.user_id)),
            PageSpec("attendance", "Pointage QR", "attendance.create",
                    lambda: AttendancePage(self.page_host, self.session_factory, self.settings,
                                           self.user_id)),
            PageSpec("employees", "Employés", "employee.view",
                    lambda: EmployeePage(self.page_host, self.session_factory, self.user_id)),
            PageSpec("departments", "Services", "employee.view",
                    lambda: DepartmentPage(self.page_host, self.session_factory, self.user_id)),
            PageSpec("schedules", "Horaires", "employee.view",
                    lambda: SchedulePage(self.page_host, self.session_factory, self.user_id)),
            PageSpec("reports", "Rapports", "report.view",
                    lambda: ReportPage(self.page_host, self.session_factory, self.user_id,
                                       self.settings)),
            PageSpec("users", "Utilisateurs", "user.view",
                    lambda: UserPage(self.page_host, self.session_factory, self.user_id)),
            PageSpec("roles", "Rôles et permissions", "role.view",
                    lambda: RolePage(self.page_host, self.session_factory, self.user_id)),
            PageSpec("devices", "Pointeuses", "device.view",
                    lambda: DevicePage(self.page_host, self.session_factory, self.user_id)),
            PageSpec("audit", "Journal d'audit", "audit.view",
                    lambda: AuditPage(self.page_host, self.session_factory, self.user_id)),
            PageSpec("settings", "Configuration", "settings.view",
                    lambda: SettingsPage(self.page_host, self.session_factory, self.settings,
                                         self.user_id,
                                         startup_update=self.startup_update)),
        ]
        for spec in specs:
            if not self._has_permission(spec.permission):
                continue
            page = spec.factory()
            page.grid(row=0, column=0, sticky="nsew")
            page.grid_remove()
            self.pages_by_key[spec.key] = page
            button = ttk.Button(
                self.navigation,
                text=spec.label,
                style="Sidebar.TButton",
                command=lambda key=spec.key: self._show_page(key),
            )
            button.pack(fill="x", pady=2)
            self.navigation_buttons.append(button)

    def _show_page(self, key: str) -> None:
        previous = getattr(self, "_active_page", None)
        if isinstance(previous, AttendancePage):
            previous._stop_camera()
        page = self.pages_by_key[key]
        page.grid()
        page.tkraise()
        self._active_page = page
        refresh = getattr(page, "refresh", None)
        if callable(refresh):
            refresh()

    def _logout(self) -> None:
        self.logout_requested = True
        self._close()

    def _close(self) -> None:
        page = getattr(self, "_active_page", None)
        if isinstance(page, AttendancePage):
            page._stop_camera()
        self.destroy()


class PageSpec:
    def __init__(self, key, label, permission, factory):
        self.key = key
        self.label = label
        self.permission = permission
        self.factory = factory


def launch_desktop(
    settings: Settings,
    session_factory: sessionmaker[Session],
    engine,
) -> int:
    exit_code = 0
    root = tk.Tk()
    root.title(translate("Démarrage — Gestion des présences"))
    root.geometry("1280x760")
    root.minsize(1000, 650)
    root.configure(bg="#f0f5fb")

    colors = {
        "background": "#f0f5fb",
        "teal": "#70aeac",
        "navy": "#082e76",
        "blue": "#155386",
        "panel": "#126d76",
        "bar": "#117a72",
        "muted": "#74839a",
        "white": "#ffffff",
        "hint": "#dfe8f0",
    }
    status = tk.StringVar(
        master=root, value=translate("Initialisation de l'application…")
    )
    task = tk.StringVar(
        master=root, value=translate("Initialisation de la base et préparation de l'interface")
    )
    progress_value = tk.DoubleVar(master=root, value=18)
    percent = tk.StringVar(master=root, value="18%")

    background = tk.Canvas(
        root, background=colors["background"], highlightthickness=0
    )
    background.pack(fill="both", expand=True)
    card = ttk.Frame(root, style="Startup.Card.TFrame")
    card_window = background.create_window(0, 0, window=card, anchor="center")
    card.grid_rowconfigure(0, weight=1)
    card.grid_columnconfigure(0, weight=0, minsize=330)
    card.grid_columnconfigure(1, weight=1)

    welcome = tk.Canvas(
        card, background=colors["blue"], highlightthickness=0
    )
    welcome.grid(row=0, column=0, sticky="nsew")

    detail = ttk.Frame(card, style="Startup.Detail.TFrame", padding=(36, 24))
    detail.grid(row=0, column=1, sticky="nsew")
    detail.grid_columnconfigure(0, weight=1)
    style = ttk.Style(root)
    style.configure("Startup.Card.TFrame", background=colors["white"])
    style.configure("Startup.Detail.TFrame", background=colors["white"])
    style.configure(
        "Startup.Logo.TFrame", background="#f2f6f8", padding=(14, 9)
    )
    style.configure(
        "Startup.Title.TLabel",
        background=colors["white"],
        foreground="#172033",
        font=("Segoe UI", 23, "bold"),
    )
    style.configure(
        "Startup.Subtitle.TLabel",
        background=colors["white"],
        foreground=colors["muted"],
        font=("Segoe UI", 11),
    )
    style.configure(
        "Startup.Task.TLabel",
        background=colors["white"],
        foreground="#172033",
        font=("Segoe UI", 17, "bold"),
    )
    style.configure(
        "Startup.Status.TLabel",
        background=colors["white"],
        foreground=colors["muted"],
        font=("Segoe UI", 10),
    )
    style.configure(
        "Startup.Percent.TLabel",
        background=colors["white"],
        foreground=colors["panel"],
        font=("Segoe UI", 17, "bold"),
    )
    style.configure(
        "Startup.Progress.Horizontal.TProgressbar",
        troughcolor=colors["hint"],
        background=colors["bar"],
        bordercolor=colors["hint"],
        lightcolor=colors["bar"],
        darkcolor=colors["bar"],
        thickness=20,
    )

    logo = ttk.Frame(detail, style="Startup.Logo.TFrame")
    logo.grid(row=0, column=0, sticky="w", pady=(0, 18))
    logo_canvas = tk.Canvas(
        logo, width=190, height=56, background="#f2f6f8", highlightthickness=0
    )
    logo_canvas.pack()
    logo_canvas.create_text(
        4, 9, text=translate("Démarrage sécurisé"),
        anchor="nw", fill=colors["panel"], font=("Segoe UI", 9, "bold")
    )
    logo_canvas.create_oval(10, 29, 38, 55, outline=colors["panel"], width=3)
    logo_canvas.create_rectangle(20, 32, 28, 52, fill=colors["panel"], outline="")
    logo_canvas.create_rectangle(14, 38, 34, 46, fill=colors["panel"], outline="")
    logo_canvas.create_text(
        44, 37, text="GESTION",
        anchor="w", fill=colors["navy"], font=("Segoe UI", 10, "bold")
    )
    logo_canvas.create_text(
        44, 49, text=translate("DES PRÉSENCES"),
        anchor="w", fill=colors["muted"], font=("Segoe UI", 6, "bold")
    )
    ttk.Label(
        detail,
        text=translate("Ouverture de l'application"),
        style="Startup.Title.TLabel",
    ).grid(row=1, column=0, sticky="w")
    ttk.Label(
        detail,
        text=translate("Progression du démarrage"),
        style="Startup.Subtitle.TLabel",
    ).grid(row=2, column=0, sticky="w", pady=(2, 24))
    ttk.Label(
        detail, textvariable=task, style="Startup.Task.TLabel", wraplength=620
    ).grid(row=3, column=0, sticky="w", pady=(0, 5))
    ttk.Label(
        detail, text=translate("Progression"), style="Startup.Status.TLabel"
    ).grid(row=4, column=0, sticky="w")

    progress_row = ttk.Frame(detail, style="Startup.Detail.TFrame")
    progress_row.grid(row=5, column=0, sticky="ew", pady=(0, 27))
    progress_row.grid_columnconfigure(0, weight=1)
    progress = ttk.Progressbar(
        progress_row,
        maximum=100,
        variable=progress_value,
        style="Startup.Progress.Horizontal.TProgressbar",
    )
    progress.grid(row=0, column=0, sticky="ew", pady=(22, 0))
    ttk.Label(
        progress_row, textvariable=percent, style="Startup.Percent.TLabel"
    ).grid(row=0, column=0, sticky="e", padx=(0, 8), pady=(0, 3))
    ttk.Label(
        detail,
        textvariable=status,
        style="Startup.Status.TLabel",
        wraplength=640,
    ).grid(row=6, column=0, sticky="w", pady=(4, 18))
    ttk.Label(
        detail,
        text=translate("Base • Interface • Contrôles • Journalisation"),
        style="Startup.Status.TLabel",
    ).grid(row=7, column=0, sticky="w")

    def draw_background(event) -> None:
        width = max(event.width, 1)
        height = max(event.height, 1)
        background.delete("decoration")
        background.create_oval(
            -width * 0.18, height * 0.04, width * 0.43, height * 0.98,
            fill=colors["teal"], outline="", tags="decoration",
        )
        background.create_oval(
            width * 0.69, -height * 0.35, width * 1.2, height * 0.45,
            fill="#f1e2c4", outline="", tags="decoration",
        )
        background.create_oval(
            width * 0.55, height * 0.51, width * 1.24, height * 1.28,
            fill="#c1d5d5", outline="", tags="decoration",
        )
        background.tag_raise(card_window)
        background.coords(
            card_window, width / 2, height / 2
        )
        background.itemconfigure(
            card_window,
            width=min(1050, width - 56),
            height=min(520, height - 56),
        )

    def draw_welcome(event) -> None:
        width = max(event.width, 1)
        height = max(event.height, 1)
        welcome.delete("art")
        welcome.create_oval(
            -width * 0.08, height * 0.12, width * 1.16, height * 1.2,
            fill="#0f7780", outline="", tags="art",
        )
        welcome.create_oval(
            width * 0.05, height * 0.04, width * 0.95, height * 1.14,
            fill=colors["blue"], outline="", tags="art",
        )
        welcome.create_arc(
            width * 0.05, height * 0.07, width * 0.95, height * 1.12,
            start=44, extent=272, style="arc", outline="#b4a326", width=12,
            tags="art",
        )
        welcome.create_arc(
            width * 0.11, height * 0.15, width * 0.88, height * 1.03,
            start=44, extent=270, style="arc", outline="#16857f", width=7,
            tags="art",
        )
        welcome.create_oval(
            width * 0.09, height * 0.06, width * 0.25, height * 0.17,
            fill="#eaf2f6", outline="", tags="art",
        )
        welcome.create_text(
            width * 0.12, height * 0.40,
            text=translate("Chargement intelligent"),
            anchor="w", width=width * 0.76, fill=colors["white"],
            font=("Segoe UI", 22, "bold"), justify="left", tags="art",
        )
        welcome.create_text(
            width * 0.12, height * 0.63,
            text=translate(
                "Le poste prépare la base, l'interface et les contrôles pour "
                "ouvrir votre espace de gestion dans de bonnes conditions."
            ),
            anchor="w", width=width * 0.76, fill="#e1edf3",
            font=("Segoe UI", 10), justify="left", tags="art",
        )

    def render_progress(value: int) -> None:
        progress_value.set(value)
        percent.set(f"{value}%")

    startup_check_finished = False

    def advance_progress() -> None:
        if startup_check_finished:
            return
        current = int(progress_value.get())
        if current < 90:
            render_progress(min(90, current + 2))
        elif str(progress.cget("mode")) != "indeterminate":
            progress.configure(mode="indeterminate")
            progress.start(12)
        root.after(180, advance_progress)

    background.bind("<Configure>", draw_background)
    welcome.bind("<Configure>", draw_welcome)

    update_results: queue.Queue[
        tuple[UpdateRelease | None, Exception | None]
    ] = queue.Queue()
    startup_update: UpdateRelease | None = None

    def check_updates_in_background() -> None:
        try:
            update_results.put((check_for_update(), None))
        except Exception as error:
            update_results.put((None, error))

    def run_login_sessions() -> None:
        nonlocal exit_code
        progress.stop()
        root.withdraw()
        while True:
            login = LoginDialog(root, session_factory)
            root.wait_window(login.window)
            if login.user_id is None:
                break
            window = MainWindow(
                root,
                session_factory,
                settings,
                login.user_id,
                startup_update=startup_update,
            )
            root.wait_window(window)
            exit_code = 0
            if not window.logout_requested:
                break
        root.quit()

    def finish_startup_check() -> None:
        nonlocal startup_update, startup_check_finished
        try:
            release, error = update_results.get_nowait()
        except queue.Empty:
            root.after(100, finish_startup_check)
            return

        startup_check_finished = True
        progress.stop()
        progress.configure(mode="determinate", maximum=100)
        if error is not None:
            logger.warning("Vérification des mises à jour au démarrage impossible: %s", error)
            status.set(
                translate("Vérification indisponible; démarrage de l'application…")
            )
            task.set(translate("Finalisation du démarrage"))
        elif release is not None:
            startup_update = release
            task.set(translate("Nouvelle version détectée"))
            status.set(
                translate("Version {version} disponible. Chargement…").format(
                    version=release.version
                )
            )
        else:
            task.set(translate("Sécurisation du poste et des modules"))
            status.set(translate("Vérification terminée. Chargement…"))
        render_progress(96)

        def complete_progress() -> None:
            render_progress(100)
            root.after(250, run_login_sessions)

        root.after(350, complete_progress)

    try:
        with session_factory() as session:
            language_setting = session.get(Setting, LANGUAGE_SETTING_KEY)
            language = (
                language_setting.value
                if language_setting and language_setting.value in {"fr", "en"}
                else "fr"
            )
        set_language(language)
        localize_widget_tree(root, language)
        status.set(translate("Vérification des mises à jour…"))
        root.deiconify()
        root.after(180, advance_progress)
        threading.Thread(target=check_updates_in_background, daemon=True).start()
        root.after(100, finish_startup_check)
        root.mainloop()
    finally:
        root.destroy()
        engine.dispose()
    return exit_code
