"""Fabrique de sessions SQLAlchemy."""

from sqlalchemy import Engine
from sqlalchemy.orm import Session, sessionmaker


def create_session_factory(engine: Engine) -> sessionmaker[Session]:
    """Construit une fabrique pour des sessions transactionnelles."""
    return sessionmaker(bind=engine, expire_on_commit=False)
