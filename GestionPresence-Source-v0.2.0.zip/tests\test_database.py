from datetime import date, datetime, time

import pytest
from sqlalchemy import inspect, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from gestion_presence.database import create_database_file
from gestion_presence.database.connection import create_database, create_engine
from gestion_presence.database.models import (
    Attendance,
    AuditLog,
    Department,
    Device,
    Employee,
    Permission,
    Role,
    RolePermission,
    Setting,
    User,
    UserRole,
    WorkSchedule,
)
from gestion_presence.repositories.employees import EmployeeRepository


@pytest.fixture
def engine():
    test_engine = create_engine("sqlite:///:memory:")
    create_database(test_engine)
    yield test_engine
    test_engine.dispose()


def test_creates_all_required_tables_and_indexes(engine):
    database_inspector = inspect(engine)

    assert set(database_inspector.get_table_names()) == {
        "employees",
        "departments",
        "users",
        "roles",
        "permissions",
        "user_roles",
        "role_permissions",
        "attendance",
        "work_schedules",
        "devices",
        "audit_logs",
        "settings",
    }
    assert "ix_attendance_date_status" in {
        index["name"] for index in database_inspector.get_indexes("attendance")
    }
    assert "ix_audit_logs_occurred_at" in {
        index["name"] for index in database_inspector.get_indexes("audit_logs")
    }


def test_creates_sqlite_database_file_and_parent_directories(tmp_path):
    database_path = tmp_path / "data" / "attendance.db"
    file_engine = create_database_file(database_path)
    try:
        assert database_path.is_file()
        assert set(inspect(file_engine).get_table_names()) == {
            "employees",
            "departments",
            "users",
            "roles",
            "permissions",
            "user_roles",
            "role_permissions",
            "attendance",
            "work_schedules",
            "devices",
            "audit_logs",
            "settings",
        }
    finally:
        file_engine.dispose()


def test_crud_and_relationships_across_schema(engine):
    with Session(engine) as session:
        department = Department(code="IT", name="Informatique")
        role = Role(name="RH", description="Gestion des ressources humaines")
        permission = Permission(
            name="employee.view", resource="employee", description="Voir les employés"
        )
        device = Device(
            device_code="DEVICE-001",
            name="Entrée principale",
            location="Accueil",
            device_type="qr",
        )
        session.add_all([department, role, permission, device])
        session.flush()

        employee = EmployeeRepository.create(
            session,
            first_name="Jean",
            last_name="Kabila",
            department_id=department.id,
            job_title="Technicien",
            phone="+243000000000",
            hire_date=date(2026, 1, 5),
        )
        user = User(
            username="rh01",
            password_hash="test-hash",
            employee_id=employee.id,
        )
        session.add(user)
        session.flush()
        session.add_all(
            [
                UserRole(user_id=user.id, role_id=role.id, assigned_by=user.id),
                RolePermission(role_id=role.id, permission_id=permission.id),
                WorkSchedule(
                    employee_id=employee.id,
                    name="Horaire standard",
                    day_of_week=0,
                    start_time=time(8, 0),
                    end_time=time(16, 0),
                    break_minutes=30,
                    grace_period_minutes=5,
                    effective_from=date(2026, 1, 1),
                ),
                Attendance(
                    employee_id=employee.id,
                    device_id=device.id,
                    attendance_date=date(2026, 10, 3),
                    check_in_at=datetime(2026, 10, 3, 7, 52),
                    check_out_at=datetime(2026, 10, 3, 16, 5),
                    identification_method="qr",
                    status="completed",
                    worked_minutes=463,
                    late_minutes=0,
                ),
                AuditLog(
                    user_id=user.id,
                    action="UPDATE_EMPLOYEE",
                    entity_type="employee",
                    entity_id=employee.employee_code,
                    result="success",
                    details={"changed_field": "job_title"},
                ),
                Setting(
                    key="organization.name",
                    value="Entreprise",
                    updated_by=user.id,
                ),
            ]
        )
        session.commit()

        employee_id = employee.id
        employee_code = employee.employee_code
        assert employee_code.startswith(f"EMP-{date.today().year}-")
        assert user.user_roles[0].role.name == "RH"
        assert role.role_permissions[0].permission.name == "employee.view"
        assert employee.attendances[0].device.device_code == "DEVICE-001"
        assert employee.work_schedules[0].grace_period_minutes == 5
        assert session.scalar(select(AuditLog)).details == {"changed_field": "job_title"}
        assert session.get(Setting, "organization.name").value == "Entreprise"

        employee.job_title = "Administrateur systèmes"
        session.commit()
        assert session.get(Employee, employee_id).job_title == "Administrateur systèmes"

        session.delete(session.get(Attendance, 1))
        session.commit()
        assert session.scalar(select(Attendance)) is None


def test_employee_code_is_generated_and_not_reused_after_delete(engine):
    with Session(engine) as session:
        first = EmployeeRepository.create(
            session, first_name="A", last_name="Premier"
        )
        session.commit()
        first_id = first.id
        first_code = first.employee_code

        session.delete(first)
        session.commit()

        second = EmployeeRepository.create(
            session, first_name="B", last_name="Deuxième"
        )
        session.commit()

        assert second.id > first_id
        assert second.employee_code != first_code
        assert second.employee_code == f"EMP-{date.today().year}-{second.id:06d}"


def test_database_rejects_duplicate_codes_and_daily_attendance(engine):
    with Session(engine) as session:
        employee = EmployeeRepository.create(
            session, first_name="Jean", last_name="Kabila"
        )
        session.commit()

        duplicate_employee = Employee(
            employee_code=employee.employee_code,
            first_name="Marie",
            last_name="Kabeya",
        )
        session.add(duplicate_employee)
        with pytest.raises(IntegrityError):
            session.commit()
        session.rollback()

        session.add(
            Attendance(
                employee_id=employee.id,
                attendance_date=date(2026, 10, 3),
                check_in_at=datetime(2026, 10, 3, 8, 0),
            )
        )
        session.commit()
        session.add(
            Attendance(
                employee_id=employee.id,
                attendance_date=date(2026, 10, 3),
                check_in_at=datetime(2026, 10, 3, 8, 30),
            )
        )
        with pytest.raises(IntegrityError):
            session.commit()


def test_foreign_keys_and_check_constraints_are_enforced(engine):
    with engine.connect() as connection:
        assert connection.exec_driver_sql("PRAGMA foreign_keys").scalar_one() == 1

    with Session(engine) as session:
        session.add(
            Attendance(
                employee_id=999,
                attendance_date=date(2026, 10, 3),
                check_in_at=datetime(2026, 10, 3, 8, 0),
            )
        )
        with pytest.raises(IntegrityError):
            session.commit()
        session.rollback()

        session.add(
            Device(
                device_code="DEVICE-BAD",
                name="Type invalide",
                device_type="unknown",
            )
        )
        with pytest.raises(IntegrityError):
            session.commit()
