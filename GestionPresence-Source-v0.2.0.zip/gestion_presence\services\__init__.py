"""Services métier indépendants de l'interface graphique."""
