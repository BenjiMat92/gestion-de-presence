"""Consultation, gestion et cartes QR des employés."""

from datetime import date
from pathlib import Path
from tkinter import StringVar, filedialog, messagebox, ttk

import qrcode
from sqlalchemy import select
from sqlalchemy.orm import Session, sessionmaker

from gestion_presence.database.models import Department, Employee
from gestion_presence.errors import ApplicationError
from gestion_presence.services.employees import EmployeeService
from gestion_presence.ui.common import (
    BasePage,
    ask_form,
    build_table,
    fill_table,
    has_ui_permission,
    read_database,
    show_error,
    write_database,
)


class EmployeePage(BasePage):
    def __init__(
        self,
        parent,
        session_factory: sessionmaker[Session],
        actor_user_id: int,
    ) -> None:
        super().__init__(parent, "Employés")
        self.session_factory = session_factory
        self.actor_user_id = actor_user_id
        self.search = StringVar()
        ttk.Entry(
            self.toolbar,
            textvariable=self.search,
            width=38,
        ).pack(side="left", fill="x", expand=True, padx=(0, 10))
        ttk.Label(self.toolbar, text="Rechercher nom, prénom ou matricule").pack(
            side="left"
        )
        self.search.trace_add("write", lambda *_args: self.refresh())
        self.add_action(
            "Carte QR", self.export_qr,
            permission=has_ui_permission(session_factory, actor_user_id, "employee.view"),
        )
        self.add_action(
            "Activer / désactiver", self.toggle_employee,
            permission=has_ui_permission(session_factory, actor_user_id, "employee.update"),
        )
        self.add_action(
            "Modifier", self.edit_employee,
            permission=has_ui_permission(session_factory, actor_user_id, "employee.update"),
        )
        self.add_action(
            "Ajouter", self.add_employee,
            permission=has_ui_permission(session_factory, actor_user_id, "employee.create"),
        )
        self.table = build_table(
            self.content,
            ["ID", "Matricule", "Prénom", "Nom", "Service", "Poste", "Téléphone", "Statut"],
        )
        self.refresh()

    def refresh(self) -> None:
        try:
            records = read_database(
                self.session_factory,
                lambda session: [
                    (
                        employee.id,
                        employee.employee_code,
                        employee.first_name,
                        employee.last_name,
                        employee.department.name if employee.department else "",
                        employee.job_title or "",
                        employee.phone or "",
                        "Actif" if employee.is_active else "Désactivé",
                    )
                    for employee in EmployeeService.search(
                        session,
                        actor_user_id=self.actor_user_id,
                        query=self.search.get(),
                        include_inactive=True,
                    )
                ],
            )
            fill_table(self.table, records)
        except Exception as error:
            show_error("Employés", error)

    def selected_id(self) -> int | None:
        selection = self.table.selection()
        if not selection:
            messagebox.showinfo("Employés", "Sélectionnez un employé.", parent=self)
            return None
        return int(self.table.item(selection[0], "values")[0])

    def _departments(self) -> list[tuple[int, str]]:
        return read_database(
            self.session_factory,
            lambda session: [
                (department.id, department.name)
                for department in session.scalars(
                    select(Department)
                    .where(Department.is_active.is_(True))
                    .order_by(Department.name)
                )
            ],
        )

    def _employee_values(self, employee: Employee | None = None):
        departments = self._departments()
        department_choices = [("Aucun service", None)] + [
            (name, identifier) for identifier, name in departments
        ]
        department_name = (
            next(
                (name for identifier, name in departments
                 if identifier == employee.department_id),
                "Aucun service",
            )
            if employee
            else "Aucun service"
        )
        values = ask_form(
            self,
            "Modifier l'employé" if employee else "Nouvel employé",
            [
                ("Prénom *", employee.first_name if employee else "", None, False),
                ("Nom *", employee.last_name if employee else "", None, False),
                ("Service", department_name, department_choices, False),
                ("Poste", employee.job_title or "" if employee else "", None, False),
                ("Téléphone", employee.phone or "" if employee else "", None, False),
                (
                    "Date d'embauche (AAAA-MM-JJ)",
                    employee.hire_date.isoformat()
                    if employee and employee.hire_date
                    else date.today().isoformat(),
                    None,
                    False,
                ),
            ],
        )
        if values is None:
            return None
        try:
            hire_date = date.fromisoformat(str(values["Date d'embauche (AAAA-MM-JJ)"]))
        except ValueError:
            messagebox.showerror(
                "Date invalide", "Utilisez le format AAAA-MM-JJ.", parent=self
            )
            return None
        return {
            "first_name": str(values["Prénom *"]),
            "last_name": str(values["Nom *"]),
            "department_id": values["Service"],
            "job_title": str(values["Poste"]) or None,
            "phone": str(values["Téléphone"]) or None,
            "hire_date": hire_date,
        }

    def add_employee(self) -> None:
        data = self._employee_values()
        if data is None:
            return
        try:
            write_database(
                self.session_factory,
                lambda session: EmployeeService.create(
                    session, actor_user_id=self.actor_user_id, **data
                ),
            )
            self.refresh()
        except Exception as error:
            show_error("Création impossible", error)

    def edit_employee(self) -> None:
        employee_id = self.selected_id()
        if employee_id is None:
            return
        try:
            employee = read_database(
                self.session_factory,
                lambda session: session.get(Employee, employee_id),
            )
            if employee is None:
                raise ApplicationError("L'employé sélectionné n'existe plus.")
            data = self._employee_values(employee)
            if data is None:
                return
            write_database(
                self.session_factory,
                lambda session: EmployeeService.update(
                    session,
                    employee_id,
                    actor_user_id=self.actor_user_id,
                    **data,
                ),
            )
            self.refresh()
        except Exception as error:
            show_error("Modification impossible", error)

    def toggle_employee(self) -> None:
        employee_id = self.selected_id()
        if employee_id is None:
            return
        try:
            active = read_database(
                self.session_factory,
                lambda session: bool(session.get(Employee, employee_id).is_active),
            )
            operation = EmployeeService.deactivate if active else EmployeeService.activate
            write_database(
                self.session_factory,
                lambda session: operation(
                    session, employee_id, actor_user_id=self.actor_user_id
                ),
            )
            self.refresh()
        except Exception as error:
            show_error("Statut impossible à modifier", error)

    def export_qr(self) -> None:
        employee_id = self.selected_id()
        if employee_id is None:
            return
        try:
            employee_code = read_database(
                self.session_factory,
                lambda session: EmployeeService.get_by_id(
                    session, employee_id, actor_user_id=self.actor_user_id
                ).employee_code,
            )
            path = filedialog.asksaveasfilename(
                parent=self,
                title="Enregistrer la carte QR",
                initialfile=f"{employee_code}.png",
                defaultextension=".png",
                filetypes=[("Image PNG", "*.png")],
            )
            if not path:
                return
            qr = qrcode.QRCode(box_size=10, border=4)
            qr.add_data(employee_code)
            qr.make(fit=True)
            qr.make_image(fill_color="black", back_color="white").save(Path(path))
            messagebox.showinfo("Carte QR", f"Carte enregistrée : {path}", parent=self)
        except Exception as error:
            show_error("Carte QR", error)
